# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, ProcessViewSet, FormViewSet

router = DefaultRouter()
router.register(r'categories', CategoryViewSet)
router.register(r'processes', ProcessViewSet)
router.register(r'forms', FormViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('processes/<int:pk>/verify_password/', ProcessViewSet.as_view({'post': 'verify_password'}), name='process'
                                                                                                          '-verify-'
                                                                                                          'password'),
    path('forms/<int:pk>/verify_password/', FormViewSet.as_view({'post': 'verify_password'}), name='form'
                                                                                                   '-verify-password'),
    path('forms/<int:pk>/', FormViewSet.show_form_list, name='form_list')
]
