from django.db import models
from django.contrib.auth.models import User
from ordered_model.models import OrderedModel
import uuid


class Form(models.Model):
    name = models.CharField(max_length=255)
    is_private = models.BooleanField(default=False)
    password = models.CharField(max_length=255, blank=True, null=True)
    link = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_forms')
    filled_by = models.ManyToManyField(User, related_name='filled_forms', blank=True, through='Response')
    views = models.IntegerField(default=0)
    responses = models.IntegerField(default=0)

    def __str__(self):
        return self.name


class DescriptiveQuestion(OrderedModel):
    question = models.TextField()
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='descriptive_questions')
    order_with_respect_to = 'form'

    def __str__(self):
        return self.question


class SelectedText(models.Model):
    text = models.CharField(max_length=255)

    def __str__(self):
        return self.text


class MultipleChoiceQuestion(OrderedModel):
    question = models.TextField()
    choices = models.ManyToManyField(SelectedText, related_name='multiple_choice_questions')
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='multiple_choice_questions')
    order_with_respect_to = 'form'

    def __str__(self):
        return self.question


class CheckboxChoice(models.Model):
    text = models.CharField(max_length=255)
    question = models.ForeignKey('CheckboxQuestion', on_delete=models.CASCADE, related_name='choices')

    def __str__(self):
        return self.text


class CheckboxQuestion(OrderedModel):
    question = models.TextField()
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='checkbox_questions')
    order_with_respect_to = 'form'

    def __str__(self):
        return self.question


class TrueFalseQuestion(OrderedModel):
    question = models.TextField()
    is_true = models.BooleanField()
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='true_false_questions')
    order_with_respect_to = 'form'

    def __str__(self):
        return self.question


class RatingQuestion(OrderedModel):
    question = models.TextField()
    max_rating = models.IntegerField()
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='rating_questions')
    order_with_respect_to = 'form'

    def __str__(self):
        return self.question


class FourChoiceQuestion(OrderedModel):
    question = models.TextField()
    choice1 = models.CharField(max_length=255)
    choice2 = models.CharField(max_length=255)
    choice3 = models.CharField(max_length=255)
    choice4 = models.CharField(max_length=255)
    selected_choice = models.IntegerField(choices=[(1, 'Choice 1'), (2, 'Choice 2'), (3, 'Choice 3'), (4, 'Choice 4')],
                                          blank=True, null=True)
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='four_choice_questions')
    order_with_respect_to = 'form'

    def __str__(self):
        return self.question


class Response(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    form = models.ForeignKey(Form, on_delete=models.CASCADE)
    descriptive_answers = models.ManyToManyField(DescriptiveQuestion, through='DescriptiveAnswer')
    multiple_choice_answers = models.ManyToManyField(MultipleChoiceQuestion, through='MultipleChoiceAnswer')
    checkbox_answers = models.ManyToManyField(CheckboxQuestion, through='CheckboxAnswer')
    true_false_answers = models.ManyToManyField(TrueFalseQuestion, through='TrueFalseAnswer')
    rating_answers = models.ManyToManyField(RatingQuestion, through='RatingAnswer')
    four_choice_answers = models.ManyToManyField(FourChoiceQuestion, through='FourChoiceAnswer')

    def __str__(self):
        return f"Response by {self.user} for form {self.form}"


class DescriptiveAnswer(models.Model):
    response = models.ForeignKey(Response, on_delete=models.CASCADE)
    question = models.ForeignKey(DescriptiveQuestion, on_delete=models.CASCADE)
    answer = models.TextField()

    def __str__(self):
        return self.answer


class MultipleChoiceAnswer(models.Model):
    response = models.ForeignKey(Response, on_delete=models.CASCADE)
    question = models.ForeignKey(MultipleChoiceQuestion, on_delete=models.CASCADE)
    selected_choice = models.ForeignKey(SelectedText, on_delete=models.CASCADE)

    def __str__(self):
        return self.selected_choice.text


class CheckboxAnswer(models.Model):
    response = models.ForeignKey(Response, on_delete=models.CASCADE)
    question = models.ForeignKey(CheckboxQuestion, on_delete=models.CASCADE)
    selected_choices = models.ManyToManyField(CheckboxChoice)

    def __str__(self):
        return ', '.join([choice.text for choice in self.selected_choices.all()])


class TrueFalseAnswer(models.Model):
    response = models.ForeignKey(Response, on_delete=models.CASCADE)
    question = models.ForeignKey(TrueFalseQuestion, on_delete=models.CASCADE)
    answer = models.BooleanField()

    def __str__(self):
        return 'True' if self.answer else 'False'


class RatingAnswer(models.Model):
    response = models.ForeignKey(Response, on_delete=models.CASCADE)
    question = models.ForeignKey(RatingQuestion, on_delete=models.CASCADE)
    rating = models.IntegerField()

    def __str__(self):
        return str(self.rating)


class FourChoiceAnswer(models.Model):
    response = models.ForeignKey(Response, on_delete=models.CASCADE)
    question = models.ForeignKey(FourChoiceQuestion, on_delete=models.CASCADE)
    selected_choice = models.IntegerField(choices=[(1, 'Choice 1'), (2, 'Choice 2'), (3, 'Choice 3'), (4, 'Choice 4')])

    def __str__(self):
        return f"Choice {self.selected_choice}"


class ProcessForm(OrderedModel):
    process = models.ForeignKey('Process', on_delete=models.CASCADE)
    form = models.ForeignKey(Form, on_delete=models.CASCADE)
    order_with_respect_to = 'process'

    class Meta(OrderedModel.Meta):
        ordering = ['process', 'order']


class Process(models.Model):
    name = models.CharField(max_length=255)
    forms = models.ManyToManyField(Form, through=ProcessForm)
    is_private = models.BooleanField(default=False)
    password = models.CharField(max_length=255, blank=True, null=True)
    is_linear = models.BooleanField(default=True)  # True for linear, False for free
    link = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_processes')
    views = models.IntegerField(default=0)
    responses = models.IntegerField(default=0)

    def __str__(self):
        return self.name


class Category(models.Model):
    name = models.CharField(max_length=255)
    forms = models.ManyToManyField(Form, blank=True)
    processes = models.ManyToManyField(Process, blank=True)
    is_private = models.BooleanField(default=False)
    password = models.CharField(max_length=255, blank=True, null=True)
    link = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_categories')

    def __str__(self):
        return self.name


class FormView(models.Model):
    form = models.ForeignKey(Form, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    viewed_at = models.DateTimeField(auto_now_add=True)


class ProcessView(models.Model):
    process = models.ForeignKey(Process, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    viewed_at = models.DateTimeField(auto_now_add=True)
