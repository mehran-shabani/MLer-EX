import uuid
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied, ValidationError
from django.contrib.auth.models import User
from .models import (
    Category, Process, Form, DescriptiveQuestion, MultipleChoiceQuestion, CheckboxQuestion, TrueFalseQuestion,
    RatingQuestion, FourChoiceQuestion, SelectedText, CheckboxChoice, Response as FormResponse, DescriptiveAnswer,
    MultipleChoiceAnswer, CheckboxAnswer, TrueFalseAnswer, RatingAnswer, FourChoiceAnswer
)
from .serializers import (
    CategorySerializer, ProcessSerializer, FormSerializer,
    ResponseSerializer, UserSerializer, DescriptiveAnswerSerializer, MultipleChoiceAnswerSerializer,
    CheckboxAnswerSerializer, TrueFalseAnswerSerializer, RatingAnswerSerializer, FourChoiceAnswerSerializer
)
from django.db import transaction


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class ProcessViewSet(viewsets.ModelViewSet):
    queryset = Process.objects.all()
    serializer_class = ProcessSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=['post'])
    def verify_password(self, request, pk=None):
        process = self.get_object()
        if process.is_private:
            if 'password' in request.data:
                if process.password == request.data['password']:
                    return Response({'detail': 'Password verified.'}, status=status.HTTP_200_OK)
                else:
                    raise PermissionDenied('Incorrect password.')
            else:
                raise PermissionDenied('Password required.')
        return Response({'detail': 'Password not required.'}, status=status.HTTP_200_OK)


class FormViewSet(viewsets.ModelViewSet):
    queryset = Form.objects.all()
    serializer_class = FormSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='link/(?P<link>[^/.]+)')
    def get_form_by_link(self, request, link=None):
        try:
            form = Form.objects.get(link=link)
            serializer = self.get_serializer(form)
            print('FORM THAT SEND TO FRONT', serializer.data)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Form.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)

    @action(detail=True, methods=['get'])
    def show_form_list(self, request):
        data = request.data
        print(data)
        try:
            form = Form.objects.all(user=request.user)
            serializer = self.get_serializer(form, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Form.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)

    @action(detail=True, methods=['post'])
    def verify_password(self, request):
        form = self.get_object()
        if form.is_private:
            if 'password' in request.data:
                if form.password == request.data['password']:
                    return Response({'detail': 'Password verified.'}, status=status.HTTP_200_OK)
                else:
                    raise PermissionDenied('Incorrect password.')
            else:
                raise PermissionDenied('Password required.')
        return Response({'detail': 'Password not required.'}, status=status.HTTP_200_OK)

    @transaction.atomic
    def create(self, request, *args, **kwargs):
        data = request.data
        print(data)
        is_private = data.get('is_private', False)
        password = data.get('password', '') if is_private else ''
        form = Form.objects.create(
            name=data['name'],
            is_private=is_private,
            password=password,
            created_by=request.user
        )

        for question in data.get('descriptive_questions', []):
            DescriptiveQuestion.objects.create(form=form, **question)
        for question in data.get('multiple_choice_questions', []):
            choices = question.pop('choices')
            multiple_choice_question = MultipleChoiceQuestion.objects.create(form=form, **question)
            choice_objects = [SelectedText.objects.create(text=choice_text) for choice_text in choices]
            multiple_choice_question.choices.set(choice_objects)  # set for many to many
        for question in data.get('checkbox_questions', []):
            checkboxes = question.pop('checkboxes')
            checkbox_question = CheckboxQuestion.objects.create(form=form, **question)
            checkbox_objects = [CheckboxChoice.objects.create(text=checkbox_text, question=checkbox_question) for
                                checkbox_text in checkboxes]
            checkbox_question.choices.set(checkbox_objects)  # set for many to many
        for question in data.get('true_false_questions', []):
            TrueFalseQuestion.objects.create(form=form, **question)
        for question in data.get('rating_questions', []):
            RatingQuestion.objects.create(form=form, **question)
        for question in data.get('four_choice_questions', []):
            FourChoiceQuestion.objects.create(form=form, **question)

        serializer = FormSerializer(form)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['post'], url_path='link/(?P<link>[^/.]+)/submit')
    @transaction.atomic
    def submit_form_by_link(self, request, link=None):
        try:
            uuid_obj = uuid.UUID(link)  # بررسی لینک به عنوان UUID
            form = Form.objects.get(link=uuid_obj)
            response = FormResponse.objects.create(user=request.user, form=form)
            print("Incoming request data:", request.data)

            for answer_data in request.data.get('descriptive_answers', []):
                question = DescriptiveQuestion.objects.filter(id=answer_data['question_id']).first()
                if question:
                    DescriptiveAnswer.objects.create(response=response, question=question, answer=answer_data['answer'])
                    print("Saved descriptive answer:", DescriptiveAnswer)

            for answer_data in request.data.get('multiple_choice_answers', []):
                question = MultipleChoiceQuestion.objects.filter(id=answer_data['question_id']).first()
                if question:
                    selected_choice = SelectedText.objects.filter(id=answer_data['selected_choice_id']).first()
                    if selected_choice:
                        MultipleChoiceAnswer.objects.create(response=response, question=question,
                                                            selected_choice=selected_choice)
                        print("Saved multiple choice answer:", MultipleChoiceAnswer)

            for answer_data in request.data.get('checkbox_answers', []):
                question = CheckboxQuestion.objects.filter(id=answer_data['question_id']).first()
                if question:
                    checkbox_answer = CheckboxAnswer.objects.create(response=response, question=question)
                    selected_choices = [CheckboxChoice.objects.filter(id=choice_id, question=question).first() for
                                        choice_id in answer_data['selected_choice_ids']]
                    selected_choices = [choice for choice in selected_choices if choice is not None]
                    checkbox_answer.selected_choices.set(selected_choices)
                    print("Saved checkbox answer:", checkbox_answer)

            for answer_data in request.data.get('true_false_answers', []):
                question = TrueFalseQuestion.objects.filter(id=answer_data['question_id']).first()
                if question:
                    answer = answer_data['answer']
                    if isinstance(answer, str):
                        answer = answer.lower() in ['true', '1', 'yes']
                    elif isinstance(answer, int):
                        answer = bool(answer)
                    TrueFalseAnswer.objects.create(response=response, question=question, answer=answer)
                    print("Saved true false answer:", TrueFalseAnswer)

            for answer_data in request.data.get('rating_answers', []):
                question = RatingQuestion.objects.filter(id=answer_data['question_id']).first()
                if question:
                    RatingAnswer.objects.create(response=response, question=question, rating=answer_data['rating'])
                    print("Saved rating answer:", RatingAnswer)

            for answer_data in request.data.get('four_choice_answers', []):
                question = FourChoiceQuestion.objects.filter(id=answer_data['question_id']).first()
                if question:
                    FourChoiceAnswer.objects.create(response=response, question=question,
                                                    selected_choice=answer_data['selected_choice'])
                    print("Saved four choice answer:", FourChoiceAnswer)

            serializer = ResponseSerializer(response)
            print("Response data:", serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        except Form.DoesNotExist:
            return Response({'detail': 'Form not found.'}, status=status.HTTP_404_NOT_FOUND)
        except ValidationError as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['get'], url_path='link/(?P<link>[^/.]+)/responses')
    @transaction.atomic
    def responses(self, request, link=None):
        try:
            uuid_obj = uuid.UUID(link)
            print(f"Received link: {link}")  # چاپ لینک دریافتی
            form = Form.objects.get(link=uuid_obj)
            print(f"Form: {form}")  # چاپ اطلاعات فرم
            responses = FormResponse.objects.filter(form=form)
            print(f"Responses: {responses}")  # چاپ اطلاعات پاسخ‌ها
            response_data = []
            for response in responses:
                response_dict = {
                    'user': response.user.username,
                    'descriptive_answers': DescriptiveAnswerSerializer(
                        DescriptiveAnswer.objects.filter(response=response), many=True).data,
                    'multiple_choice_answers': MultipleChoiceAnswerSerializer(
                        MultipleChoiceAnswer.objects.filter(response=response), many=True).data,
                    'checkbox_answers': CheckboxAnswerSerializer(CheckboxAnswer.objects.filter(response=response),
                                                                 many=True).data,
                    'true_false_answers': TrueFalseAnswerSerializer(TrueFalseAnswer.objects.filter(response=response),
                                                                    many=True).data,
                    'rating_answers': RatingAnswerSerializer(RatingAnswer.objects.filter(response=response),
                                                             many=True).data,
                    'four_choice_answers': FourChoiceAnswerSerializer(
                        FourChoiceAnswer.objects.filter(response=response), many=True).data,
                }
                response_data.append(response_dict)
            print(f"Response Data: {response_data}")  # چاپ داده‌های نهایی پاسخ
            return Response(response_data, status=status.HTTP_200_OK)
        except Form.DoesNotExist:
            return Response({'detail': 'Form not found.'}, status=status.HTTP_404_NOT_FOUND)


class ResponseViewSet(viewsets.ModelViewSet):
    queryset = FormResponse.objects.all()
    serializer_class = ResponseSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
