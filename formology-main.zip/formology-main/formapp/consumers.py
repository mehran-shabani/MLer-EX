import json
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import sync_to_async


class FormConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.form_id = self.scope['url_route']['kwargs']['form_id']
        self.form_group_name = f'form_{self.form_id}'

        await self.channel_layer.group_add(
            self.form_group_name,
            self.channel_name
        )

        await self.accept()

        # Send initial form data
        await self.send_initial_form_data()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            self.form_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        # Handle incoming messages if necessary
        pass

    async def send_form_update(self, event):
        form_data = event['form_data']
        await self.send(text_data=json.dumps(form_data))

    async def send_initial_form_data(self):
        form_data = await self.get_form_data()
        await self.send(text_data=json.dumps(form_data))

    @sync_to_async
    def get_form_data(self):
        from formapp.models import Form  # Import moved inside the method
        form = Form.objects.get(id=self.form_id)
        return {
            'id': form.id,
            'name': form.name,
            'questions': list(form.descriptive_questions.values())
        }


class ProcessConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.process_id = self.scope['url_route']['kwargs']['process_id']
        self.process_group_name = f'process_{self.process_id}'

        await self.channel_layer.group_add(
            self.process_group_name,
            self.channel_name
        )

        await self.accept()

        # Send initial process data
        await self.send_initial_process_data()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            self.process_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        # Handle incoming messages if necessary
        pass

    async def send_process_update(self, event):
        process_data = event['process_data']
        await self.send(text_data=json.dumps(process_data))

    async def send_initial_process_data(self):
        process_data = await self.get_process_data()
        await self.send(text_data=json.dumps(process_data))

    @sync_to_async
    def get_process_data(self):
        from formapp.models import Process  # Import moved inside the method
        process = Process.objects.get(id=self.process_id)
        return {
            'id': process.id,
            'name': process.name,
            'forms': list(process.forms.values())
        }
