from django.contrib import admin
from .models import Form, Process, DescriptiveQuestion, MultipleChoiceQuestion, CheckboxQuestion, TrueFalseQuestion, \
    RatingQuestion, FourChoiceQuestion


class DescriptiveQuestionInline(admin.TabularInline):
    model = DescriptiveQuestion
    extra = 1


class MultipleChoiceQuestionInline(admin.TabularInline):
    model = MultipleChoiceQuestion
    extra = 1


class CheckboxQuestionInline(admin.TabularInline):
    model = CheckboxQuestion
    extra = 1


class TrueFalseQuestionInline(admin.TabularInline):
    model = TrueFalseQuestion
    extra = 1


class RatingQuestionInline(admin.TabularInline):
    model = RatingQuestion
    extra = 1


class FourChoiceQuestionInline(admin.TabularInline):
    model = FourChoiceQuestion
    extra = 1


class FormAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_by', 'created_at', 'is_private']
    inlines = [
        DescriptiveQuestionInline,
        MultipleChoiceQuestionInline,
        CheckboxQuestionInline,
        TrueFalseQuestionInline,
        RatingQuestionInline,
        FourChoiceQuestionInline,
    ]


class ProcessAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_by', 'created_at', 'is_private', 'is_linear']


admin.site.register(Form, FormAdmin)
admin.site.register(Process, ProcessAdmin)
