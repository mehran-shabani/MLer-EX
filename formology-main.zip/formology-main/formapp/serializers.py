from django.contrib.auth.models import User
from rest_framework import serializers

from .models import (
    Form, Process, DescriptiveQuestion, MultipleChoiceQuestion, CheckboxQuestion, TrueFalseQuestion,
    RatingQuestion, FourChoiceQuestion, Category, Response, DescriptiveAnswer, MultipleChoiceAnswer,
    CheckboxAnswer, TrueFalseAnswer, RatingAnswer, FourChoiceAnswer, SelectedText, CheckboxChoice
)


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']


class SelectedTextSerializer(serializers.ModelSerializer):
    class Meta:
        model = SelectedText
        fields = ['id', 'text']


class DescriptiveQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = DescriptiveQuestion
        fields = ['id', 'question']

class CheckboxChoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = CheckboxChoice
        fields = ['id', 'text']


class CheckboxQuestionSerializer(serializers.ModelSerializer):
    choices = CheckboxChoiceSerializer(many=True, read_only=True)

    class Meta:
        model = CheckboxQuestion
        fields = ['id', 'question', 'choices']


class MultipleChoiceQuestionSerializer(serializers.ModelSerializer):
    choices = serializers.StringRelatedField(many=True)

    class Meta:
        model = MultipleChoiceQuestion
        fields = ['id', 'question', 'choices']


class TrueFalseQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrueFalseQuestion
        fields = ['id', 'question', 'is_true']


class RatingQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RatingQuestion
        fields = ['id', 'question', 'max_rating']


class FourChoiceQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = FourChoiceQuestion
        fields = ['id', 'question', 'choice1', 'choice2', 'choice3', 'choice4', 'selected_choice']


class DescriptiveAnswerSerializer(serializers.ModelSerializer):
    question = DescriptiveQuestionSerializer()

    class Meta:
        model = DescriptiveAnswer
        fields = ['question', 'answer']


class MultipleChoiceAnswerSerializer(serializers.ModelSerializer):
    question = MultipleChoiceQuestionSerializer()
    selected_choice = serializers.StringRelatedField()

    class Meta:
        model = MultipleChoiceAnswer
        fields = ['question', 'selected_choice']


class CheckboxAnswerSerializer(serializers.ModelSerializer):
    question = CheckboxQuestionSerializer()
    selected_choices = serializers.StringRelatedField(many=True)

    class Meta:
        model = CheckboxAnswer
        fields = ['question', 'selected_choices']


class TrueFalseAnswerSerializer(serializers.ModelSerializer):
    question = TrueFalseQuestionSerializer()

    class Meta:
        model = TrueFalseAnswer
        fields = ['question', 'answer']


class RatingAnswerSerializer(serializers.ModelSerializer):
    question = RatingQuestionSerializer()

    class Meta:
        model = RatingAnswer
        fields = ['question', 'rating']


class FourChoiceAnswerSerializer(serializers.ModelSerializer):
    question = FourChoiceQuestionSerializer()

    class Meta:
        model = FourChoiceAnswer
        fields = ['question', 'selected_choice']


class FormSerializer(serializers.ModelSerializer):
    descriptive_questions = DescriptiveQuestionSerializer(many=True, read_only=True)
    multiple_choice_questions = MultipleChoiceQuestionSerializer(many=True, read_only=True)
    checkbox_questions = CheckboxQuestionSerializer(many=True, read_only=True)
    true_false_questions = TrueFalseQuestionSerializer(many=True, read_only=True)
    rating_questions = RatingQuestionSerializer(many=True, read_only=True)
    four_choice_questions = FourChoiceQuestionSerializer(many=True, read_only=True)
    created_by = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Form
        fields = ['id', 'name', 'descriptive_questions', 'multiple_choice_questions', 'checkbox_questions',
                  'true_false_questions', 'rating_questions', 'four_choice_questions', 'is_private', 'password',
                  'link', 'created_at', 'created_by']


class ResponseSerializer(serializers.ModelSerializer):
    descriptive_answers = DescriptiveAnswerSerializer(many=True, source='descriptiveanswer_set')
    multiple_choice_answers = MultipleChoiceAnswerSerializer(many=True, source='multiplechoiceanswer_set')
    checkbox_answers = CheckboxAnswerSerializer(many=True, source='checkboxanswer_set')
    true_false_answers = TrueFalseAnswerSerializer(many=True, source='truefalseanswer_set')
    rating_answers = RatingAnswerSerializer(many=True, source='ratinganswer_set')
    four_choice_answers = FourChoiceAnswerSerializer(many=True, source='fourchoiceanswer_set')

    class Meta:
        model = Response
        fields = ['id', 'user', 'form', 'descriptive_answers', 'multiple_choice_answers', 'checkbox_answers',
                  'true_false_answers', 'rating_answers', 'four_choice_answers']


class ProcessSerializer(serializers.ModelSerializer):
    forms = FormSerializer(many=True, read_only=True)
    created_by = UserSerializer(read_only=True)
    link = serializers.UUIDField(read_only=True)

    class Meta:
        model = Process
        fields = ['id', 'name', 'forms', 'is_private', 'password', 'is_linear', 'link', 'created_at', 'created_by']


class CategorySerializer(serializers.ModelSerializer):
    link = serializers.UUIDField(read_only=True)

    class Meta:
        model = Category
        fields = ['id', 'name', 'forms', 'processes', 'is_private', 'password', 'link', 'created_at', 'created_by']



