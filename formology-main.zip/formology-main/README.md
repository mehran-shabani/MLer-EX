# Formology

## Overview

Formology is a comprehensive Django application that includes RESTful APIs, GraphQL integration, Celery for asynchronous task management, Redis for caching and messaging, and Docker for containerization. It supports periodic email reports, detailed form and process management, and real-time updates using WebSockets.

The frontend is built with React, providing user authentication, form and process creation, and a dashboard for managing forms and processes. Users can fill out forms and processes, with the ability to handle private forms and processes requiring passwords.

## Features

- **Django REST Framework** for building APIs
- **GraphQL** support with Graphene-Django
- **Celery** for handling background tasks
- **Redis** as a message broker and caching backend
- **Docker** for containerized deployment
- **Swagger and Redoc** for API documentation
- **Periodic Email Reports** configurable via Django admin
- **Real-time updates** using WebSockets
- **React** frontend with user authentication, form, and process management

## Prerequisites

- Docker and Docker Compose
- Python 3.9+
- Redis (for caching and Celery)

## Getting Started

### Backend Setup

1. **Clone the repository**

    ```sh
    git clone https://github.com/your-username/formology.git
    cd formology
    ```

2. **Set up environment variables**

   Create a `.env` file in the root directory of your project and add the following environment variables:

    ```env
    SECRET_KEY=your_secret_key
    DEBUG=True
    DJANGO_ALLOWED_HOSTS=localhost 127.0.0.1 [::1]
    REDIS_URL=redis://redis:6379/0
    CELERY_BROKER_URL=redis://redis:6379/0
    CELERY_RESULT_BACKEND=redis://redis:6379/0
    ```

3. **Build and run Docker containers**

    ```sh
    docker-compose up --build
    ```

   This command will build the Docker images and start the containers for the Django application and Redis.

4. **Apply database migrations and create superuser**

   Open a new terminal window and run the following commands:

    ```sh
    docker-compose exec web python manage.py migrate
    docker-compose exec web python manage.py createsuperuser
    ```

   Follow the prompts to create a superuser account.

5. **Access the application**

    - **Django Admin**: [http://localhost:8000/admin](http://localhost:8000/admin)
    - **Swagger API Documentation**: [http://localhost:8000/swagger/](http://localhost:8000/swagger/)
    - **Redoc API Documentation**: [http://localhost:8000/redoc/](http://localhost:8000/redoc/)
    - **GraphQL Playground**: [http://localhost:8000/graphql/](http://localhost:8000/graphql/)

### Frontend Setup

1. **Navigate to the frontend directory**

    ```sh
    cd formology-frontend
    ```

2. **Install dependencies**

    ```sh
    npm install
    ```

3. **Run the React application**

    ```sh
    npm start
    ```

   The application will be available at [http://localhost:3000](http://localhost:3000).

## Usage

### User Authentication

- **Login**: Users can log in with their username and password.
- **Register**: New users can register with a username, password, and email.

### Dashboard

- **Forms**: Users can view, create, edit, and delete their forms.
- **Processes**: Users can view, create, edit, and delete their processes.
- **Form and Process Details**: Users can view detailed information about their forms and processes.

### Filling Forms and Processes

- **Form Filling**: Users can fill out forms, answering various types of questions.
- **Process Navigation**: Users can navigate through processes, filling out forms in sequence or freely, based on process configuration.
- **Password Protection**: If a form or process is private, users will be prompted to enter a password before accessing it.

## API Documentation

Formology uses `drf-yasg` to generate interactive API documentation. You can access the documentation at the following endpoints:

- **Swagger**: [http://localhost:8000/swagger/](http://localhost:8000/swagger/)
- **Redoc**: [http://localhost:8000/redoc/](http://localhost:8000/redoc/)

## Real-time Updates

Formology supports real-time updates using WebSockets. The WebSocket endpoints are:

- `/ws/form/<int:form_id>/`
- `/ws/process/<int:process_id>/`

These endpoints provide real-time updates for forms and processes.

## Periodic Email Reports

Admins can configure periodic email reports via the Django admin panel. The reports include information about forms and processes created within a specified date range.

### Configuration

To configure periodic email reports:

1. Log in to the Django admin panel.
2. Navigate to the "Report Settings" section.
3. Set the desired interval for receiving reports, the date range, and the email address to receive the reports.

## Celery

Celery is used for handling background tasks such as sending periodic email reports. The Celery worker and beat services are defined in the `docker-compose.yml` file.

To start the Celery worker and beat services, run:


    docker-compose up -d celery celery-beat
##  Caching
Formology uses Redis for caching. The cache backend is configured in settings.py and uses django-redis.

## GraphQL
Formology supports GraphQL via graphene-django. The GraphQL endpoint is available at:

GraphQL Playground: http://localhost:8000/graphql/
Example Query
graphql

    {
     allForms {
       id
       name
       createdAt
     }
     allProcesses {
       id
       name
       createdAt
     }
   }
Running Tests
To run tests, use the following command:


    docker-compose exec web python manage.py test
## Contributing
We welcome contributions to Formology! Please fork the repository and submit pull requests for review.

## License
This project is licensed under the MIT License.
