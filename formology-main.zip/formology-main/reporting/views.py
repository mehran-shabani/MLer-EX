# reporting/views.py

from rest_framework import viewsets
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from .models import ReportSettings
from .serializers import ReportSettingsSerializer
from formapp.serializers import *


class ReportSettingsViewSet(viewsets.ModelViewSet):
    queryset = ReportSettings.objects.all()
    serializer_class = ReportSettingsSerializer
    permission_classes = [IsAdminUser]


# reporting/views.py

from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync


class FormViewSet(viewsets.ModelViewSet):
    queryset = Form.objects.all()
    serializer_class = FormSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        form = serializer.save(created_by=self.request.user)
        self.send_form_update(form)

    def perform_update(self, serializer):
        form = serializer.save()
        self.send_form_update(form)

    def send_form_update(self, form):
        channel_layer = get_channel_layer()
        form_data = FormSerializer(form).data
        async_to_sync(channel_layer.group_send)(
            f'form_{form.id}',
            {
                'type': 'send_form_update',
                'form_data': form_data,
            }
        )


class ProcessViewSet(viewsets.ModelViewSet):
    queryset = Process.objects.all()
    serializer_class = ProcessSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        process = serializer.save(created_by=self.request.user)
        self.send_process_update(process)

    def perform_update(self, serializer):
        process = serializer.save()
        self.send_process_update(process)

    def send_process_update(self, process):
        channel_layer = get_channel_layer()
        process_data = ProcessSerializer(process).data
        async_to_sync(channel_layer.group_send)(
            f'process_{process.id}',
            {
                'type': 'send_process_update',
                'process_data': process_data,
            }
        )
