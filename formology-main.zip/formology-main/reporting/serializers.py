# reporting/serializers.py

from rest_framework import serializers
from .models import ReportSettings


class ReportSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportSettings
        fields = '__all__'
