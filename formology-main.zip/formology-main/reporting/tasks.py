# reporting/tasks.py

from celery import shared_task
from django.core.mail import send_mail
from django.utils import timezone
from .models import ReportSettings
from formapp.models import Form, Process
from formapp.serializers import FormSerializer, ProcessSerializer
import json


@shared_task
def send_periodic_reports():
    now = timezone.now()
    settings = ReportSettings.objects.all()

    for setting in settings:
        if (now - setting.last_sent).days >= setting.send_interval:
            forms = Form.objects.filter(created_at__range=(setting.start_date, setting.end_date))
            processes = Process.objects.filter(created_at__range=(setting.start_date, setting.end_date))

            form_serializer = FormSerializer(forms, many=True)
            process_serializer = ProcessSerializer(processes, many=True)

            message = f"Report from {setting.start_date} to {setting.end_date}\n\n"
            message += "Forms:\n" + json.dumps(form_serializer.data, indent=2) + "\n\n"
            message += "Processes:\n" + json.dumps(process_serializer.data, indent=2) + "\n\n"

            send_mail(
                'Periodic Report',
                message,
                'from@example.com',
                [setting.email],
                fail_silently=False,
            )

            setting.last_sent = now
            setting.save()
