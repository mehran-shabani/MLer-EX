# reporting/admin.py

from django.contrib import admin
from .models import ReportSettings


@admin.register(ReportSettings)
class ReportSettingsAdmin(admin.ModelAdmin):
    list_display = ('admin_user', 'send_interval', 'last_sent', 'email')
    fields = ('admin_user', 'send_interval', 'start_date', 'end_date', 'email')
