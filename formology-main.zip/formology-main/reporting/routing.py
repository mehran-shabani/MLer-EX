from django.urls import re_path
from formapp.consumers import FormConsumer, ProcessConsumer

websocket_urlpatterns = [
    re_path(r'ws/form/(?P<form_id>\d+)/$', FormConsumer.as_asgi()),
    re_path(r'ws/process/(?P<process_id>\d+)/$', ProcessConsumer.as_asgi()),
]
