# reporting/urls.py

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ReportSettingsViewSet

router = DefaultRouter()
router.register(r'settings', ReportSettingsViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
