# reporting/models.py

from django.db import models
from django.contrib.auth.models import User


class ReportSettings(models.Model):
    admin_user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='report_settings')
    send_interval = models.IntegerField(default=7)  # Interval in days
    last_sent = models.DateTimeField(auto_now_add=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    email = models.EmailField()

    def __str__(self):
        return f'Report settings for {self.admin_user.username}'
