import graphene
from graphene_django.types import DjangoObjectType
from formapp.models import (
    Form, Process, DescriptiveQuestion, MultipleChoiceQuestion,
    CheckboxQuestion, TrueFalseQuestion, RatingQuestion, FourChoiceQuestion, Category
)
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password

class UserType(DjangoObjectType):
    class Meta:
        model = User

class DescriptiveQuestionType(DjangoObjectType):
    class Meta:
        model = DescriptiveQuestion

class MultipleChoiceQuestionType(DjangoObjectType):
    class Meta:
        model = MultipleChoiceQuestion

class CheckboxQuestionType(DjangoObjectType):
    class Meta:
        model = CheckboxQuestion

class TrueFalseQuestionType(DjangoObjectType):
    class Meta:
        model = TrueFalseQuestion

class RatingQuestionType(DjangoObjectType):
    class Meta:
        model = RatingQuestion

class FourChoiceQuestionType(DjangoObjectType):
    class Meta:
        model = FourChoiceQuestion

class CategoryType(DjangoObjectType):
    class Meta:
        model = Category

class FormType(DjangoObjectType):
    class Meta:
        model = Form

class ProcessType(DjangoObjectType):
    class Meta:
        model = Process

class Query(graphene.ObjectType):
    all_users = graphene.List(UserType)
    all_forms = graphene.List(FormType)
    all_processes = graphene.List(ProcessType)
    all_descriptive_questions = graphene.List(DescriptiveQuestionType)
    all_multiple_choice_questions = graphene.List(MultipleChoiceQuestionType)
    all_checkbox_questions = graphene.List(CheckboxQuestionType)
    all_true_false_questions = graphene.List(TrueFalseQuestionType)
    all_rating_questions = graphene.List(RatingQuestionType)
    all_four_choice_questions = graphene.List(FourChoiceQuestionType)
    all_categories = graphene.List(CategoryType)

    user = graphene.Field(UserType, id=graphene.Int())
    form = graphene.Field(FormType, id=graphene.Int())
    process = graphene.Field(ProcessType, id=graphene.Int())

    def resolve_all_users(self, info, **kwargs):
        return User.objects.all()

    def resolve_all_forms(self, info, **kwargs):
        return Form.objects.all()

    def resolve_all_processes(self, info, **kwargs):
        return Process.objects.all()

    def resolve_all_descriptive_questions(self, info, **kwargs):
        return DescriptiveQuestion.objects.all()

    def resolve_all_multiple_choice_questions(self, info, **kwargs):
        return MultipleChoiceQuestion.objects.all()

    def resolve_all_checkbox_questions(self, info, **kwargs):
        return CheckboxQuestion.objects.all()

    def resolve_all_true_false_questions(self, info, **kwargs):
        return TrueFalseQuestion.objects.all()

    def resolve_all_rating_questions(self, info, **kwargs):
        return RatingQuestion.objects.all()

    def resolve_all_four_choice_questions(self, info, **kwargs):
        return FourChoiceQuestion.objects.all()

    def resolve_all_categories(self, info, **kwargs):
        return Category.objects.all()

    def resolve_user(self, info, id):
        return User.objects.get(id=id)

    def resolve_form(self, info, id):
        return Form.objects.get(id=id)

    def resolve_process(self, info, id):
        return Process.objects.get(id=id)

class CreateUser(graphene.Mutation):
    class Arguments:
        username = graphene.String(required=True)
        email = graphene.String(required=True)
        password = graphene.String(required=True)

    user = graphene.Field(UserType)

    def mutate(self, info, username, email, password):
        user = User(username=username, email=email, password=make_password(password))
        user.save()
        return CreateUser(user=user)

class UpdateUser(graphene.Mutation):
    class Arguments:
        id = graphene.Int(required=True)
        username = graphene.String()
        email = graphene.String()
        password = graphene.String()

    user = graphene.Field(UserType)

    def mutate(self, info, id, username=None, email=None, password=None):
        user = User.objects.get(id=id)
        if username:
            user.username = username
        if email:
            user.email = email
        if password:
            user.password = make_password(password)
        user.save()
        return UpdateUser(user=user)

class CreateForm(graphene.Mutation):
    class Arguments:
        name = graphene.String(required=True)
        is_private = graphene.Boolean()
        password = graphene.String()
        link = graphene.String()
        created_by_id = graphene.Int(required=True)

    form = graphene.Field(FormType)
    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, name, is_private=False, password=None, link=None, created_by_id=None):
        try:
            created_by = User.objects.get(id=created_by_id)
        except User.DoesNotExist:
            return CreateForm(success=False, message="User matching query does not exist.")

        form = Form(name=name, is_private=is_private, password=password, link=link, created_by=created_by)
        form.save()
        return CreateForm(form=form, success=True, message="Form created successfully.")

class CreateProcess(graphene.Mutation):
    class Arguments:
        name = graphene.String(required=True)
        is_private = graphene.Boolean()
        password = graphene.String()
        is_linear = graphene.Boolean()
        link = graphene.String()
        created_by_id = graphene.Int()

    process = graphene.Field(ProcessType)

    def mutate(self, info, name, is_private=False, password=None, is_linear=False, link=None, created_by_id=None):
        created_by = User.objects.get(id=created_by_id)
        process = Process(name=name, is_private=is_private, password=password, is_linear=is_linear, link=link, created_by=created_by)
        process.save()
        return CreateProcess(process=process)

class Mutation(graphene.ObjectType):
    create_user = CreateUser.Field()
    update_user = UpdateUser.Field()
    create_form = CreateForm.Field()
    create_process = CreateProcess.Field()

schema = graphene.Schema(query=Query, mutation=Mutation)
