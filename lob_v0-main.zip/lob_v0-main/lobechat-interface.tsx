"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Plus, MessageSquare, Settings, HelpCircle, Share2, FileText, ChevronDown, Compass } from "lucide-react"

// Import the new page components
import DiscoverPage from "./pages/discover-page"
import FileManagementPage from "./pages/file-management-page"
import ChatPage from "./pages/chat-page"

export default function Component() {
  const [currentPage, setCurrentPage] = useState("chat")

  const renderMainContent = () => {
    switch (currentPage) {
      case "discover":
        return <DiscoverPage />
      case "file-management":
        return <FileManagementPage />
      case "chat":
      default:
        return <ChatPage />
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Left Sidebar */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center text-white font-bold text-sm">
              🧠
            </div>
            <span className="text-xl font-semibold text-gray-900">LobeHub</span>
            <Button variant="ghost" size="icon" className="ml-auto">
              <Share2 className="w-4 h-4" />
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search assistants..." className="pl-10 bg-gray-50 border-gray-200" />
            <kbd className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">
              ⌘ K
            </kbd>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-2">
            <Card
              className={`mb-2 cursor-pointer ${currentPage === "chat" ? "bg-blue-50 border-blue-200" : "hover:bg-gray-50"}`}
              onClick={() => setCurrentPage("chat")}
            >
              <CardContent className="p-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center text-white text-sm">
                    🧠
                  </div>
                  <span className="font-medium text-gray-900">Just Chat</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="px-4 py-2">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Default List</span>
              <ChevronDown className="w-4 h-4 text-gray-400" />
            </div>

            <Button variant="ghost" className="w-full justify-start gap-2 text-gray-600 hover:bg-gray-50">
              <Plus className="w-4 h-4" />
              New Assistant
            </Button>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="p-4 border-t border-gray-100">
          <div className="flex justify-around">
            <Button
              variant="ghost"
              size="icon"
              className={currentPage === "chat" ? "bg-blue-100 text-blue-600" : ""}
              onClick={() => setCurrentPage("chat")}
            >
              <MessageSquare className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={currentPage === "discover" ? "bg-blue-100 text-blue-600" : ""}
              onClick={() => setCurrentPage("discover")}
            >
              <Compass className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={currentPage === "file-management" ? "bg-blue-100 text-blue-600" : ""}
              onClick={() => setCurrentPage("file-management")}
            >
              <FileText className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <HelpCircle className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      {renderMainContent()}
    </div>
  )
}
