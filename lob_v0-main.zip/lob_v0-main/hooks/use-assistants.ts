"use client"

import { useApi, useMutation } from "./use-api"
import { apiClient } from "@/lib/api"
import type { Assistant } from "@/types"

export function useAssistants(page = 1, limit = 10) {
  return useApi(() => apiClient.getAssistants(page, limit))
}

export function useAssistant(id: string) {
  return useApi(() => apiClient.getAssistant(id), {
    enabled: !!id,
  })
}

export function useCreateAssistant() {
  return useMutation((data: Partial<Assistant>) => apiClient.createAssistant(data))
}

export function useUpdateAssistant() {
  return useMutation(({ id, data }: { id: string; data: Partial<Assistant> }) => apiClient.updateAssistant(id, data))
}

export function useDeleteAssistant() {
  return useMutation((id: string) => apiClient.deleteAssistant(id))
}
