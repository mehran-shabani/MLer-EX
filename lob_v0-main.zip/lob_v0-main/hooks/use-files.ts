"use client"

import { useApi, useMutation } from "./use-api"
import { apiClient } from "@/lib/api"

export function useFiles(page = 1, limit = 10) {
  return useApi(() => apiClient.getFiles(page, limit))
}

export function useFileUpload() {
  return useMutation((file: File) => apiClient.uploadFile(file))
}
