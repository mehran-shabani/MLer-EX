"use client"

import { useState, useEffect, useCallback } from "react"
import { useApi, useMutation } from "./use-api"
import { apiClient } from "@/lib/api"
import type { Message } from "@/types"

export function useChats(page = 1, limit = 10) {
  return useApi(() => apiClient.getChats(page, limit))
}

export function useChat(id: string) {
  return useApi(() => apiClient.getChat(id), {
    enabled: !!id,
  })
}

export function useCreateChat() {
  return useMutation(({ assistantId, title }: { assistantId: string; title?: string }) =>
    apiClient.createChat(assistantId, title),
  )
}

export function useSendMessage() {
  return useMutation(({ chatId, content }: { chatId: string; content: string }) =>
    apiClient.sendMessage(chatId, content),
  )
}

// Real-time chat hook with WebSocket simulation
export function useRealTimeChat(chatId: string) {
  const [messages, setMessages] = useState<Message[]>([])
  const [isConnected, setIsConnected] = useState(false)

  const addMessage = useCallback((message: Message) => {
    setMessages((prev) => [...prev, message])
  }, [])

  const sendMessage = useCallback(
    async (content: string) => {
      if (!chatId) return

      // Add user message immediately
      const userMessage: Message = {
        id: Date.now().toString(),
        chatId,
        role: "user",
        content,
        createdAt: new Date().toISOString(),
      }
      addMessage(userMessage)

      try {
        // Send to API
        const response = await apiClient.sendMessage(chatId, content)

        // Simulate AI response delay
        setTimeout(() => {
          const aiMessage: Message = {
            id: (Date.now() + 1).toString(),
            chatId,
            role: "assistant",
            content: `This is a simulated response to: "${content}"`,
            createdAt: new Date().toISOString(),
          }
          addMessage(aiMessage)
        }, 1000)
      } catch (error) {
        console.error("Failed to send message:", error)
      }
    },
    [chatId, addMessage],
  )

  useEffect(() => {
    if (chatId) {
      setIsConnected(true)
      // In a real app, you'd establish WebSocket connection here
    }

    return () => {
      setIsConnected(false)
    }
  }, [chatId])

  return {
    messages,
    isConnected,
    sendMessage,
    addMessage,
  }
}
