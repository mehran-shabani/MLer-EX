"use client"

import { useState, useEffect, useCallback } from "react"
import type { UseApiOptions } from "@/types"

export function useApi<T>(apiCall: () => Promise<T>, options: UseApiOptions = {}) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const { onSuccess, onError, enabled = true } = options

  const execute = useCallback(async () => {
    if (!enabled) return

    setLoading(true)
    setError(null)

    try {
      const result = await apiCall()
      setData(result)
      onSuccess?.(result)
    } catch (err) {
      const error = err as Error
      setError(error)
      onError?.(error)
    } finally {
      setLoading(false)
    }
  }, [apiCall, enabled, onSuccess, onError])

  useEffect(() => {
    execute()
  }, [execute])

  const refetch = useCallback(() => {
    execute()
  }, [execute])

  return {
    data,
    loading,
    error,
    refetch,
  }
}

export function useMutation<T, P>(mutationFn: (params: P) => Promise<T>, options: UseApiOptions = {}) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const { onSuccess, onError } = options

  const mutate = useCallback(
    async (params: P) => {
      setLoading(true)
      setError(null)

      try {
        const result = await mutationFn(params)
        setData(result)
        onSuccess?.(result)
        return result
      } catch (err) {
        const error = err as Error
        setError(error)
        onError?.(error)
        throw error
      } finally {
        setLoading(false)
      }
    },
    [mutationFn, onSuccess, onError],
  )

  return {
    data,
    loading,
    error,
    mutate,
  }
}
