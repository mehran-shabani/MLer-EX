// API Client Configuration
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "/api"

type User = {}

type Assistant = {}

type Chat = {}

type Message = {}

type FileUpload = {}

interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
}

class ApiClient {
  private baseURL: string
  private token: string | null = null

  constructor(baseURL: string) {
    this.baseURL = baseURL
    this.token = typeof window !== "undefined" ? localStorage.getItem("auth_token") : null
  }

  setToken(token: string) {
    this.token = token
    if (typeof window !== "undefined") {
      localStorage.setItem("auth_token", token)
    }
  }

  clearToken() {
    this.token = null
    if (typeof window !== "undefined") {
      localStorage.removeItem("auth_token")
    }
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseURL}${endpoint}`
    const headers: HeadersInit = {
      "Content-Type": "application/json",
      ...options.headers,
    }

    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`
    }

    const response = await fetch(url, {
      ...options,
      headers,
    })

    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: "Network error" }))
      throw new Error(error.message || `HTTP ${response.status}`)
    }

    return response.json()
  }

  // Auth endpoints
  async login(email: string, password: string) {
    return this.request<{ user: User; token: string }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    })
  }

  async register(name: string, email: string, password: string) {
    return this.request<{ user: User; token: string }>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ name, email, password }),
    })
  }

  async logout() {
    return this.request("/auth/logout", { method: "POST" })
  }

  async getProfile() {
    return this.request<User>("/auth/profile")
  }

  // Assistant endpoints
  async getAssistants(page = 1, limit = 10) {
    return this.request<PaginatedResponse<Assistant>>(`/assistants?page=${page}&limit=${limit}`)
  }

  async getAssistant(id: string) {
    return this.request<Assistant>(`/assistants/${id}`)
  }

  async createAssistant(data: Partial<Assistant>) {
    return this.request<Assistant>("/assistants", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateAssistant(id: string, data: Partial<Assistant>) {
    return this.request<Assistant>(`/assistants/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteAssistant(id: string) {
    return this.request(`/assistants/${id}`, { method: "DELETE" })
  }

  // Chat endpoints
  async getChats(page = 1, limit = 10) {
    return this.request<PaginatedResponse<Chat>>(`/chats?page=${page}&limit=${limit}`)
  }

  async getChat(id: string) {
    return this.request<Chat>(`/chats/${id}`)
  }

  async createChat(assistantId: string, title?: string) {
    return this.request<Chat>("/chats", {
      method: "POST",
      body: JSON.stringify({ assistantId, title }),
    })
  }

  async sendMessage(chatId: string, content: string) {
    return this.request<Message>(`/chats/${chatId}/messages`, {
      method: "POST",
      body: JSON.stringify({ content }),
    })
  }

  // File endpoints
  async uploadFile(file: File) {
    const formData = new FormData()
    formData.append("file", file)

    return fetch(`${this.baseURL}/files/upload`, {
      method: "POST",
      headers: {
        Authorization: this.token ? `Bearer ${this.token}` : "",
      },
      body: formData,
    }).then((res) => res.json())
  }

  async getFiles(page = 1, limit = 10) {
    return this.request<PaginatedResponse<FileUpload>>(`/files?page=${page}&limit=${limit}`)
  }
}

export const apiClient = new ApiClient(API_BASE_URL)
