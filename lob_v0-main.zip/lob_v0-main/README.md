# AI Assistant Platform

A comprehensive web application for managing AI assistants with real-time chat capabilities, user authentication, and file management.

## Features

### 🔐 Authentication System
- User registration and login
- JWT-based authentication
- Protected routes and API endpoints
- Session management with automatic token refresh

### 🤖 Assistant Management
- Create custom AI assistants with specific personalities
- Configure different AI models (GPT-4, GPT-3.5, Claude)
- Tag-based organization and filtering
- Public/private assistant sharing

### 💬 Real-time Chat
- WebSocket-based real-time messaging
- Message history and persistence
- Multiple chat sessions
- File attachments and media support

### 📁 File Management
- File upload and storage
- Multiple file type support
- Integration with chat conversations
- File sharing and permissions

### 🎨 Modern UI/UX
- Responsive design for all devices
- Dark/light mode support
- Intuitive navigation and layout
- Accessibility-compliant components

## Architecture

### Frontend Architecture
\`\`\`
├── app/                    # Next.js App Router
│   ├── auth/              # Authentication pages
│   ├── dashboard/         # Main application
│   └── api/               # API routes
├── components/            # Reusable UI components
│   ├── auth/             # Authentication components
│   ├── chat/             # Chat interface components
│   ├── assistants/       # Assistant management
│   └── layout/           # Layout components
├── contexts/             # React Context providers
├── hooks/                # Custom React hooks
├── lib/                  # Utility libraries
└── types/                # TypeScript type definitions
\`\`\`

### Key Technologies
- **Next.js 14** - Full-stack React framework
- **TypeScript** - Type safety and developer experience
- **Tailwind CSS** - Utility-first styling
- **Radix UI** - Accessible component primitives
- **React Context** - Global state management
- **Custom Hooks** - Reusable logic and API integration

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn package manager

### Installation

1. Clone the repository:
\`\`\`bash
git clone <repository-url>
cd ai-assistant-platform
\`\`\`

2. Install dependencies:
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables:
\`\`\`bash
cp .env.example .env.local
\`\`\`

4. Start the development server:
\`\`\`bash
npm run dev
\`\`\`

5. Open [http://localhost:3000](http://localhost:3000) in your browser.

### Demo Credentials
- Email: `demo@example.com`
- Password: `password123`

## API Documentation

### Authentication Endpoints

#### POST /api/auth/login
Login with email and password.

**Request Body:**
\`\`\`json
{
  "email": "user@example.com",
  "password": "password123"
}
\`\`\`

**Response:**
\`\`\`json
{
  "user": {
    "id": "1",
    "name": "John Doe",
    "email": "user@example.com"
  },
  "token": "jwt-token-here"
}
\`\`\`

#### POST /api/auth/register
Register a new user account.

**Request Body:**
\`\`\`json
{
  "name": "John Doe",
  "email": "user@example.com",
  "password": "password123"
}
\`\`\`

### Assistant Endpoints

#### GET /api/assistants
Get paginated list of assistants.

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)

#### POST /api/assistants
Create a new assistant.

**Request Body:**
\`\`\`json
{
  "name": "Code Assistant",
  "description": "Helps with programming",
  "model": "gpt-4",
  "systemPrompt": "You are a helpful coding assistant.",
  "tags": ["coding", "programming"],
  "isPublic": false
}
\`\`\`

### Chat Endpoints

#### GET /api/chats
Get user's chat sessions.

#### POST /api/chats
Create a new chat session.

#### POST /api/chats/:id/messages
Send a message in a chat session.

## Custom Hooks

### useAuth()
Manages user authentication state and provides login/logout functions.

\`\`\`typescript
const { user, isAuthenticated, login, logout, isLoading } = useAuth()
\`\`\`

### useApi(apiCall, options)
Generic hook for API calls with loading states and error handling.

\`\`\`typescript
const { data, loading, error, refetch } = useApi(() => apiClient.getAssistants())
\`\`\`

### useMutation(mutationFn, options)
Hook for API mutations (POST, PUT, DELETE operations).

\`\`\`typescript
const { mutate, loading, error } = useMutation(
  (data) => apiClient.createAssistant(data)
)
\`\`\`

### useRealTimeChat(chatId)
Manages real-time chat functionality with WebSocket connection.

\`\`\`typescript
const { messages, isConnected, sendMessage } = useRealTimeChat(chatId)
\`\`\`

## Component Library

### Authentication Components
- `LoginForm` - User login interface
- `RegisterForm` - User registration interface

### Chat Components
- `ChatInterface` - Main chat UI with message history
- `MessageBubble` - Individual message display

### Assistant Components
- `AssistantCard` - Assistant preview and actions
- `CreateAssistantDialog` - Assistant creation form

### Layout Components
- `Sidebar` - Navigation and chat history
- `Header` - Top navigation bar

## State Management

The application uses React Context for global state management:

### AuthContext
Manages user authentication state, login/logout functions, and token management.

### API Client
Centralized API client with automatic token handling and request/response interceptors.

## Deployment

### Environment Variables
\`\`\`bash
NEXT_PUBLIC_API_URL=http://localhost:3000/api
DATABASE_URL=your-database-url
JWT_SECRET=your-jwt-secret
\`\`\`

### Build and Deploy
\`\`\`bash
npm run build
npm start
\`\`\`

## Future Enhancements

### Planned Features
- [ ] Voice message support
- [ ] Advanced file processing (PDF, images)
- [ ] Assistant marketplace
- [ ] Team collaboration features
- [ ] Advanced analytics and usage tracking
- [ ] Mobile app (React Native)

### Technical Improvements
- [ ] Database integration (PostgreSQL/MongoDB)
- [ ] Redis for session management
- [ ] WebSocket server for real-time features
- [ ] File storage (AWS S3/CloudFlare R2)
- [ ] Email notifications
- [ ] Rate limiting and security enhancements

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions:
- Create an issue on GitHub
- Email: support@ai-assistant-platform.com
- Documentation: [docs.ai-assistant-platform.com](https://docs.ai-assistant-platform.com)
