"use client"

import type React from "react"
import { createContext, useContext, useEffect, useReducer } from "react"
import type { User, AuthState } from "@/types"
import { apiClient } from "@/lib/api"

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

type AuthAction =
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_USER"; payload: User | null }
  | { type: "SET_ERROR"; payload: string | null }

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, isLoading: action.payload }
    case "SET_USER":
      return {
        ...state,
        user: action.payload,
        isAuthenticated: !!action.payload,
        isLoading: false,
      }
    case "SET_ERROR":
      return { ...state, isLoading: false }
    default:
      return state
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, {
    user: null,
    isAuthenticated: false,
    isLoading: true,
  })

  useEffect(() => {
    // Check for existing session on mount
    const initAuth = async () => {
      try {
        const token = localStorage.getItem("auth_token")
        if (token) {
          apiClient.setToken(token)
          const user = await apiClient.getProfile()
          dispatch({ type: "SET_USER", payload: user })
        } else {
          dispatch({ type: "SET_USER", payload: null })
        }
      } catch (error) {
        console.error("Auth initialization error:", error)
        dispatch({ type: "SET_USER", payload: null })
      }
    }

    initAuth()
  }, [])

  const login = async (email: string, password: string) => {
    dispatch({ type: "SET_LOADING", payload: true })
    try {
      const response = await apiClient.login(email, password)
      apiClient.setToken(response.token)
      dispatch({ type: "SET_USER", payload: response.user })
    } catch (error) {
      dispatch({ type: "SET_ERROR", payload: (error as Error).message })
      throw error
    }
  }

  const register = async (name: string, email: string, password: string) => {
    dispatch({ type: "SET_LOADING", payload: true })
    try {
      const response = await apiClient.register(name, email, password)
      apiClient.setToken(response.token)
      dispatch({ type: "SET_USER", payload: response.user })
    } catch (error) {
      dispatch({ type: "SET_ERROR", payload: (error as Error).message })
      throw error
    }
  }

  const logout = async () => {
    try {
      await apiClient.logout()
    } catch (error) {
      console.error("Logout error:", error)
    } finally {
      apiClient.clearToken()
      dispatch({ type: "SET_USER", payload: null })
    }
  }

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
