// Core Types
export interface User {
  id: string
  email: string
  name: string
  avatar?: string
  createdAt: string
  updatedAt: string
}

export interface Assistant {
  id: string
  name: string
  description: string
  avatar: string
  model: string
  systemPrompt: string
  userId: string
  isPublic: boolean
  tags: string[]
  createdAt: string
  updatedAt: string
}

export interface Chat {
  id: string
  title: string
  assistantId: string
  userId: string
  messages: Message[]
  createdAt: string
  updatedAt: string
}

export interface Message {
  id: string
  chatId: string
  role: "user" | "assistant" | "system"
  content: string
  metadata?: {
    model?: string
    tokens?: number
    timestamp?: string
  }
  createdAt: string
}

export interface FileUpload {
  id: string
  name: string
  size: number
  type: string
  url: string
  userId: string
  createdAt: string
}

// API Response Types
export interface ApiResponse<T> {
  data: T
  message?: string
  error?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

// Hook Types
export interface UseApiOptions {
  onSuccess?: (data: any) => void
  onError?: (error: Error) => void
  enabled?: boolean
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
}
