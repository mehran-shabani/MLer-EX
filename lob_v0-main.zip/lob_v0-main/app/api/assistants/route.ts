import { type NextRequest, NextResponse } from "next/server"

// Mock assistants data
const mockAssistants = [
  {
    id: "1",
    name: "Code Assistant",
    description: "Helps with programming and code review",
    avatar: "💻",
    model: "gpt-4",
    systemPrompt: "You are a helpful coding assistant.",
    userId: "1",
    isPublic: false,
    tags: ["coding", "programming", "development"],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "2",
    name: "Writing Assistant",
    description: "Helps with writing and content creation",
    avatar: "✍️",
    model: "gpt-4",
    systemPrompt: "You are a helpful writing assistant.",
    userId: "1",
    isPublic: false,
    tags: ["writing", "content", "editing"],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")

  // Mock pagination
  const startIndex = (page - 1) * limit
  const endIndex = startIndex + limit
  const paginatedAssistants = mockAssistants.slice(startIndex, endIndex)

  return NextResponse.json({
    data: paginatedAssistants,
    pagination: {
      page,
      limit,
      total: mockAssistants.length,
      totalPages: Math.ceil(mockAssistants.length / limit),
    },
  })
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    const newAssistant = {
      id: Date.now().toString(),
      ...data,
      userId: "1", // Mock user ID
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    mockAssistants.push(newAssistant)

    return NextResponse.json(newAssistant)
  } catch (error) {
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
