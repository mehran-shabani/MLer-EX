"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useAssistants } from "@/hooks/use-assistants"
import { useCreateChat } from "@/hooks/use-chat"
import { Sidebar } from "@/components/layout/sidebar"
import { AssistantCard } from "@/components/assistants/assistant-card"
import { CreateAssistantDialog } from "@/components/assistants/create-assistant-dialog"
import { ChatInterface } from "@/components/chat/chat-interface"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { Assistant } from "@/types"
import { Loader2 } from "lucide-react"

export default function DashboardPage() {
  const [currentView, setCurrentView] = useState("assistants")
  const [selectedChat, setSelectedChat] = useState<string | null>(null)

  const { user } = useAuth()
  const { data: assistantsData, loading: assistantsLoading, refetch } = useAssistants()
  const { mutate: createChat } = useCreateChat()

  const handleStartChat = async (assistant: Assistant) => {
    try {
      const chat = await createChat({
        assistantId: assistant.id,
        title: `Chat with ${assistant.name}`,
      })
      setSelectedChat(chat.id)
      setCurrentView(`chat-${chat.id}`)
    } catch (error) {
      console.error("Failed to create chat:", error)
    }
  }

  const handleEditAssistant = (assistant: Assistant) => {
    // TODO: Implement edit functionality
    console.log("Edit assistant:", assistant)
  }

  const handleDeleteAssistant = (assistant: Assistant) => {
    // TODO: Implement delete functionality
    console.log("Delete assistant:", assistant)
  }

  const renderMainContent = () => {
    if (currentView.startsWith("chat-")) {
      const chatId = currentView.replace("chat-", "")
      const assistant = assistantsData?.data.find((a) => a.id === selectedChat)

      return <ChatInterface chatId={chatId} assistantName={assistant?.name || "Assistant"} />
    }

    switch (currentView) {
      case "assistants":
        return (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold">Your Assistants</h1>
                <p className="text-gray-600">Manage and chat with your AI assistants</p>
              </div>
              <CreateAssistantDialog onSuccess={refetch} />
            </div>

            {assistantsLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {assistantsData?.data.map((assistant) => (
                  <AssistantCard
                    key={assistant.id}
                    assistant={assistant}
                    onChat={handleStartChat}
                    onEdit={handleEditAssistant}
                    onDelete={handleDeleteAssistant}
                  />
                ))}
              </div>
            )}

            {!assistantsLoading && assistantsData?.data.length === 0 && (
              <Card className="text-center py-12">
                <CardHeader>
                  <CardTitle>No Assistants Yet</CardTitle>
                  <CardDescription>Create your first AI assistant to get started</CardDescription>
                </CardHeader>
                <CardContent>
                  <CreateAssistantDialog onSuccess={refetch} />
                </CardContent>
              </Card>
            )}
          </div>
        )

      case "files":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-6">File Management</h1>
            <Card>
              <CardContent className="p-6">
                <p className="text-gray-600">File management features coming soon...</p>
              </CardContent>
            </Card>
          </div>
        )

      case "settings":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-6">Settings</h1>
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Manage your account preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Name</label>
                    <p className="text-gray-600">{user?.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Email</label>
                    <p className="text-gray-600">{user?.email}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      default:
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-6">Welcome to AI Assistant Platform</h1>
            <Card>
              <CardContent className="p-6">
                <p className="text-gray-600">Select a section from the sidebar to get started.</p>
              </CardContent>
            </Card>
          </div>
        )
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <div className="flex-1 overflow-hidden">{renderMainContent()}</div>
    </div>
  )
}
