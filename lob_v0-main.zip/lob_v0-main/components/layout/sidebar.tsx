"use client"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/contexts/auth-context"
import { useChats } from "@/hooks/use-chat"
import { MessageSquare, Bot, FileText, Settings, LogOut, Plus } from "lucide-react"

interface SidebarProps {
  currentView: string
  onViewChange: (view: string) => void
}

export function Sidebar({ currentView, onViewChange }: SidebarProps) {
  const { user, logout } = useAuth()
  const { data: chatsData } = useChats()

  const menuItems = [
    { id: "chat", label: "Chat", icon: MessageSquare },
    { id: "assistants", label: "Assistants", icon: Bot },
    { id: "files", label: "Files", icon: FileText },
    { id: "settings", label: "Settings", icon: Settings },
  ]

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold">
            AI
          </div>
          <span className="font-semibold text-lg">Assistant Platform</span>
        </div>
      </div>

      {/* Navigation */}
      <div className="p-4">
        <div className="space-y-1">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant={currentView === item.id ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => onViewChange(item.id)}
            >
              <item.icon className="mr-2 h-4 w-4" />
              {item.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Recent Chats */}
      <div className="flex-1 px-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-gray-500">Recent Chats</h3>
          <Button variant="ghost" size="icon" className="h-6 w-6">
            <Plus className="h-3 w-3" />
          </Button>
        </div>

        <ScrollArea className="h-64">
          <div className="space-y-1">
            {chatsData?.data.map((chat) => (
              <Button
                key={chat.id}
                variant="ghost"
                className="w-full justify-start text-left h-auto p-2"
                onClick={() => onViewChange(`chat-${chat.id}`)}
              >
                <div className="truncate">
                  <div className="text-sm font-medium truncate">{chat.title}</div>
                  <div className="text-xs text-gray-500">{new Date(chat.updatedAt).toLocaleDateString()}</div>
                </div>
              </Button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* User Profile */}
      <div className="p-4 border-t">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            {user?.name?.[0]?.toUpperCase() || "U"}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium truncate">{user?.name}</div>
            <div className="text-xs text-gray-500 truncate">{user?.email}</div>
          </div>
        </div>

        <Button
          variant="ghost"
          className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
          onClick={logout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </div>
  )
}
