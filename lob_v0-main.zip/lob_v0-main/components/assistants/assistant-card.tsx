"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Assistant } from "@/types"
import { MessageSquare, Settings, Trash2 } from "lucide-react"

interface AssistantCardProps {
  assistant: Assistant
  onChat: (assistant: Assistant) => void
  onEdit: (assistant: Assistant) => void
  onDelete: (assistant: Assistant) => void
}

export function AssistantCard({ assistant, onChat, onEdit, onDelete }: AssistantCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white text-xl">
              {assistant.avatar || "🤖"}
            </div>
            <div>
              <CardTitle className="text-lg">{assistant.name}</CardTitle>
              <CardDescription className="text-sm">Model: {assistant.model}</CardDescription>
            </div>
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" onClick={() => onEdit(assistant)}>
              <Settings className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => onDelete(assistant)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{assistant.description}</p>

        <div className="flex flex-wrap gap-1 mb-4">
          {assistant.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>

        <Button onClick={() => onChat(assistant)} className="w-full">
          <MessageSquare className="mr-2 h-4 w-4" />
          Start Chat
        </Button>
      </CardContent>
    </Card>
  )
}
