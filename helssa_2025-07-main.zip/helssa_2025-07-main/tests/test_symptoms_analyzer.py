from chatbot_pro.knowledge.symptoms_analyzer import SymptomsAnalyzer


def test_extract_keywords_and_systems():
    analyzer = SymptomsAnalyzer()
    text = "سرفه و درد شکم و تهوع"
    assert set(analyzer.extract_keywords(text)) == {"سرفه", "درد شکم", "تهوع", "درد"}


def test_emergency_level_always_zero():
    analyzer = SymptomsAnalyzer()
    assert analyzer.emergency_level("تنگی نفس شدید") == 0
    assert analyzer.is_emergency("تنگی نفس شدید") is False
