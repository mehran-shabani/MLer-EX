from chatbot_pro.agents.base_agent import BaseAgent
import types


class SimpleAgent(BaseAgent):
    domain_name = "simple"
    trigger_keywords = ["simple"]

    def _build_domain_prompt(self, message, patient_info):
        return f"{patient_info['age']}:{message}"


def test_base_agent_consult(dummy_llm_obj):
    agent = SimpleAgent()
    history = [{"sender": "patient", "content": "old"}]
    result = agent.consult("new", {"age": 30}, history)
    assert result == "stub reply"
    assert len(dummy_llm_obj.chats) == 1
    messages = dummy_llm_obj.chats[0]
    assert messages[0].role == "system"
    assert messages[-1].content == "new"
