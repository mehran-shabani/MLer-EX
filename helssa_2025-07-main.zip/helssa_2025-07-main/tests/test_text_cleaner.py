from chatbot_pro.utils.text_cleaner import refine_text


def test_refine_text_empty():
    assert refine_text("") == ""


def test_refine_text_cleanup():
    inp = "مي  روم ... سلام  ,  خوبم"
    assert refine_text(inp) == "می‌روم… سلام, خوبم."
