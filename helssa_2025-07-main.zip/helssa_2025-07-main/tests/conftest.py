import sys
import types
import importlib.util
from pathlib import Path

# ----------------- Stub external dependencies -----------------
# Minimal stand-ins for llama_index classes used by the code
llms = types.ModuleType("llama_index.core.llms")
class ChatMessage:
    def __init__(self, role, content):
        self.role = role
        self.content = content
class MessageRole:
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
llms.ChatMessage = ChatMessage
llms.MessageRole = MessageRole
sys.modules["llama_index.core.llms"] = llms

# Dummy LLM used by BaseAgent
class DummyLLM:
    def __init__(self):
        self.chats = []

    def chat(self, messages):
        self.chats.append(messages)
        return types.SimpleNamespace(message=types.SimpleNamespace(content="stub reply"))

dummy_llm = DummyLLM()
llm_mod = types.ModuleType("chatbot_pro.utils.llm_config")
llm_mod.llm_config = types.SimpleNamespace(get_llm=lambda: dummy_llm)
sys.modules["chatbot_pro.utils.llm_config"] = llm_mod


# ----------------- Load chatbot_pro package -----------------
ROOT = Path(__file__).resolve().parents[1] / "api.medogram" / "chatbot_pro"

# Prepare empty package so relative imports succeed
pkg = types.ModuleType("chatbot_pro")
pkg.__path__ = [str(ROOT)]
sys.modules["chatbot_pro"] = pkg

# Create agents package placeholder
agents_dir = ROOT / "agents"
agents_pkg = types.ModuleType("chatbot_pro.agents")
agents_pkg.__path__ = [str(agents_dir)]
sys.modules["chatbot_pro.agents"] = agents_pkg

# Load base_agent first to build stubs
base_spec = importlib.util.spec_from_file_location(
    "chatbot_pro.agents.base_agent",
    agents_dir / "base_agent.py",
)
base_mod = importlib.util.module_from_spec(base_spec)
sys.modules["chatbot_pro.agents.base_agent"] = base_mod
base_spec.loader.exec_module(base_mod)

# Stub missing ObstetricsGynecologyAgent
obgyn_mod = types.ModuleType("chatbot_pro.agents.obgyn_agent")
class ObstetricsGynecologyAgent(base_mod.BaseAgent):
    domain_name = "obgyn"
    trigger_keywords = ["بارداری"]
    def _build_domain_prompt(self, message, patient_info):
        return f"OBGYN:{message}"
obgyn_mod.ObstetricsGynecologyAgent = ObstetricsGynecologyAgent
sys.modules["chatbot_pro.agents.obgyn_agent"] = obgyn_mod

# Alias for misspelled psychiatry agent file
psych_path = agents_dir / "psychaitry_agent.py"
psych_spec = importlib.util.spec_from_file_location(
    "chatbot_pro.agents.psychiatry_agent", psych_path
)
psych_mod = importlib.util.module_from_spec(psych_spec)
sys.modules["chatbot_pro.agents.psychiatry_agent"] = psych_mod
psych_spec.loader.exec_module(psych_mod)

# Load package itself
spec = importlib.util.spec_from_file_location(
    "chatbot_pro",
    ROOT / "__init__.py",
    submodule_search_locations=[str(ROOT)],
)
chatbot_pro = importlib.util.module_from_spec(spec)
sys.modules["chatbot_pro"] = chatbot_pro
spec.loader.exec_module(chatbot_pro)

import pytest

@pytest.fixture
def dummy_llm_obj():
    dummy_llm.chats.clear()
    return dummy_llm
