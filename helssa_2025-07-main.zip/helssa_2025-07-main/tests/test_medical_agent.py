import importlib
from chatbot_pro.agents import medical_agent


def test_selects_specialist(monkeypatch):
    agent = medical_agent.MedicalAgent()

    # patch analyzer to deterministic outputs
    monkeypatch.setattr(agent.analyzer, "extract_keywords", lambda text: ["درد"])
    monkeypatch.setattr(agent.analyzer, "emergency_level", lambda text: 2)

    for ag in agent.specialists:
        monkeypatch.setattr(ag, "consult", lambda m, p, h, dom=ag.domain_name: dom)

    res = agent.consult("سنگ کلیه", {"age": 40}, [])
    assert res["domain"] == "nephro_urology"
    assert res["reply"] == "nephro_urology"
    assert res["symptoms"] == ["درد"]
    assert res["emergency"] is False
    assert res["emergency_level"] == 2


def test_fallback_to_family(monkeypatch):
    agent = medical_agent.MedicalAgent()
    monkeypatch.setattr(agent.analyzer, "extract_keywords", lambda text: [])
    monkeypatch.setattr(agent.analyzer, "emergency_level", lambda text: 0)
    for ag in agent.specialists:
        monkeypatch.setattr(ag, "consult", lambda m, p, h, dom=ag.domain_name: dom)
    res = agent.consult("پیام عادی", {}, [])
    assert res["domain"] == "family"
