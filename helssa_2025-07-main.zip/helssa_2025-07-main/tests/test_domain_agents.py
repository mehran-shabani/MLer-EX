import importlib
from chatbot_pro.agents import base_agent

AGENT_MODULES = [
    "chatbot_pro.agents.family_agent",
    "chatbot_pro.agents.obgyn_agent",
    "chatbot_pro.agents.internal_agent",
    "chatbot_pro.agents.psychaitry_agent",
    "chatbot_pro.agents.cardiology_agent",
    "chatbot_pro.agents.surgery_agent",
    "chatbot_pro.agents.ent_derm_agent",
    "chatbot_pro.agents.neurology_agent",
    "chatbot_pro.agents.nephrology_agent",
    "chatbot_pro.agents.gastro_agent",
    "chatbot_pro.agents.rheumatology_agent",
]


def _get_agent_cls(module_name):
    mod = importlib.import_module(module_name)
    for value in mod.__dict__.values():
        if isinstance(value, type) and issubclass(value, base_agent.BaseAgent) and value is not base_agent.BaseAgent:
            return value
    raise RuntimeError("agent class not found")


def test_domain_prompts():
    info = {"age": 30, "gender": "x", "bmi": 25, "chronic_conditions": []}
    for module_name in AGENT_MODULES:
        cls = _get_agent_cls(module_name)
        agent = cls()
        prompt = agent._build_domain_prompt("پیام", info)
        assert isinstance(prompt, str)
        assert "پیام" in prompt
