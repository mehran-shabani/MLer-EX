// profile_screen.dart
// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:helssa/utils/avatar_manager.dart';
import '../../utils/snackbar.dart';
import 'profile_avatar.dart';
import 'profile_payment.dart';
import 'package:url_launcher/url_launcher.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  late String accessToken;
  Map<String, dynamic> profile = {};
  late AvatarManager avatarManager;
  double walletAmount = 0.0;
  bool isLoading = true;
  bool isEditing = false;
  bool isAvatarLoading = true;
  Map<String, dynamic> errors = {};
  String? paymentUrl;
  final ValueNotifier<int?> selectedAmount = ValueNotifier<int?>(null);
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  bool isWalletRefreshActive = false;

  @override
  void initState() {
    super.initState();
    _initAvatarManager()
        .then((_) => _loadAccessToken())
        .then((_) => _fetchProfileAndWallet());
  }

  Future<void> _initAvatarManager() async {
    final prefs = await SharedPreferences.getInstance();
    avatarManager = AvatarManager(prefs);
    setState(() => isAvatarLoading = false);
  }

  Future<void> _loadAccessToken() async {
    final prefs = await SharedPreferences.getInstance();
    accessToken = prefs.getString('access_token') ?? '';
    if (accessToken.isEmpty) {
      CustomSnackBar.show('خطا: دسترسی نامعتبر!', context, isError: true);
    }
  }

  // ░░░  تغییر اصلی: استفاده از POST و مسیرهای profileios / boxios  ░░░
  Future<void> _fetchProfileAndWallet() async {
    setState(() => isLoading = true);
    try {
      final responses = await Future.wait([
        http.post(
          Uri.parse('https://api.medogram.ir/api/profileios/'),
          headers: {'Authorization': 'Bearer $accessToken'},
        ),
        http.post(
          Uri.parse('https://api.medogram.ir/api/boxios'),
          headers: {'Authorization': 'Bearer $accessToken'},
        ),
      ]);

      if (responses[0].statusCode == 200 && responses[1].statusCode == 200) {
        setState(() {
          profile = json.decode(responses[0].body);
          walletAmount =
              json.decode(responses[1].body)['amount'].toDouble();
          _usernameController.text = profile['username'] ?? '';
          _emailController.text = profile['email'] ?? '';
          errors = {};
        });
        final username = profile['username'] ?? '';
        if (username.isNotEmpty &&
            !avatarManager.isCurrentAvatarForUsername(username)) {
          await avatarManager.generateAvatarFromUsername(username);
          setState(() {});
        }
      } else {
        CustomSnackBar.show(
            'خطا در دریافت اطلاعات پروفایل یا کیف پول!', context,
            isError: true);
      }
    } catch (e) {
      CustomSnackBar.show(
          'خطا در دریافت اطلاعات پروفایل یا کیف پول!', context,
          isError: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('https://api.medogram.ir/api/profile/update/'),
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode({
          'username': _usernameController.text,
          'email': _emailController.text,
        }),
      );

      if (response.statusCode == 201) {
        setState(() {
          profile = json.decode(response.body);
          isEditing = false;
          errors = {};
        });
        final newUsername = profile['username'] ?? '';
        if (newUsername.isNotEmpty) {
          await avatarManager.generateAvatarFromUsername(newUsername);
          setState(() {});
        }
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('پروفایل و آواتار با موفقیت به‌روزرسانی شدند!'),
            backgroundColor: Colors.green.shade700,
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else if (response.statusCode == 400) {
        setState(() => errors = json.decode(response.body));
      } else {
        CustomSnackBar.show('خطا در به‌روزرسانی پروفایل!', context,
            isError: true);
      }
    } catch (e) {
      CustomSnackBar.show('خطا در به‌روزرسانی پروفایل!', context,
          isError: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('پروفایل کاربری'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'آواتار تصادفی',
            onPressed: () async {
              await avatarManager.generateRandomAvatar();
              setState(() {});
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('آواتار تصادفی جدید تولید شد!'),
                  backgroundColor: Colors.blue.shade700,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
        ],
      ),
      body: isLoading || isAvatarLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildProfileView(),
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
    );
  }

  Widget _buildProfileView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          ProfileAvatar(
            avatarManager: avatarManager,
            profile: profile,
            onAvatarChanged: () => setState(() {}),
          ),
          const SizedBox(height: 16),
          Text(profile['username'] ?? '',
              style:
                  const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const Divider(height: 32, thickness: 1),
          _buildWalletInfo(),
          const SizedBox(height: 24),
          isEditing ? _buildEditForm() : _buildProfileInfo(),
          const SizedBox(height: 24),
          _buildActionButtons(),
          const SizedBox(height: 24),
          ProfilePayment(
            isLoading: isLoading,
            paymentUrl: paymentUrl,
            selectedAmount: selectedAmount,
            onGetPaymentLink: _getPaymentLink,
            onLaunchPaymentUrl: _launchPaymentUrl,
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildWalletInfo() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.blueAccent.shade100,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          IconButton(
            icon: Icon(
              Icons.sync,
              color: isWalletRefreshActive ? Colors.red : Colors.white,
            ),
            tooltip: isWalletRefreshActive
                ? 'بروزرسانی موجودی'
                : 'پس از پرداخت بروزرسانی کنید',
            onPressed: isWalletRefreshActive
                ? () async {
                    setState(() => isLoading = true);
                    await _fetchProfileAndWallet();
                    setState(() => isWalletRefreshActive = false);
                  }
                : null,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'موجودی: ${walletAmount.toStringAsFixed(0)} ﷼',
              style: TextStyle(
                fontSize: 18,
                color:
                    walletAmount < 400000 ? Colors.red : Colors.greenAccent,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(width: 8),
          const Icon(
            Icons.account_balance_wallet,
            color: Colors.white,
            size: 26,
          ),
        ],
      ),
    );
  }

  Widget _buildProfileInfo() {
    return Column(
      children: [
        ListTile(
          leading: const Icon(Icons.person),
          title: const Text('نام کاربری'),
          subtitle: Text(profile['username'] ?? ''),
        ),
        ListTile(
          leading: const Icon(Icons.email),
          title: const Text('ایمیل'),
          subtitle: Text(profile['email'] ?? ''),
        ),
      ],
    );
  }

  Widget _buildEditForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _usernameController,
            decoration: InputDecoration(
              labelText: 'نام کاربری',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12)),
              errorText: errors['username'] != null
                  ? errors['username'][0]
                  : null,
              prefixIcon: const Icon(Icons.person),
              helperText:
                  'تغییر نام کاربری آواتار شما را به‌روزرسانی می‌کند',
            ),
            validator: (value) => value == null || value.isEmpty
                ? 'لطفاً نام کاربری را وارد کنید'
                : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _emailController,
            decoration: InputDecoration(
              labelText: 'ایمیل',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12)),
              errorText:
                  errors['email'] != null ? errors['email'][0] : null,
              prefixIcon: const Icon(Icons.email),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'لطفاً ایمیل را وارد کنید';
              }
              if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                return 'لطفاً یک ایمیل معتبر وارد کنید';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (isEditing)
          ElevatedButton.icon(
            onPressed: isLoading ? null : _updateProfile,
            icon: const Icon(Icons.save),
            label: const Text('ذخیره'),
            style: ElevatedButton.styleFrom(
              padding:
                  const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
        if (isEditing) ...[
          const SizedBox(width: 16),
          ElevatedButton.icon(
            onPressed: () => setState(() {
              isEditing = false;
              errors = {};
            }),
            icon: const Icon(Icons.cancel),
            label: const Text('لغو'),
            style: ElevatedButton.styleFrom(
              padding:
                  const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              backgroundColor: Colors.grey,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
        if (!isEditing)
          ElevatedButton.icon(
            onPressed: () => setState(() => isEditing = true),
            icon: const Icon(Icons.edit),
            label: const Text('ویرایش پروفایل'),
            style: ElevatedButton.styleFrom(
              padding:
                  const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
      ],
    );
  }

  Future<String?> _getPaymentLink() async {
    if (selectedAmount.value == null || selectedAmount.value! <= 0) {
      CustomSnackBar.show('لطفا مبلغ معتبری را انتخاب کنید', context,
          isError: true);
      return null;
    }

    setState(() => isLoading = true);
    try {
      final response = await http.post(
        Uri.parse('https://api.medogram.ir/api/transaction/'),
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode({'amount': selectedAmount.value!}),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['payment_url'] != null) {
          setState(() => paymentUrl = data['payment_url']);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('لینک پرداخت با موفقیت ایجاد شد'),
              backgroundColor: Colors.green.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
          return data['payment_url'];
        } else {
          CustomSnackBar.show('لینک پرداخت در پاسخ سرور یافت نشد', context,
              isError: true);
          return null;
        }
      } else {
        final error = json.decode(response.body);
        CustomSnackBar.show(error['detail'] ?? 'خطا در دریافت لینک پرداخت',
            context,
            isError: true);
        return null;
      }
    } catch (e) {
      CustomSnackBar.show('خطا در برقراری ارتباط با سرور', context,
          isError: true);
      return null;
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _launchPaymentUrl() async {
    if (paymentUrl == null) return;
    final uri = Uri.parse(paymentUrl!);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      setState(() => isWalletRefreshActive = true);
    } else {
      CustomSnackBar.show('خطا در باز کردن لینک پرداخت!', context,
          isError: true);
    }
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    selectedAmount.dispose();
    super.dispose();
  }
}
