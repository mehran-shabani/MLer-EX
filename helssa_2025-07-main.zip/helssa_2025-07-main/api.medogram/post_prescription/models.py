from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class Prescription(models.Model):
    user       = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="prescriptions"
    )
    name       = models.CharField(max_length=150)
    is_active  = models.BooleanField(default=True)
    reorder    = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-created_at",)

    def __str__(self) -> str:
        return f"{self.name} (#{self.pk})"


class PrescriptionItem(models.Model):
    prescription = models.ForeignKey(
        Prescription, on_delete=models.CASCADE, related_name="items"
    )
    drug        = models.CharField(max_length=255)
    dose        = models.PositiveIntegerField()
    per_intake  = models.CharField(max_length=64, blank=True)
    frequency   = models.CharField(max_length=64, blank=True)
    count       = models.PositiveIntegerField(null=True, blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-created_at",)

    def __str__(self) -> str:
        return f"{self.drug} ({self.dose} mg)"
