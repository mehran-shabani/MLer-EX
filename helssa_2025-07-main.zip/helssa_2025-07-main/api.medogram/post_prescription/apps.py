from django.apps import AppConfig


class PostPrescriptionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "post_prescription"

    def ready(self) -> None:
        # رجیستر سیگنال‌ها
        from . import signals  # noqa: F401
