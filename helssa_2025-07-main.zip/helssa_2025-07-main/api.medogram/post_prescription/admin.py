from django.contrib import admin
from django.utils.html import format_html

from .models import Prescription, PrescriptionItem


class PrescriptionItemInline(admin.TabularInline):
    model = PrescriptionItem
    extra = 0


@admin.register(Prescription)
class PrescriptionAdmin(admin.ModelAdmin):
    list_display  = ("id", "user", "name", "active_circle", "reorder", "created_at")
    list_filter   = ("is_active", "created_at")
    search_fields = ("name", "user__username")
    readonly_fields = ("created_at",)
    inlines = (PrescriptionItemInline,)

    def active_circle(self, obj):
        color = "green" if obj.is_active else "red"
        return format_html('<span style="color:{};font-size:18px;">●</span>', color)
    active_circle.short_description = "Active"

    actions = ["activate", "deactivate", "reset_reorder"]

    def activate(self, request, queryset):   queryset.update(is_active=True)
    def deactivate(self, request, queryset): queryset.update(is_active=False)
    def reset_reorder(self, request, queryset): queryset.update(reorder=1)
    activate.short_description = "Set active"
    deactivate.short_description = "Set inactive"
    reset_reorder.short_description = "Reset reorder→1"
