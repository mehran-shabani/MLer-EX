from rest_framework import serializers
from .models import Prescription, PrescriptionItem


class PrescriptionItemSerializer(serializers.ModelSerializer):
    class Meta:
        model  = PrescriptionItem
        fields = (
            "id",
            "drug",
            "dose",
            "per_intake",
            "frequency",
            "count",
            "created_at",
        )
        read_only_fields = ("id", "created_at", "prescription")


class CreatePrescriptionSerializer(serializers.ModelSerializer):
    items = PrescriptionItemSerializer(many=True)

    class Meta:
        model  = Prescription
        fields = ("id", "name", "items")
        read_only_fields = ("id",)

    def create(self, validated_data):
        items_data = validated_data.pop("items")
        prescription = Prescription.objects.create(
            user=self.context["request"].user, **validated_data
        )
        PrescriptionItem.objects.bulk_create(
            [
                PrescriptionItem(prescription=prescription, **item)
                for item in items_data
            ]
        )
        return prescription


class PrescriptionSerializer(serializers.ModelSerializer):
    items = PrescriptionItemSerializer(many=True, read_only=True)

    class Meta:
        model  = Prescription
        fields = ("id", "name", "is_active", "reorder", "created_at", "items")
        read_only_fields = ("id", "is_active", "reorder", "created_at")
