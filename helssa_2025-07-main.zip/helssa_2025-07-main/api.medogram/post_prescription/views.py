from django.shortcuts import get_object_or_404
from django.db.models import F
from rest_framework import status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response

from .models import Prescription, PrescriptionItem
from .serializers import (
    CreatePrescriptionSerializer,
    PrescriptionSerializer,
    PrescriptionItemSerializer,
)

# -----------------------------------------------------------------
# 1) POST /prescription/create-order/
# -----------------------------------------------------------------
@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def create_order(request):
    serializer = CreatePrescriptionSerializer(
        data=request.data, context={"request": request}
    )
    if serializer.is_valid():
        prescription = serializer.save()
        return Response(
            PrescriptionSerializer(prescription).data,
            status=status.HTTP_201_CREATED,
        )
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# -----------------------------------------------------------------
# 2) PATCH /prescription/edit-drug/<int:order_id>/<int:item_id>/
# -----------------------------------------------------------------
@api_view(["PATCH"])
@permission_classes([permissions.IsAuthenticated])
def edit_drug(request, order_id, item_id):
    item = get_object_or_404(
        PrescriptionItem.objects.select_related("prescription"),
        pk=item_id,
        prescription__pk=order_id,
        prescription__user=request.user,
    )
    serializer = PrescriptionItemSerializer(item, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# -----------------------------------------------------------------
# 3) DELETE /prescription/delete-drug/<int:order_id>/<int:item_id>/
# -----------------------------------------------------------------
@api_view(["DELETE"])
@permission_classes([permissions.IsAuthenticated])
def delete_drug(request, order_id, item_id):
    item = get_object_or_404(
        PrescriptionItem.objects.select_related("prescription"),
        pk=item_id,
        prescription__pk=order_id,
        prescription__user=request.user,
    )
    item.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)


# -----------------------------------------------------------------
# 4) POST /prescription/add-drug/<int:order_id>/
# -----------------------------------------------------------------
@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def add_drug(request, order_id):
    prescription = get_object_or_404(
        Prescription, pk=order_id, user=request.user
    )
    serializer = PrescriptionItemSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save(prescription=prescription)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# -----------------------------------------------------------------
# 5) PATCH /prescription/edit-order/<int:order_id>/
# -----------------------------------------------------------------
@api_view(["PATCH"])
@permission_classes([permissions.IsAuthenticated])
def edit_order(request, order_id):
    prescription = get_object_or_404(
        Prescription, pk=order_id, user=request.user
    )
    serializer = PrescriptionSerializer(
        prescription, data=request.data, partial=True
    )
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# -----------------------------------------------------------------
# 6) GET /prescription/reorder/<int:order_id>/
# -----------------------------------------------------------------
@api_view(["GET"])
@permission_classes([permissions.IsAuthenticated])
def reorder(request, order_id):
    prescription = get_object_or_404(
        Prescription, pk=order_id, user=request.user
    )
    Prescription.objects.filter(pk=order_id).update(reorder=F("reorder") + 1)
    prescription.refresh_from_db()
    return Response(
        {"id": prescription.id, "reorder": prescription.reorder},
        status=status.HTTP_200_OK,
    )


# -----------------------------------------------------------------
# 7) GET /prescription/read-order/
# -----------------------------------------------------------------
@api_view(["GET"])
@permission_classes([permissions.IsAuthenticated])
def read_order(request):
    qs = Prescription.objects.filter(user=request.user)
    serializer = PrescriptionSerializer(qs, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


# -----------------------------------------------------------------
# 8) GET /prescription/read-drug/<int:order_id>/
# -----------------------------------------------------------------
@api_view(["GET"])
@permission_classes([permissions.IsAuthenticated])
def read_drug(request, order_id):
    prescription = get_object_or_404(
        Prescription, pk=order_id, user=request.user
    )
    items = prescription.items.all()
    serializer = PrescriptionItemSerializer(items, many=True)
    return Response(
        {
            "prescription_id": prescription.id,
            "prescription_name": prescription.name,
            "drugs": serializer.data,
        },
        status=status.HTTP_200_OK,
    )
