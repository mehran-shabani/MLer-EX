from django.urls import path
from . import views

app_name = "post_prescription"

urlpatterns = [
    path("prescription/create-order/",                      views.create_order, name="create-order"),
    path("prescription/edit-drug/<int:order_id>/<int:item_id>/", views.edit_drug,   name="edit-drug"),
    path("prescription/delete-drug/<int:order_id>/<int:item_id>/", views.delete_drug, name="delete-drug"),
    path("prescription/add-drug/<int:order_id>/",           views.add_drug,    name="add-drug"),
    path("prescription/edit-order/<int:order_id>/",         views.edit_order,  name="edit-order"),
    path("prescription/reorder/<int:order_id>/",            views.reorder,     name="reorder"),
    path("prescription/read-order/",                        views.read_order,  name="read-order"),
    path("prescription/read-drug/<int:order_id>/",          views.read_drug,   name="read-drug"),
]
