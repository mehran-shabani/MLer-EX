import logging
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from kavenegar import KavenegarAPI, APIException, HTTPException

from .models import Prescription

logger = logging.getLogger(__name__)


@receiver(post_save, sender=Prescription)
def notify_user_on_create(sender, instance, created, **kwargs):
    """
    پس از ایجاد Prescription جدید، برای کاربر پیامک اطلاع‌رسانی ارسال می‌کند.
    فرض بر این است که شماره تلفن کاربر در فیلد user.phone_number ذخیره شده
    و خالی نیست؛ در غیر این صورت پیامک ارسال نمی‌شود.
    """
    if not created:
        return

    user  = instance.user
    phone = getattr(user, "phone_number", None)
    if not phone:
        logger.warning("User %s has no phone number; SMS skipped.", user.pk)
        return

    try:
        api = KavenegarAPI(settings.KAVEH_NEGAR_API_KEY)
        api.verify_lookup({
            "receptor": phone,
            "token"   : instance.name,      # {{token}} در قالب
            "template": "order-created",
        })
    except (APIException, HTTPException) as exc:
        logger.error("Kavenegar error (Prescription %s): %s", instance.pk, exc)
