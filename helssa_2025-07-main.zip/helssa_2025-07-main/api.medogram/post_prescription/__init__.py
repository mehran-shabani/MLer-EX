default_app_config = "post_prescription.apps.PostPrescriptionConfig"
