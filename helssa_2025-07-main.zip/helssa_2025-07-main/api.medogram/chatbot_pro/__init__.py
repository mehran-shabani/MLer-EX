'''
chatbot_pro/
├── __init__.py
├── admin.py
├── apps.py
├── models.py
├── serializers.py
├── permissions.py
├── views.py
├── roots.py
├── utils/
│   ├── __init__.py
│   ├── llm_config.py
│   └── text_cleaner.py
├── knowledge/
│   ├── __init__.py
│   └── symptoms_analyzer.py
├── services/
│   ├── __init__.py
│   └── consultation_service.py
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── family_agent.py
│   ├── obgyn_agent.py
│   ├── internal_agent.py
│   ├── psychiatry_agent.py
│   ├── cardiology_agent.py
│   ├── surgery_agent.py
│   ├── ent_derm_agent.py
│   ├── neurology_agent.py
│   ├── nephrology_agent.py
│   ├── gastro_agent.py
│   ├── rheumatology_agent.py
│   └── medical_agent.py
└── migrations/
    └── __init__.py
'''
