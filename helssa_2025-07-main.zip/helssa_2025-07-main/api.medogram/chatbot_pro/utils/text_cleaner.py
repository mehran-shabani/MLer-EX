"""
Text Cleaner
============
بهبود املایی و نشانه‌گذاری خروجی مدل پیش از ارسال به کلاینت.
"""
from __future__ import annotations

import re
from typing import List, Tuple

# ------------------- قواعد جایگزینی -------------------
REPLACEMENTS: List[Tuple[str, str]] = [
    (r"ي", "ی"),        # ی عربی → فارسی
    (r"ك", "ک"),        # ک عربی → فارسی
    (r"\b([^\s]+) ها\b", r"\1‌ها"),
    (r"\bمی\s+([^\s]+)", r"می‌\1"),
    (r"\bنمی\s+([^\s]+)", r"نمی‌\1"),
    (r"\s+([.,!?؛،])", r"\1"),
    (r"\.{3,}", "…"),
    (r"[ ]{2,}", " "),
]

# ------------------- توابع داخلی -----------------------
def _apply_replacements(text: str) -> str:
    for pattern, repl in REPLACEMENTS:
        text = re.sub(pattern, repl, text)
    return text.strip()


# -------------------- API عمومی ------------------------
def refine_text(raw_text: str) -> str:
    """
    متن خام مدل → متن اصلاح‌شده و یک‌دست.
    """
    if not raw_text:
        return raw_text
    cleaned = _apply_replacements(raw_text)
    cleaned = cleaned[0].upper() + cleaned[1:]  # Capitalize
    if cleaned and cleaned[-1] not in ".!؟…":
        cleaned += "."
    return cleaned
