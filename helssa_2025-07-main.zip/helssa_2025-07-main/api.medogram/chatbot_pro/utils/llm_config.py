"""
LLM Configuration (TalkBot)
===========================
لایهٔ انتزاعی تماس با سرویس LLM «TalkBot».
"""
from __future__ import annotations

import os
import logging
from functools import lru_cache
from typing import Optional

import httpx
from django.conf import settings
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)

from llama_index.llms.openai import OpenAI
from llama_index.core import ServiceContext
from llama_index.core.callbacks import CallbackManager, LlamaDebugHandler

logger = logging.getLogger(__name__)


class TalkBotLLM:
    """دسترسی منعطف و پایدار به مدل‌های TalkBot."""

    DEFAULT_BASE = "https://api.talkbot.ir/v1"
    DEFAULT_MODEL = "gpt-4o"
    TIMEOUT = 30  # ثانیه

    # ------------------------ سازنده ------------------------
    def __init__(
        self,
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        default_model: Optional[str] = None,
        debug: Optional[bool] = None,
    ) -> None:
        self.api_key = (
            api_key
            or getattr(settings, "TALKBOT_API", None)
            or os.getenv("TALKBOT_API")
        )
        if not self.api_key:
            raise ValueError("TalkBot API key not provided.")

        self.api_base = api_base or getattr(settings, "TALKBOT_BASE", self.DEFAULT_BASE)
        self.default_model = default_model or getattr(
            settings, "TALKBOT_MODEL", self.DEFAULT_MODEL
        )
        self.debug = bool(debug if debug is not None else getattr(settings, "DEBUG", False))

        handlers = [LlamaDebugHandler(print_trace_on_end=self.debug)]
        self.callback_manager = CallbackManager(handlers)

    # ----------------------- سازنده LLM ----------------------
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(httpx.RequestError),
        reraise=True,
    )
    def _build_llm(
        self,
        model: str,
        temperature: float,
        max_tokens: int,
        streaming: bool = False,
    ) -> OpenAI:
        return OpenAI(
            api_key=self.api_key,
            api_base=self.api_base,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            streaming=streaming,
            timeout=self.TIMEOUT,
            callback_manager=self.callback_manager,
        )

    # ------------------------ متدهای عمومی -------------------
    @lru_cache(maxsize=16)
    def get_llm(
        self, temperature: float = 0.3, max_tokens: int = 2000, model: Optional[str] = None
    ) -> OpenAI:
        return self._build_llm(model or self.default_model, temperature, max_tokens, False)

    @lru_cache(maxsize=16)
    def get_streaming_llm(
        self, temperature: float = 0.3, max_tokens: int = 2000, model: Optional[str] = None
    ) -> OpenAI:
        return self._build_llm(model or self.default_model, temperature, max_tokens, True)

    # --------------------- ServiceContext --------------------
    def get_service_context(
        self,
        temperature: float = 0.3,
        max_tokens: int = 2000,
        chunk_size: int = 1024,
        chunk_overlap: int = 50,
    ) -> ServiceContext:
        llm = self.get_llm(temperature=temperature, max_tokens=max_tokens)
        return ServiceContext.from_defaults(
            llm=llm,
            callback_manager=self.callback_manager,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

    # --------------------- Health Check ----------------------
    def ping(self) -> bool:
        try:
            resp = httpx.get(
                f"{self.api_base}/models",
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10,
            )
            return resp.status_code == 200
        except httpx.RequestError as exc:
            logger.warning("TalkBot ping failed: %s", exc)
            return False


# نمونه سراسری
llm_config = TalkBotLLM()
