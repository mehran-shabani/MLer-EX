"""
chatbot_pro.knowledge
=====================
زیرپکیج دانش پایه (rule-based) برای تحلیل ورودی کاربر.
"""
from .symptoms_analyzer import SymptomsAnalyzer  # دسترسی مستقیم
