"""
Symptoms Analyzer
=================
استخراج علائم، تعیین سطح فوریت، و دسته‌بندی سیستم‌های درگیر
------------------------------------------------------------------
این ماژول سه وظیفهٔ اصلی دارد:
1) `extract_keywords`   → علائم یکتا (canonical)
2) `emergency_level`    → عدد 0 تا 3 (فوریت)
3) `classify_systems`   → فهرست سیستم‌ها (Respiratory, Cardiac, …)
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Dict, List, Tuple


class SymptomsAnalyzer:
    """
    تحلیلگر علائم مبتنی بر قاعده.
    """

    # ------------------------------------------------------------------
    # پایگاه دادهٔ مترادف علائم  (canonical_term → {synonyms})
    # ------------------------------------------------------------------
    _SYMPTOM_SYNONYMS: Dict[str, Tuple[str, ...]] = {
        "درد": ("درد", "pain", "ache"),
        "تب": ("تب", "fever", "حرارت"),
        "تهوع": ("تهوع", "حالت تهوع", "nausea"),
        "استفراغ": ("استفراغ", "vomit", "قی"),
        "سرفه": ("سرفه", "cough"),
        "تنگی نفس": ("تنگی نفس", "نفس‌تنگی", "dyspnea"),
        "درد قفسه سینه": ("درد قفسه سینه", "سینه درد", "chest pain"),
        "درد شکم": ("درد شکم", "شکم درد", "abdominal pain"),
        "اسهال": ("اسهال", "diarrhea"),
        "یبوست": ("یبوست", "constipation"),
        "فلج": ("فلج", "paralysis", "ضعف اندام"),
        "بی‌حسی": ("بی حسی", "paresthesia"),
        "سوزش ادرار": ("سوزش ادرار", "dysuria"),
        "ادرار خونی": ("ادرار خونی", "hematuria", "هماچوری"),
    }

    # ------------------------------------------------------------------
    # علائم خطر و امتیاز فوریت
    # ------------------------------------------------------------------
    _EMERGENCY_SIGNS: Dict[str, int] = {
        r"\bدرد\s+قفسه\s+سینه\b": 3,
        r"\bتنگی\s+نفس\s+شدید\b": 3,
        r"\bاز\s+دست\s+دادن\s+هوشیاری\b": 3,
        r"\bفلج\b": 2,
        r"\bخونریزی\b": 2,
        r"\bدرد\s+شکم\s+حاد\b": 2,
    }

    # ------------------------------------------------------------------
    # نگاشت علامت → سیستم درگیر
    # ------------------------------------------------------------------
    _SYSTEM_MAP: Dict[str, str] = {
        "درد قفسه سینه": "Cardiac",
        "تنگی نفس": "Respiratory",
        "سرفه": "Respiratory",
        "درد شکم": "GI",
        "اسهال": "GI",
        "یبوست": "GI",
        "سوزش ادرار": "GU",
        "ادرار خونی": "GU",
        "فلج": "Neurologic",
        "بی‌حسی": "Neurologic",
        "تب": "General",
        "تهوع": "GI",
    }

    # --------------------------- آماده‌سازی ----------------------------
    def __init__(self) -> None:
        self._compiled_synonyms = {
            canon: tuple(self._compile_pattern(s) for s in syns)
            for canon, syns in self._SYMPTOM_SYNONYMS.items()
        }
        self._compiled_emergencies = {
            self._compile_pattern(pat): score
            for pat, score in self._EMERGENCY_SIGNS.items()
        }

    # ==================================================================
    # API عمومی
    # ==================================================================
    def extract_keywords(self, text: str) -> List[str]:
        """لیست علائم یکتا به‌صورت canonical."""
        text_norm = self._normalize(text)
        found = []
        for canon, patterns in self._compiled_synonyms.items():
            if any(p.search(text_norm) for p in patterns):
                found.append(canon)
        return sorted(set(found))

    def emergency_level(self, text: str) -> int:
        """
        0: بدون فوریت • 1: کم‌خطر • 2: هشدار • 3: اورژانس
        """
        text_norm = self._normalize(text)
        level = 0
        for pattern, score in self._compiled_emergencies.items():
            if pattern.search(text_norm):
                level = max(level, score)
        return level

    def is_emergency(self, text: str) -> bool:
        """سازگاری با نسخهٔ قدیمی. True اگر سطح 3 باشد."""
        return self.emergency_level(text) == 3

    def classify_systems(self, text: str) -> List[str]:
        """سیستم‌های درگیر بر اساس علائم استخراج‌شده."""
        return sorted(
            {self._SYSTEM_MAP[sym] for sym in self.extract_keywords(text) if sym in self._SYSTEM_MAP}
        )

    # ==================================================================
    # توابع کمکی داخلی
    # ==================================================================
    @staticmethod
    def _normalize(text: str) -> str:
        return re.sub(r"\s+", " ", text.strip().lower())

    @staticmethod
    def _compile_pattern(phrase: str) -> re.Pattern:
        phrase = re.sub(r"\s+", " ", phrase.strip().lower())
        return re.compile(rf"\b{re.escape(phrase)}\b", re.IGNORECASE)


# برای سازگاری قدیمی
SimpleSymptomsAnalyzer = SymptomsAnalyzer
