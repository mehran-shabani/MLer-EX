"""
chatbot_pro.views
=================
واسطهٔ HTTP (Django REST Framework) بین کلاینت و لایهٔ سرویس.
"""
from __future__ import annotations

from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import get_object_or_404

from .permissions import IsAuthenticatedRequired
from .models import PatientProfile, MedicalConsultation
from .serializers import MedicalConsultationSerializer
from .services.consultation_service import ConsultationService
from .utils.text_cleaner import refine_text

# نمونهٔ سراسری سرویس
consultation_service = ConsultationService()


class StartOrContinueConsultation(APIView):
    """
    POST → ایجاد یا ادامهٔ مشاوره
    ----------------------------------------------------------
    body نمونه:
    {
        "message": "سلام دکتر …",
        "consultation_id": 12   # (اختیاری) برای ادامهٔ جلسه
    }
    """
    permission_classes = (IsAuthenticatedRequired,)

    def post(self, request):
        # 1) پروفایل بیمار از روی یوزر فعلی
        profile = get_object_or_404(PatientProfile, user=request.user)
        message = request.data.get("message", "").strip()
        consultation_id = request.data.get("consultation_id")

        # 2) ایجاد یا ادامه
        if consultation_id:
            result = consultation_service.process_message(consultation_id, message)
        else:
            consultation = consultation_service.start_consultation(profile, message)
            result = consultation_service.process_message(consultation.id, message)

        # 3) پاک‌سازی ادبی متن خروجی
        if isinstance(result, dict) and "response" in result:
            result["response"]["explanation"] = refine_text(
                result["response"].get("explanation", "")
            )

        return Response(result)


class EndConsultation(APIView):
    """
    POST → پایان دادن به جلسه
    body:
    {
        "consultation_id": 12,
        "reason": "completed" | "emergency"
    }
    """
    permission_classes = (IsAuthenticatedRequired,)

    def post(self, request):
        consultation_id = request.data.get("consultation_id")
        reason = request.data.get("reason", "completed")
        result = consultation_service.end_consultation(consultation_id, reason)
        return Response(result)


class ListMyConsultations(APIView):
    """
    GET → آخرین ۲۰ جلسهٔ کاربر جاری.
    """
    permission_classes = (IsAuthenticatedRequired,)

    def get(self, request):
        profile = get_object_or_404(PatientProfile, user=request.user)
        qs = MedicalConsultation.objects.filter(patient=profile).order_by("-created_at")[:20]
        serializer = MedicalConsultationSerializer(qs, many=True)
        return Response(serializer.data)
