"""
chatbot_pro.admin
=================
پیکربندی پنل ادمین برای مدل‌های برنامه.
"""
from __future__ import annotations

from django.contrib import admin
from .models import PatientProfile, MedicalConsultation, ConsultationMessage


@admin.register(PatientProfile)
class PatientProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "age", "bmi", "gender")
    search_fields = ("user__username", "user__first_name", "user__last_name")
    readonly_fields = ("age", "bmi")


class ConsultationMessageInline(admin.TabularInline):
    model = ConsultationMessage
    extra = 0
    readonly_fields = ("sender", "content", "created_at")
    can_delete = False


@admin.register(MedicalConsultation)
class MedicalConsultationAdmin(admin.ModelAdmin):
    list_display = ("patient", "status", "created_at", "updated_at")
    list_filter = ("status", "created_at")
    search_fields = ("patient__user__username", "chief_complaint")
    inlines = (ConsultationMessageInline,)

    def has_add_permission(self, request):  # noqa: D401
        """جلوگیری از ایجاد مشاورهٔ دستی در ادمین."""
        return False
