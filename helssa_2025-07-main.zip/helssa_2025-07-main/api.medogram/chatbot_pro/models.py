"""
chatbot_pro.models
==================
مدل‌های اصلی برنامه‌ٔ پزشک مجازی.
"""
from __future__ import annotations

from datetime import date
from django.db import models
from django.utils import timezone
from telemedicine.models import CustomUser   # ← یوزر سفارشی پروژهٔ مادر


class PatientProfile(models.Model):
    """
    پروفایل بیمار  
    شامل اطلاعات پایه و شاخص‌های سلامت (BMI، سابقهٔ بیماری و…).
    """
    user = models.OneToOneField(
        CustomUser,
        on_delete=models.CASCADE,
        related_name="patient_profile",
    )
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=10, help_text="male | female | other")
    height = models.FloatField(null=True, blank=True, help_text="سانتی‌متر")
    weight = models.FloatField(null=True, blank=True, help_text="کیلوگرم")
    chronic_conditions = models.JSONField(default=list, blank=True)
    allergies = models.JSONField(default=list, blank=True)
    current_medications = models.JSONField(default=list, blank=True)

    # ---------------------------- متدهای کمکی ----------------------------
    @property
    def age(self) -> int:
        """محاسبه سن نسبی امروز."""
        today = date.today()
        return (
            today.year
            - self.date_of_birth.year
            - ((today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day))
        )

    @property
    def bmi(self) -> float | None:
        """شاخص تودهٔ بدنی؛ در صورت نبود وزن یا قد → None."""
        if self.height and self.weight:
            return round(self.weight / ((self.height / 100) ** 2), 1)
        return None

    # --------------------------------------------------------------------
    def __str__(self) -> str:  # noqa: DunderStr
        return f"{self.user.get_full_name()} ({self.user.username})"


class MedicalConsultation(models.Model):
    """
    جلسهٔ مشاورهٔ پزشکی بین بیمار و هوش مصنوعی.
    """
    STATUS_CHOICES = (
        ("active", "در حال انجام"),
        ("completed", "تکمیل شده"),
        ("emergency", "اورژانسی"),
    )

    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name="consultations"
    )
    chief_complaint = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="active")
    symptoms = models.JSONField(default=list, blank=True)
    result_json = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    # --------------------------------------------------------------------
    def __str__(self) -> str:  # noqa: DunderStr
        return f"{self.patient} | {self.status} | {self.created_at:%Y-%m-%d}"


class ConsultationMessage(models.Model):
    """
    پیام موجود در یک جلسهٔ مشاوره.
    sender: patient | ai
    """
    consultation = models.ForeignKey(
        MedicalConsultation, on_delete=models.CASCADE, related_name="messages"
    )
    sender = models.CharField(max_length=20)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    # --------------------------------------------------------------------
    class Meta:  # noqa: DunderStr
        ordering = ("created_at",)

    def __str__(self) -> str:  # noqa: DunderStr
        return f"{self.sender}: {self.content[:30]}..."
