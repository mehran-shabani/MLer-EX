# Chatbot‑Pro API 🚑🤖

A minimal, JWT‑protected REST interface that powers **Medogram’s smart triage & therapy chatbot**.  
Everything you need to plug a Flutter (or any) client into the service lives in the three routes below.

---

## Base URL  
```
https://api.medogram.ir/api/chatbot-pro/
```

### Authentication  
Every request **must** carry a Simple JWT access‑token:

```http
Authorization: Bearer <access_token>
```

---

## Endpoints

| Path | Method | Description | Request Body |
|------|--------|-------------|--------------|
| `consult/` | **POST** | • Start a **new** consultation (omit `consultation_id`).<br>• Send a **follow‑up** message (include `consultation_id`). | ```json
{ "message": "Hi doctor…", "consultation_id": 42 }
``` |
| `end/` | **POST** | Close an active consultation. | ```json
{ "consultation_id": 42, "reason": "completed" }
``` <br>`reason`: `"completed"` (default) | `"emergency"` |
| `my/` | **GET** | Fetch the 20 most‑recent consultations of the logged‑in user. | – |

---

### Response – `consult/`

```jsonc
{
  "consultation_id": 42,
  "response": {
    "explanation": "AI reply — already spell‑checked & polished",
    "emergency": false,          // true ⇢ level 3
    "emergency_level": 0,        // 0–3 numeric scale
    "symptoms": ["pain", "fever"],
    "domain": "internal"         // agent that answered
  }
}
```

* **`emergency_level`**:  
  * 0 Normal &nbsp; 1 Watch &nbsp; 2 Warning &nbsp; **3 Emergency**
* **`domain`**: specialty agent that handled the message (cardiology, neurology, …).

---

## Quick Start (cURL)

```bash
# Start a new consultation
curl -X POST https://api.medogram.ir/api/chatbot-pro/consult/      -H "Authorization: Bearer $ACCESS"      -H "Content-Type: application/json"      -d '{"message":"Hello, I have a headache"}'

# Follow‑up message
curl -X POST https://api.medogram.ir/api/chatbot-pro/consult/      -H "Authorization: Bearer $ACCESS"      -H "Content-Type: application/json"      -d '{"consultation_id":42,"message":"It is getting worse"}'

# End the session
curl -X POST https://api.medogram.ir/api/chatbot-pro/end/      -H "Authorization: Bearer $ACCESS"      -H "Content-Type: application/json"      -d '{"consultation_id":42,"reason":"completed"}'

# List my sessions
curl -X GET https://api.medogram.ir/api/chatbot-pro/my/      -H "Authorization: Bearer $ACCESS"
```

---

## Error Codes

| Code | Meaning | Client Action |
|------|---------|---------------|
| 200  | OK | Render data |
| 400  | Bad request / missing field | Show validation error |
| 401  | Invalid / expired token | Refresh token → retry, or force login |
| 404  | Not found | Show “item not found” / back to list |
| 500  | Server error | Generic “please try again later” |

---

### Why only three routes?

1. **Simplicity** – one central `consult/` endpoint handles the entire chat loop.  
2. **Safety** – server analyses every message; if `emergency_level == 3` you show a red banner.  
3. **Speed** – responses are spell‑checked server‑side; front‑end just displays them.

---

**Happy coding!** 🚀
