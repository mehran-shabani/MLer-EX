"""
chatbot_pro.roots
=================
مسیرهای اپ را در قالب فایل «roots.py» ارائه می‌کند.
"""
from django.urls import path
from .views import (
    StartOrContinueConsultation,
    EndConsultation,
    ListMyConsultations,
)

urlpatterns = [
    path("consult/", StartOrContinueConsultation.as_view(), name="consult"),
    path("end/", EndConsultation.as_view(), name="end_consultation"),
    path("my/", ListMyConsultations.as_view(), name="my_consultations"),
]
