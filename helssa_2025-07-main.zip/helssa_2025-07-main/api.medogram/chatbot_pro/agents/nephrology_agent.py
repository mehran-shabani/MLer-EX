"""
NephrologyUrologyAgent
======================
مدیریت سنگ کلیه، عفونت ادرار، نارسایی کلیه و بیماری‌های پروستات.
"""
from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class NephrologyUrologyAgent(BaseAgent):
    """
    وظایف:
      • تشخیص و درمان سنگ کلیه (medical expulsion therapy).  
      • پروتکل عفونت ادراری ساده و عارضه‌دار.  
      • پایش GFR، مدیریت CKD و زمان دیالیز.  
      • غربالگری سرطان پروستات (PSA) و BPH.
    """

    domain_name: str = "nephro_urology"
    trigger_keywords: List[str] = [
        "سنگ کلیه",
        "کلیه درد",
        "عفونت ادرار",
        "سوزش ادرار",
        "ادرار خونی",
        "پروستات",
        "سرطان پروستات",
        "bph",
        "psa",
    ]

    # ----------------------- پرامپت ------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        return (
            "شما متخصص کلیه و مجاری ادرار هستید. لطفاً:\n"
            "• تشخیص و درمان بیماری فعلی (سنگ، عفونت، نارسایی و غیره).\n"
            "• دستور دارویی یا جراحی و زمان مراجعه به اورژانس.\n"
            "• آموزش بیمار در مورد پیشگیری و پیگیری آزمایشات.\n\n"
            f"سن بیمار: {patient_info.get('age')} سال\n"
            f"پیام بیمار: «{message}»"
        )
