"""
NeurologyAgent
==============
پاسخ‌گوی سردرد، ام‌اس، پارکینسون، کمردردهای نوروژنیک و تشنج.
"""
from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class NeurologyAgent(BaseAgent):
    """
    وظایف:
      • تشخیص افتراقی سردرد (میگرن، خوشه‌ای، تنشی) و پرچم‌های قرمز.  
      • مشاوره Multiple Sclerosis: عود، درمان حاد، DMT.  
      • راهنمایی بیماران پارکینسون در مراحل دارویی و فیزیوتراپی.  
      • مدیریت کمردردهای نوروژنیک و تست‌های تصویربرداری.  
      • ارزیابی تشنج و زمان شروع درمان ضدّصرع.
    """

    domain_name: str = "neurology"
    trigger_keywords: List[str] = [
        "سردرد",
        "میگرن",
        "کلستر هدیک",
        "ام اس",
        "multiple sclerosis",
        "پارکینسون",
        "تشنج",
        "کمردرد",
        "بی‌حسی",
        "گزگز",
    ]

    # ----------------------- پرامپت ------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        return (
            "شما متخصص مغز و اعصاب هستید. مراحل زیر را انجام دهید:\n"
            "۱) تشخیص افتراقی بر اساس شرح حال.\n"
            "2) پرچم‌های خطر و اندیکاسیون تصویربرداری فوری.\n"
            "۳) طرح درمان دارویی و غیردارویی.\n"
            "۴) زمان‌بندی پیگیری و ارجاع به فوق‌تخصص در صورت نیاز.\n\n"
            f"اطلاعات بیمار: سن {patient_info.get('age')} سال، "
            f"BMI {patient_info.get('bmi')}\n"
            f"پیام بیمار: «{message}»"
        )
