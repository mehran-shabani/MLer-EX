"""
EntDermatologyAgent
===================
ترکیب تخصص گوش‌حلق‌وبینی و پوست/زیبایی برای سؤالات شایع.
"""
from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class EntDermatologyAgent(BaseAgent):
    """
    وظایف:
      • تشخیص و درمان سینوزیت، عفونت گوش، آلرژی بینی.  
      • افتراق ضایعات پوستی خوش‌خیم/بدخیم و آکنه.  
      • راهنمایی مراقبت‌های پس از لیزر و پروسیجرهای زیبایی.
    """

    domain_name: str = "ent_derm"
    trigger_keywords: List[str] = [
        "گوش درد",
        "عفونت گوش",
        "سینوزیت",
        "گرفتگی بینی",
        "آکنه",
        "جوش",
        "خال",
        "لیزر پوست",
        "اگزما",
        "پسوریازیس",
    ]

    # ----------------------- پرامپت ------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        return (
            "شما متخصص ENT و پوست هستید. لطفاً:\n"
            "• علت اصلی شکایت بیمار را توضیح دهید.\n"
            "• دارو یا درمان موضعی/سیستمی مناسب پیشنهاد کنید.\n"
            "• علائم هشدار برای ارجاع فوری را ذکر کنید.\n\n"
            f"پیام بیمار: «{message}»"
        )
