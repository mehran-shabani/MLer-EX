"""
chatbot_pro.agents
==================
درگاه مرکزی همهٔ عامل‌های تخصصی (Agents).

🔹 هنگام بارگذاری Django، این پکیج مپینگ `DOMAIN_AGENT_MAP` را آماده می‌کند
   تا سایر بخش‌ها (مثلاً ConsultationService) بتوانند به‌سادگی عامل مناسب
   را فراخوانی کنند.  
🔹 در این پیام فقط سه فایل پایه ارائه شده‌اند؛ فایل‌های تخصصی دیگر در
   پیام‌های بعدی افزوده خواهند شد.
"""

# ------------------------------- Imports -------------------------------
from .family_agent import FamilyPhysicianAgent

# ↓↓↓ سایر Agentها در پیام‌های بعدی به این مپینگ افزوده خواهند شد ↓↓↓
# from .obgyn_agent import ObstetricsGynecologyAgent
# from .internal_agent import InternalMedicineAgent
# ...

# -------------------------- Mapping (domain → agent) -------------------
DOMAIN_AGENT_MAP = {
    "family": FamilyPhysicianAgent(),
    # "obgyn": ObstetricsGynecologyAgent(),
    # "internal": InternalMedicineAgent(),
    # ...
}

__all__ = ["DOMAIN_AGENT_MAP", "FamilyPhysicianAgent"]
