"""
PsychiatryAgent
===============
مدیریت افسردگی، اضطراب، بی‌خوابی و سایر اختلالات شایع روان‌پزشکی.
"""
from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class PsychiatryAgent(BaseAgent):
    """
    وظایف:
      • ارزیابی شدت افسردگی / اضطراب بر اساس شرح حال  
      • مداخلات غیر دارویی (CBT، Mindfulness) و دارویی خط اول  
      • شناسایی علائم خطر (افکار خودکشی، سایکوز) و ارجاع فوری  
      • آموزش به بیمار در مورد عوارض دارویی و مدیریت پیگیری
    """

    domain_name: str = "psychiatry"
    trigger_keywords: List[str] = [
        "افسردگی",
        "اضطراب",
        "استرس",
        "بی‌خوابی",
        "insomnia",
        "پانیک",
        "حمله پانیک",
        "وسواس",
    ]

    # ----------------------- پرامپت ------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        return (
            "شما روان‌پزشک هستید. لطفاً مراحل زیر را اجرا کنید:\n"
            "۱) تعیین شدت اختلال بر اساس گفته‌های بیمار.\n"
            "۲) ارائه تکنیک‌های خودیاری و روان‌درمانی کوتاه.\n"
            "۳) تجویز دارو (SSRI یا بنزودیازپین کوتاه‌مدت) در صورت نیاز.\n"
            "۴) بررسی علائم خطر و در صورت وجود ارجاع فوری.\n\n"
            f"اطلاعات بیمار: سن {patient_info.get('age')}، "
            f"جنس {patient_info.get('gender')}\n"
            f"پیام بیمار: «{message}»"
        )
