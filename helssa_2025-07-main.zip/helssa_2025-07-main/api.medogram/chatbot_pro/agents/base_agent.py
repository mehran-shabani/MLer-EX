"""
BaseAgent
=========
کلاس پایه برای تمام Agentهای تخصصی.  
تمام Agentهای بعدی از این کلاس ارث می‌برند و تنها متد `_build_domain_prompt`
را مطابق دامنهٔ خود پیاده‌سازی می‌کنند.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, List

from llama_index.core.llms import ChatMessage, MessageRole
from ..utils.llm_config import llm_config


class BaseAgent(ABC):
    """
    Agent پایه:  
    - یک LLM مشترک  
    - قالب‌بندی تاریخچه گفتگو  
    - متد اصلی `consult`
    """

    def __init__(self) -> None:
        # همهٔ Agentها از یک نمونه LLM کش‌شده استفاده می‌کنند
        self.llm = llm_config.get_llm()

    # -------------- ویژگی‌های دامنه (باید در Subclass تعیین شود) --------------
    domain_name: str = "base"
    trigger_keywords: List[str] = []

    # ------------------- پرامپت اختصاصی هر Agent -------------------
    @abstractmethod
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        """
        در Agentهای فرزند پیاده‌سازی می‌شود تا متن SYSTEM پرامپت را
        بر اساس پیام بیمار و اطلاعات بیمار تولید کند.
        """
        ...

    # ------------------------ متد اصلی مشاوره ------------------------
    def consult(self, message: str, patient_info: Dict, history: List[Dict]) -> str:
        """
        ارسال پیام بیمار + تاریخچه به LLM و دریافت پاسخ.
        """
        # 1) ساخت پرامپت دامنه
        prompt = self._build_domain_prompt(message, patient_info)

        # 2) تبدیل تاریخچه به ChatMessage
        messages: List[ChatMessage] = [ChatMessage(role=MessageRole.SYSTEM, content=prompt)]
        for msg in history[-5:]:
            role = MessageRole.USER if msg["sender"] == "patient" else MessageRole.ASSISTANT
            messages.append(ChatMessage(role=role, content=msg["content"]))

        # 3) پیام کنونی بیمار
        messages.append(ChatMessage(role=MessageRole.USER, content=message))

        # 4) فراخوانی LLM
        response = self.llm.chat(messages)
        return response.message.content
