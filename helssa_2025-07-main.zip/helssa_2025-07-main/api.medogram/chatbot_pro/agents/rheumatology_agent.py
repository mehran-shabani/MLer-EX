"""
RheumatologyAgent
=================
پوشش‌دهنده آرتریت روماتوئید، لوپوس، پوکی استخوان و سایر بیماری‌های روماتولوژی.
"""
from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class RheumatologyAgent(BaseAgent):
    """
    وظایف:
      • تشخیص و درمان مرحله‌ای آرتریت روماتوئید (DMARDs, Biologics).  
      • غربالگری لوپوس (ANA, dsDNA) و عوارض کلیوی / مغزی.  
      • پیشگیری و درمان پوکی استخوان (DXA, Bisphosphonates).  
      • توصیه سبک زندگی، فیزیوتراپی و پایش عوارض دارویی.
    """

    domain_name: str = "rheumatology"
    trigger_keywords: List[str] = [
        "روماتیسم",
        "آرتریت روماتوئید",
        "لوپوس",
        "پوکی استخوان",
        "درد مفصل",
        "التهاب مفصل",
        "RA",
        "SLE",
        "osteoporosis",
    ]

    # ----------------------- پرامپت ------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        return (
            "شما متخصص روماتولوژی هستید. لطفاً موارد زیر را انجام دهید:\n"
            "۱) تشخیص افتراقی بر اساس علائم و آزمایش‌های لازم.\n"
            "۲) طرح درمان دارویی (NSAID, Steroid, DMARD, Biologic) مرحله‌ای.\n"
            "۳) پایش عوارض و آموزش بیمار.\n"
            "۴) توصیه ورزش و رژیم غذایی مناسب.\n\n"
            f"سن بیمار: {patient_info.get('age')} سال، "
            f"جنس: {patient_info.get('gender')}\n"
            f"پیام بیمار: «{message}»"
        )
