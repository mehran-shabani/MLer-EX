"""
CardiologyAgent
===============
مدیریت درد قفسه سینه، سکته قلبی، نارسایی و پیشگیری‌ بیماری‌های قلب.
"""
from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class CardiologyAgent(BaseAgent):
    """
    وظایف:
      • تشخیص افتراقی درد قفسه سینه و سکته (STEMI/NSTEMI).  
      • اقدامات دارویی اولیه (آسپیرین، نیتروگلیسیرین) و زمان ارجاع اورژانسی.  
      • مدیریت بلندمدت نارسایی قلبی و داروهای استاندارد.  
      • راهکارهای پیشگیری (Lifestyle, استاتین‌ها) متناسب با ریسک بیمار.
    """

    domain_name: str = "cardiology"
    trigger_keywords: List[str] = [
        "درد قفسه سینه",
        "سکته قلبی",
        "انفارکتوس",
        "نارسایی قلبی",
        "تپش قلب",
        "تنگی نفس قلبی",
        "کلسترول",
        "پیشگیری قلب",
    ]

    # ----------------------- پرامپت ------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        return (
            "شما متخصص قلب و عروق هستید. لطفاً:\n"
            "۱) ابتدا علائم اورژانسی (STEMI، نارسایی حاد) را غربال کنید.\n"
            "۲) در صورت اورژانس: اقدامات اولیه و ارجاع فوریت.\n"
            "۳) در موارد غیرفوری: پروتکل‌های تشخیصی (ECG، اکو، آنزیم‌ها).\n"
            "۴) درمان دارویی و توصیه‌های پیشگیری برای LDL و Lifestyle.\n\n"
            f"سن بیمار: {patient_info.get('age')}، "
            f"BMI: {patient_info.get('bmi')}\n"
            f"پیام بیمار: «{message}»"
        )
