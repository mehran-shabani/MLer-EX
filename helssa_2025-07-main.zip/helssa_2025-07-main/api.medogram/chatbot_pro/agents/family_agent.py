"""
FamilyPhysicianAgent
====================
عامل «پزشک خانواده» وظیفهٔ غربال‌گری اولیه و ارجاع را بر عهده دارد.
"""

from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class FamilyPhysicianAgent(BaseAgent):
    """
    - رسیدگی به شکایات شایع (سرماخوردگی، سردرد، مشکلات گوارشی خفیف و …).  
    - تجویز اقدامات اولیه، آزمایش‌های پایه و ارجاع به متخصص در صورت لزوم.
    """

    domain_name: str = "family"

    # کلیدواژه‌هایی که انتخاب این Agent را برمی‌انگیزند
    trigger_keywords: List[str] = [
        "چک آپ",
        "سرماخوردگی",
        "سردرد",
        "خون دماغ",
        "کودک",
        "نوزاد",
        "اسهال",
        "استفراغ",
        "عفونت پوستی",
        "رفتگی گوش",
        "فشار خون",
        "قند",
        "چربی",
    ]

    # ------------------ پرامپت اختصاصی ------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        """
        پرامپت SYSTEM برای LLM.
        """
        return (
            "شما یک پزشک خانواده هستید. وظایف شما:\n"
            "۱) خلاصه و برداشت از شکایت بیمار\n"
            "۲) توصیه اقدامات اولیه و داروهای بدون نسخه (OTC) در صورت نیاز\n"
            "۳) آزمایش‌های پایه جهت غربال‌گری\n"
            "۴) تعیین ضرورت ارجاع به متخصص یا اورژانس\n\n"
            f"اطلاعات بیمار: سن {patient_info.get('age')}، "
            f"جنس {patient_info.get('gender')}، "
            f"BMI {patient_info.get('bmi')}\n"
            f"بیماری‌های مزمن: {', '.join(patient_info.get('chronic_conditions', []))}\n\n"
            f"پیام بیمار: «{message}»\n\n"
            "به زبان فارسی روان و محترمانه پاسخ دهید."
        )
