"""
InternalMedicineAgent
=====================
پوشش‌دهنده دیابت، فشار خون، چربی خون، کبد چرب و سایر مسائل تخصص داخلی.
"""
from __future__ import annotations

from typing import Dict, List
from .base_agent import BaseAgent


class InternalMedicineAgent(BaseAgent):
    """
    وظایف:
      • تنظیم رژیم، دارو و پایش دیابت (HbA1c، SMBG)  
      • کنترل فشار خون و داروهای ضدHypertension  
      • مدیریت دیس‌لیپیدمی (LDL، TG)  
      • بررسی و درمان کبد چرب غیرالکلی  
      • تشخیص و ارجاع عوارض (نفروپاتی، رتینوپاتی)
    """

    domain_name: str = "internal"
    trigger_keywords: List[str] = [
        "دیابت",
        "قند خون",
        "hba1c",
        "فشار خون",
        "پرفشاری",
        "چربی خون",
        "ldl",
        "تری‌گلیسیرید",
        "کبد چرب",
        "fatty liver",
    ]

    # ------------------------ پرامپت -------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        return (
            "شما فوق‌تخصص داخلی هستید. لطفاً:\n"
            "۱) وضعیت کنترل بیمار را بر اساس شرح حال تخمین بزنید.\n"
            "۲) توصیه رژیم غذایی و فعالیت بدنی.\n"
            "۳) طرح دارویی (خط اول و دوم) مطابق گایدلاین.\n"
            "۴) آزمایش‌ها و Imaging پیگیری.\n"
            "۵) زمان‌بندی و شرایط ارجاع به فوق‌تخصص.\n\n"
            f"اطلاعات بیمار: سن {patient_info.get('age')}، "
            f"BMI {patient_info.get('bmi')}\n"
            f"پیام بیمار: «{message}»"
        )
