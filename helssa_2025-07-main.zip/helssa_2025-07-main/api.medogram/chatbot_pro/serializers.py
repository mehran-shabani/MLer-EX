"""
chatbot_pro.serializers
=======================
سریالایزرهای DRF برای تبادل داده با کلاینت.
"""
from __future__ import annotations

from rest_framework import serializers
from telemedicine.models import CustomUser  # یوزر اصلی
from .models import PatientProfile, MedicalConsultation, ConsultationMessage


# -------------------------- User --------------------------
class UserSerializer(serializers.ModelSerializer):
    """نمای ساده از کاربر برای مصرف در پروفایل بیمار."""

    class Meta:
        model = CustomUser
        fields = ("id", "username", "first_name", "last_name")


# ----------------------- PatientProfile -------------------
class PatientProfileSerializer(serializers.ModelSerializer):
    """پروفایل بیمار به‌همراه اطلاعات کاربر مرتبط (read-only)."""

    user = UserSerializer(read_only=True)

    class Meta:
        model = PatientProfile
        fields = "__all__"


# ----------------------- ConsultationMessage --------------
class ConsultationMessageSerializer(serializers.ModelSerializer):
    """پیام درون مشاوره (بدون فیلد ForeignKey برگشتی برای سادگی)."""

    class Meta:
        model = ConsultationMessage
        fields = ("id", "sender", "content", "created_at")


# ----------------------- MedicalConsultation --------------
class MedicalConsultationSerializer(serializers.ModelSerializer):
    """خلاصهٔ جلسه به‌همراه آخرین پیام‌ها (read-only)."""

    messages = ConsultationMessageSerializer(many=True, read_only=True)

    class Meta:
        model = MedicalConsultation
        fields = "__all__"
