"""
Consultation Service
====================
گردانندهٔ چرخهٔ مشاورهٔ پزشکی:
 - آغاز جلسه
 - پردازش پیام‌های بعدی (LLM + Agent)
 - پایان جلسه
"""

from __future__ import annotations

import logging
from typing import Dict, List

from django.db import transaction
from django.utils import timezone
from django.core.cache import cache

from ..models import MedicalConsultation, ConsultationMessage, PatientProfile
from ..agents.medical_agent import MedicalAgent
from ..knowledge.symptoms_analyzer import SymptomsAnalyzer

logger = logging.getLogger(__name__)

CACHE_TTL = 60            # ثانیه
MAX_HISTORY_LEN = 50      # حداکثر پیام ذخیره‌شده در هر جلسه


class ConsultationService:
    """سرویس اصلی مشاورهٔ پزشکی."""

    def __init__(self) -> None:
        self.agent = MedicalAgent()
        self.symptom_analyzer = SymptomsAnalyzer()

    # ------------------------------------------------------------------
    # شروع مشاوره
    # ------------------------------------------------------------------
    def start_consultation(
        self, profile: PatientProfile, chief_complaint: str
    ) -> MedicalConsultation:
        with transaction.atomic():
            consult = MedicalConsultation.objects.create(
                patient=profile,
                chief_complaint=chief_complaint,
                status="active",
            )
            ConsultationMessage.objects.create(
                consultation=consult, sender="patient", content=chief_complaint
            )
        logger.info("Consultation %s started for user %s", consult.id, profile.user_id)
        return consult

    # ------------------------------------------------------------------
    # پردازش پیام بیمار
    # ------------------------------------------------------------------
    def process_message(self, consultation_id: int, message: str) -> Dict:
        cache_key = f"consult:{consultation_id}:{hash(message)}"
        if cached := cache.get(cache_key):
            return cached

        try:
            with transaction.atomic():
                consultation = (
                    MedicalConsultation.objects.select_for_update().get(id=consultation_id)
                )
                ConsultationMessage.objects.create(
                    consultation=consultation, sender="patient", content=message
                )
                self._trim_history_if_needed(consultation)

            agent_result = self._call_agent(consultation, message)

            with transaction.atomic():
                ConsultationMessage.objects.create(
                    consultation=consultation, sender="ai", content=agent_result["reply"]
                )
                consultation.result_json = agent_result
                consultation.symptoms = agent_result["symptoms"]
                consultation.save(
                    update_fields=["result_json", "symptoms", "updated_at"]
                )

            body = {
                "consultation_id": consultation.id,
                "response": {
                    "explanation": agent_result["reply"],
                    "emergency": agent_result["emergency"],
                    "emergency_level": agent_result["emergency_level"],
                    "symptoms": agent_result["symptoms"],
                    "domain": agent_result["domain"],
                },
            }
            cache.set(cache_key, body, CACHE_TTL)
            return body

        except MedicalConsultation.DoesNotExist:
            logger.error("Consultation %s not found", consultation_id)
            return {"status": "error", "message": "مشاوره یافت نشد"}

        except Exception as exc:  # pylint: disable=broad-except
            logger.exception("LLM processing failed: %s", exc)
            return {"status": "error", "message": "خطا در پردازش؛ لطفاً مجدداً تلاش کنید."}

    # ------------------------------------------------------------------
    # پایان مشاوره
    # ------------------------------------------------------------------
    def end_consultation(self, consultation_id: int, reason: str = "completed") -> Dict:
        try:
            with transaction.atomic():
                consultation = MedicalConsultation.objects.get(id=consultation_id)
                consultation.status = (
                    reason if reason in ("completed", "emergency") else "completed"
                )
                consultation.completed_at = timezone.now()
                consultation.save(update_fields=["status", "completed_at"])
            logger.info("Consultation %s ended (%s)", consultation_id, reason)
            return {"status": "ok", "message": "مشاوره پایان یافت"}
        except MedicalConsultation.DoesNotExist:
            return {"status": "error", "message": "مشاوره یافت نشد"}

    # ------------------------------------------------------------------
    # متد خصوصی: تماس با Agent
    # ------------------------------------------------------------------
    def _call_agent(self, consultation: MedicalConsultation, message: str) -> Dict:
        profile = consultation.patient
        patient_info = {
            "age": profile.age,
            "gender": profile.gender,
            "bmi": profile.bmi,
            "chronic_conditions": profile.chronic_conditions,
        }
        history: List[Dict] = list(
            consultation.messages.order_by("created_at").values("sender", "content")
        )

        result = self.agent.consult(message, patient_info, history)
        result["emergency_level"] = self.symptom_analyzer.emergency_level(message)
        return result

    # ------------------------------------------------------------------
    # محدود کردن طول تاریخچه
    # ------------------------------------------------------------------
    @staticmethod
    def _trim_history_if_needed(consultation: MedicalConsultation) -> None:
        msgs = consultation.messages.order_by("-created_at")
        if msgs.count() > MAX_HISTORY_LEN:
            to_delete = msgs[MAX_HISTORY_LEN :]
            ConsultationMessage.objects.filter(
                id__in=[m.id for m in to_delete]
            ).delete()
