// ignore_for_file: deprecated_member_use

import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'login/login_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  /* ===== نسخهٔ فعلی اپ؛ هر ریلیز به‌روز شود ===== */
  static const String _currentVersion = '1.0.0.8';

  /* ===== Animation ===== */
  late final AnimationController _ctl;

  /* ===== شبکه ===== */
  static const _apiUrl = 'https://api.medogram.ir/down/status/';
  static const _dlUrl  = 'https://api.medogram.ir/api/download-apk/';
  static const _timeout = Duration(seconds: 3);
  static const _minSplash = Duration(seconds: 3);

  /* ===== State ===== */
  bool _navigated = false;
  late final DateTime _start;
 

  @override
  void initState() {
    super.initState();
    _start = DateTime.now();
    _ctl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    _checkUpdate();
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  /* ---------- مقایسهٔ نسخه ---------- */
  bool _isNewer(String server, String local) {
    final s = server.split('.').map(int.parse).toList();
    final l = local.split('.').map(int.parse).toList();
    for (var i = 0; i < max(s.length, l.length); i++) {
      final sv = i < s.length ? s[i] : 0;
      final lv = i < l.length ? l[i] : 0;
      if (sv > lv) return true;
      if (sv < lv) return false;
    }
    return false;
  }

  /* ---------- فراخوانی API ---------- */
  Future<void> _checkUpdate() async {
    bool flag = false;
    bool force = false;
    String serverVer = _currentVersion;

    try {
      final resp = await http.get(Uri.parse(_apiUrl)).timeout(_timeout);
      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        flag       = data['update_available'] == true;
        serverVer  = data['version'] ?? _currentVersion;
        force      = data['force_update'] ?? false;
      }
    } catch (_) {/* سکوت */ }

    final need = flag && _isNewer(serverVer, _currentVersion);
    
    

    /* حداقل زمان اسپلش */
    final gap = DateTime.now().difference(_start);
    final wait = gap < _minSplash ? _minSplash - gap : Duration.zero;
    await Future.delayed(wait);
    if (!mounted) return;

    if (need) {
      _showUpdateDialog(force, force
          ? 'عزیزم هلسا به‌روز شده و نسخهٔ قبلی بازنشسته می‌شود!'
          : 'نسخهٔ جدید هلسا آماده است؛ بهتر است به‌روز باشی!');
    } else {
      _goLogin();
    }
  }

  /* ---------- ناوبری ---------- */
  void _goLogin() {
    if (_navigated || !mounted) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 1200),
        pageBuilder: (_, __, ___) => const LoginPage(),
        transitionsBuilder: (_, anim, __, child) {
          final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack);
          return FadeTransition(
            opacity: curved,
            child: RotationTransition(
              turns: Tween<double>(begin: .85, end: 1).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  /* ---------- دیالوگ به‌روزرسانی ---------- */
  void _showUpdateDialog(bool force, String title) {
    showDialog(
      context: context,
      barrierDismissible: !force,
      barrierColor: Colors.black54,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF1E1E2E).withOpacity(0.95),
                const Color(0xFF2A2A3E).withOpacity(0.95),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 0,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Icon
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF6366F1).withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 0,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.system_update,
                        color: Colors.white,
                        size: 32,
                      ),
                    ),
                    const SizedBox(height: 24),
                    
                    // Title
                    Text(
                      title,
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.vazirmatn(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 32),
                    
                    // Buttons
                    if (force)
                      _modernPrimaryButton('دانلود نسخهٔ جدید', _launchDownload)
                    else
                      Column(
                        children: [
                          _modernPrimaryButton('دانلود', () {
                            _launchDownload();
                            _goLogin();
                          }),
                          const SizedBox(height: 12),
                          _modernSecondaryButton('بی‌خیال!', () {
                            Navigator.pop(context);
                            _goLogin();
                          }),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /* ---------- دکمه‌های مدرن ---------- */
  Widget _modernPrimaryButton(String text, VoidCallback onPressed) {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6366F1).withOpacity(0.4),
            blurRadius: 12,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: Text(
              text,
              style: GoogleFonts.vazirmatn(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _modernSecondaryButton(String text, VoidCallback onPressed) {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: Text(
              text,
              style: GoogleFonts.vazirmatn(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.white.withOpacity(0.9),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _launchDownload() async =>
      launchUrl(Uri.parse(_dlUrl), mode: LaunchMode.externalApplication);

  /* ---------- UI (particles + logo + version) ---------- */
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: AnimatedBuilder(
          animation: _ctl,
          builder: (_, __) => Stack(
            children: [
              CustomPaint(
                size: MediaQuery.of(context).size,
                painter: _ParticlesPainter(_ctl.value),
              ),
              Center(child: _logoAnimator()),
              Positioned(
                bottom: 20,
                left: 0,
                right: 0,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    'Version : $_currentVersion',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.jetBrainsMono(
                      color: Colors.white70,
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );

  Widget _logoAnimator() => TweenAnimationBuilder<double>(
        tween: Tween(begin: .97, end: 1.03),
        duration: const Duration(seconds: 2),
        curve: Curves.easeInOut,
        builder: (_, __, ___) => Transform.scale(
          scale: 1 + 0.03 * sin(_ctl.value * 2 * pi),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                      color: Colors.blue.withOpacity(.55),
                      blurRadius: 48,
                      spreadRadius: 8)
                ]),
                child: const SizedBox(width: 270, height: 90),
              ),
              ShaderMask(
                shaderCallback: (b) {
                  final x = b.width * _ctl.value;
                  return LinearGradient(
                    colors: const [
                      Color(0xFF2196F3),
                      Color(0xFF64B5F6),
                      Color(0xFFBBDEFB),
                    ],
                    stops: [
                      (x / b.width).clamp(0, 1),
                      ((x + 40) / b.width).clamp(0, 1),
                      ((x + 80) / b.width).clamp(0, 1),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ).createShader(b);
                },
                blendMode: BlendMode.srcIn,
                child: Text('HELSSA',
                    style: GoogleFonts.orbitron(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 2)),
              ),
            ],
          ),
        ),
      );
}

/* ---------- Particles painter ---------- */
class _ParticlesPainter extends CustomPainter {
  final double progress;
  final _rand = Random();
  _ParticlesPainter(this.progress);

  @override
  void paint(Canvas c, Size s) {
    const n = 30;
    for (var i = 0; i < n; i++) {
      final t = (progress + i / n) % 1;
      final x = s.width * (.1 + .8 * _rand.nextDouble()) + 40 * sin(t * 2 * pi + i);
      final y = s.height * (.2 + .6 * _rand.nextDouble()) + 30 * cos(t * 2 * pi + i);
      final r = 2.5 + 2 * sin(t * pi);
      final op = .08 + .19 * (1 + sin((progress * 2 + i) * pi));
      c.drawCircle(
        Offset(x, y),
        r,
        Paint()
          ..color = Colors.blue.withOpacity(op)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlesPainter old) =>
      old.progress != progress;
}
