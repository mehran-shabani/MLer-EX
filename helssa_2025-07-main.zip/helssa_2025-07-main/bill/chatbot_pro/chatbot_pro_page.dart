// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'dart:math';
import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:share_plus/share_plus.dart';
import '../../utils/snackbar.dart';

import 'chatbot_pro_message_bubble.dart';
import 'chatbot_pro_input_area.dart';

class ProButton extends StatefulWidget {
  const ProButton({super.key});

  @override
  State<ProButton> createState() => _ProButtonState();
}

class _ProButtonState extends State<ProButton> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<Color?> _colorAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    
    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    
    _colorAnimation = ColorTween(
      begin: Colors.amber.shade400,
      end: Colors.amber.shade200,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _controller.repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _colorAnimation.value ?? Colors.amber.shade400,
                  Colors.amber.shade600,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.amber.withOpacity(0.4),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: const Text(
              'Pro',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      },
    );
  }
}

class AnimatedProTitle extends StatefulWidget {
  final VoidCallback onProTap;
  const AnimatedProTitle({super.key, required this.onProTap});

  @override
  State<AnimatedProTitle> createState() => _AnimatedProTitleState();
}

class _AnimatedProTitleState extends State<AnimatedProTitle>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Gradient> _gradientAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(
          backgroundColor: Colors.purple.shade50,
          radius: 18,
          child: Icon(Icons.psychology, color: Colors.purple.shade700, size: 20),
        ),
        const SizedBox(width: 8),
        const Text(
          'DocAI Assistant',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: widget.onProTap,
          child: const ProButton(),
        ),
      ],
    );
  }
}

class AnimatedProBackground extends StatefulWidget {
  const AnimatedProBackground({super.key});
  @override
  State<AnimatedProBackground> createState() => _AnimatedProBackgroundState();
}

class _AnimatedProBackgroundState extends State<AnimatedProBackground> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final List<ProParticle> _particles = [];
  final Random _random = Random();
  Size? _screenSize;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 25),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _initializeParticles(Size size) {
    if (size == _screenSize) return;
    _screenSize = size;
    _particles.clear();
    int particleCount = 35;
    for (int i = 0; i < particleCount; i++) {
      _particles.add(_createParticle(size));
    }
  }

  ProParticle _createParticle(Size size) {
    return ProParticle(
      position: Offset(_random.nextDouble() * size.width, _random.nextDouble() * size.height),
      color: [Colors.purple, Colors.indigo, Colors.teal, Colors.amber][_random.nextInt(4)]
          .withOpacity(_random.nextDouble() * 0.15 + 0.05),
      radius: _random.nextDouble() * 25 + 8,
      velocity: Offset((_random.nextDouble() - 0.5) * 0.6, (_random.nextDouble() - 0.5) * 0.6),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = Size(constraints.maxWidth, constraints.maxHeight);
        _initializeParticles(size);
        return AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return CustomPaint(
              painter: ProBackgroundPainter(_particles, _random),
              child: Container(),
            );
          },
        );
      },
    );
  }
}

class ProParticle {
  Offset position;
  Color color;
  double radius;
  Offset velocity;
  ProParticle({required this.position, required this.color, required this.radius, required this.velocity});
}

class ProBackgroundPainter extends CustomPainter {
  final List<ProParticle> particles;
  final Random random;
  ProBackgroundPainter(this.particles, this.random);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    if (particles.isEmpty) return;
    for (var particle in particles) {
      particle.position += particle.velocity;
      if (particle.position.dx < -particle.radius) {
        particle.position = Offset(size.width + particle.radius, random.nextDouble() * size.height);
      } else if (particle.position.dx > size.width + particle.radius) {
        particle.position = Offset(-particle.radius, random.nextDouble() * size.height);
      }
      if (particle.position.dy < -particle.radius) {
        particle.position = Offset(random.nextDouble() * size.width, size.height + particle.radius);
      } else if (particle.position.dy > size.height + particle.radius) {
        particle.position = Offset(random.nextDouble() * size.width, -particle.radius);
      }
      paint.color = particle.color;
      canvas.drawCircle(particle.position, particle.radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class ChatBotProPage extends StatefulWidget {
  const ChatBotProPage({super.key});

  @override
  State<ChatBotProPage> createState() => _ChatBotProPageState();
}

class _ChatBotProPageState extends State<ChatBotProPage> with TickerProviderStateMixin {
  static const double _kAppBarHeight = 56;

  final TextEditingController messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _focusNode = FocusNode();

  List<Map<String, dynamic>> currentMessages = [];
  bool isTyping = false;
  bool _showScrollButton = false;
  int? currentConsultationId;
  String? emergencyLevel;
  List<String> symptoms = [];

  @override
  void initState() {
    super.initState();
    _setupScrollController();
    _loadConsultationHistory();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    messageController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _setupScrollController() {
    _scrollController.addListener(() {
      setState(() => _showScrollButton = _scrollController.offset >= 400);
    });
  }

  Future<void> _loadConsultationHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final accessToken = prefs.getString('access_token');
    if (accessToken == null) return;

    try {
      final response = await http.get(
        Uri.parse('https://api.medogram.ir/api/chatbot-pro/my/'),
        headers: {'Authorization': 'Bearer $accessToken'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> consultations = jsonDecode(utf8.decode(response.bodyBytes));
        if (consultations.isNotEmpty) {
          final latest = consultations.first;
          if (latest['status'] != 'completed') {
            setState(() {
              currentConsultationId = latest['id'];
              currentMessages = (latest['messages'] as List).map((msg) => {
                'id': msg['id'].toString(),
                'text': msg['content'],
                'sender': msg['sender'] == 'patient' ? 'user' : 'ai',
                'timestamp': msg['created_at'],
              }).toList();
            });
          }
        }
      }
    } catch (e) {
      // Handle error silently for now
    }
  }

  Future<void> sendMessage() async {
    final text = messageController.text.trim();
    if (text.isEmpty) return;

    final DateTime now = DateTime.now();
    final userMessage = {
      'id': now.toIso8601String(),
      'text': text,
      'sender': 'user',
      'timestamp': now.toIso8601String(),
    };

    setState(() {
      currentMessages.add(userMessage);
      isTyping = true;
    });

    messageController.clear();
    _scrollToBottom();

    final prefs = await SharedPreferences.getInstance();
    final accessToken = prefs.getString('access_token');
    if (accessToken == null || accessToken.isEmpty) {
      CustomSnackBar.show('توکن دسترسی پیدا نشد.', context, isError: true);
      setState(() => isTyping = false);
      return;
    }

    try {
      final requestBody = {
        'message': text,
        if (currentConsultationId != null) 'consultation_id': currentConsultationId,
      };

      final response = await http
          .post(
            Uri.parse('https://api.medogram.ir/api/chatbot-pro/consult/'),
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'Authorization': 'Bearer $accessToken',
            },
            body: jsonEncode(requestBody),
          )
          .timeout(const Duration(seconds: 30));

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        
        // Update consultation ID
        if (currentConsultationId == null) {
          currentConsultationId = data['consultation_id'];
        }

        final responseData = data['response'];
        final botMessage = {
          'id': DateTime.now().toIso8601String(),
          'text': responseData['explanation'],
          'sender': 'ai',
          'timestamp': DateTime.now().toIso8601String(),
          'emergency': responseData['emergency'] ?? false,
          'emergency_level': responseData['emergency_level'] ?? 0,
          'symptoms': List<String>.from(responseData['symptoms'] ?? []),
          'domain': responseData['domain'] ?? '',
        };

        setState(() {
          currentMessages.add(botMessage);
          isTyping = false;
          emergencyLevel = responseData['emergency_level'].toString();
          symptoms = List<String>.from(responseData['symptoms'] ?? []);
        });

        // Show emergency warning if needed
        if (responseData['emergency_level'] == 3) {
          _showEmergencyDialog();
        }

        _scrollToBottom();
      } else if (response.statusCode == 401) {
        CustomSnackBar.show('لطفاً دوباره وارد شوید.', context, isError: true);
      } else {
        CustomSnackBar.show('خطا در ارسال پیام. لطفاً دوباره تلاش کنید.', context, isError: true);
      }
    } on TimeoutException {
      if (mounted) {
        CustomSnackBar.show('زمان انتظار به پایان رسید. لطفاً دوباره تلاش کنید.', context, isError: true);
      }
    } catch (e) {
      if (mounted) {
        CustomSnackBar.show('خطا در اتصال: $e', context, isError: true);
      }
    } finally {
      if (mounted) setState(() => isTyping = false);
    }
  }

  void _showEmergencyDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext ctx) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          backgroundColor: Colors.red.shade50,
          title: Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.red.shade600, size: 28),
              const SizedBox(width: 8),
              const Text('هشدار اورژانس!', style: TextStyle(color: Colors.red)),
            ],
          ),
          content: const Text(
            'بر اساس علائم شما، توصیه می‌شود فوراً به اورژانس مراجعه کنید.',
            style: TextStyle(fontSize: 16),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                _endConsultation('emergency');
              },
              child: Text('متوجه شدم', style: TextStyle(color: Colors.red.shade600)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _endConsultation(String reason) async {
    if (currentConsultationId == null) return;

    final prefs = await SharedPreferences.getInstance();
    final accessToken = prefs.getString('access_token');
    if (accessToken == null) return;

    try {
      await http.post(
        Uri.parse('https://api.medogram.ir/api/chatbot-pro/end/'),
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({
          'consultation_id': currentConsultationId,
          'reason': reason,
        }),
      );

      setState(() {
        currentConsultationId = null;
      });
    } catch (e) {
      // Handle error silently
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _shareChat() {
    if (currentMessages.isEmpty) {
      CustomSnackBar.show('چتی برای اشتراک گذاری وجود ندارد.', context);
      return;
    }
    final chatText = currentMessages.map((m) => '${m['sender']}: ${m['text']}').join('\n');
    Share.share(chatText, subject: 'مشاوره من با DocAI Pro');
  }

  Future<void> _showEndConsultationDialog() async {
    if (currentConsultationId == null) {
      CustomSnackBar.show('مشاوره‌ای فعال نیست.', context);
      return;
    }

    showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('پایان مشاوره'),
          content: const Text('آیا مطمئن هستید که می‌خواهید این مشاوره را پایان دهید؟'),
          actions: [
            TextButton(
              child: const Text('لغو'),
              onPressed: () => Navigator.of(ctx).pop(),
            ),
            TextButton(
              child: Text('پایان', style: TextStyle(color: Colors.orange.shade600)),
              onPressed: () {
                _endConsultation('completed');
                Navigator.of(ctx).pop();
                CustomSnackBar.show('مشاوره با موفقیت پایان یافت.', context);
              },
            ),
          ],
        );
      },
    );
  }

  void _navigateToNormalChat() {
    Navigator.of(context).pushReplacementNamed('/chat_room');
    // یا اگر از route name استفاده نمی‌کنید:
    // Navigator.of(context).pushReplacement(
    //   MaterialPageRoute(builder: (context) => const ChatRoom()),
    // );
  }

  PreferredSize _buildAppBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(_kAppBarHeight),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.purple.shade600, Colors.indigo.shade700],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.purple.withOpacity(0.3),
              blurRadius: 15,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: SafeArea(
          bottom: false,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // دکمه خروج از چت‌بات پرو (سمت راست در RTL)
              IconButton(
                icon: const Icon(Icons.arrow_forward, color: Colors.white, size: 24),
                onPressed: _navigateToNormalChat,
                splashRadius: 22,
                tooltip: 'بازگشت به چت عادی',
              ),
              
              // تایتل وسط
              AnimatedProTitle(onProTap: () {}),
              
              // دکمه‌های عملیات (سمت چپ در RTL)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.share, color: Colors.white),
                    onPressed: _shareChat,
                    splashRadius: 22,
                  ),
                  IconButton(
                    icon: const Icon(Icons.stop_circle_outlined, color: Colors.white),
                    onPressed: _showEndConsultationDialog,
                    splashRadius: 22,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      child: Row(
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: Colors.purple.shade100,
            child: Icon(Icons.psychology, size: 16, color: Colors.purple.shade700),
          ),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.8),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(18),
                topRight: Radius.circular(18),
                bottomLeft: Radius.circular(4),
                bottomRight: Radius.circular(18),
              ),
              border: Border.all(color: Colors.purple.withOpacity(0.2)),
            ),
            child: DefaultTextStyle(
              style: TextStyle(fontSize: 13, color: Colors.purple.shade700),
              child: AnimatedTextKit(
                repeatForever: true,
                animatedTexts: [WavyAnimatedText('در حال تحلیل...')],
                isRepeatingAnimation: true,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: _buildAppBar(),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Stack(
          children: [
            const Positioned.fill(child: AnimatedProBackground()),
            Column(
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.only(top: 16, bottom: 20),
                        itemCount: currentMessages.length,
                        itemBuilder: (ctx, idx) => ChatBotProMessageBubble(
                          msg: currentMessages[idx],
                          index: idx,
                          onDelete: () {
                            setState(() {
                              currentMessages.removeAt(idx);
                            });
                          },
                        ),
                      ),
                      if (_showScrollButton)
                        Positioned(
                          right: 16,
                          bottom: 20,
                          child: FloatingActionButton(
                            mini: true,
                            backgroundColor: Colors.purple.shade600,
                            elevation: 4,
                            onPressed: _scrollToBottom,
                            child: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                          ),
                        ),
                    ],
                  ),
                ),
                if (isTyping) _buildTypingIndicator(),
                ChatBotProInputArea(
                  messageController: messageController,
                  focusNode: _focusNode,
                  onSend: sendMessage,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
