// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ChatBotProInputArea extends StatefulWidget {
  final TextEditingController messageController;
  final FocusNode focusNode;
  final VoidCallback onSend;

  const ChatBotProInputArea({
    super.key,
    required this.messageController,
    required this.focusNode,
    required this.onSend,
  });

  @override
  State<ChatBotProInputArea> createState() => _ChatBotProInputAreaState();
}

class _ChatBotProInputAreaState extends State<ChatBotProInputArea>
    with SingleTickerProviderStateMixin {
  bool _showEmojiPicker = false;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    widget.messageController.addListener(_onInputChanged);
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.elasticOut),
    );
  }

  @override
  void dispose() {
    widget.messageController.removeListener(_onInputChanged);
    _animationController.dispose();
    super.dispose();
  }

  bool get hasText => widget.messageController.text.trim().isNotEmpty;

  void _onInputChanged() {
    setState(() {});
    if (hasText) {
      _animationController.forward();
    } else {
      _animationController.reverse();
    }
  }

  void _toggleEmojiPicker() {
    setState(() => _showEmojiPicker = !_showEmojiPicker);
    if (!_showEmojiPicker) FocusScope.of(context).requestFocus(widget.focusNode);
  }

  void _handleSend() {
    if (!hasText) return;
    widget.onSend();
    HapticFeedback.mediumImpact();
    setState(() => _showEmojiPicker = false);
  }

  void _handlePaste() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null) {
      final text = data!.text!;
      final selection = widget.messageController.selection;
      final newText = widget.messageController.text.replaceRange(
        selection.start,
        selection.end,
        text,
      );
      widget.messageController.value = widget.messageController.value.copyWith(
        text: newText,
        selection: TextSelection.collapsed(offset: selection.start + text.length),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.white.withOpacity(0.9),
                  Colors.white.withOpacity(0.8),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: Colors.purple.withOpacity(0.15),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
              border: Border.all(
                color: Colors.purple.withOpacity(0.2),
                width: 1.5,
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // Voice/Emoji Button
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: IconButton(
                    key: ValueKey(_showEmojiPicker),
                    icon: Icon(
                      _showEmojiPicker ? Icons.keyboard : Icons.emoji_emotions_outlined,
                      color: Colors.purple.shade600,
                      size: 26,
                    ),
                    splashRadius: 24,
                    tooltip: _showEmojiPicker ? 'کیبورد' : 'ایموجی',
                    onPressed: _toggleEmojiPicker,
                  ),
                ),

                // Attachment Button
                IconButton(
                  icon: Icon(
                    Icons.attach_file_rounded,
                    color: Colors.indigo.shade600,
                    size: 24,
                  ),
                  splashRadius: 24,
                  tooltip: 'پیوست',
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text('امکان ارسال فایل در نسخه پرو به زودی...'),
                        backgroundColor: Colors.purple.shade600,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    );
                  },
                ),

                // Text Input Field
                Expanded(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 130),
                    child: Scrollbar(
                      child: TextField(
                        controller: widget.messageController,
                        focusNode: widget.focusNode,
                        textInputAction: TextInputAction.send,
                        minLines: 1,
                        maxLines: 5,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'علائم یا مشکل خود را شرح دهید...',
                          hintStyle: TextStyle(
                            color: theme.hintColor.withOpacity(0.7),
                            fontSize: 15,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 12,
                            horizontal: 10,
                          ),
                        ),
                        style: TextStyle(
                          fontSize: 16,
                          color: theme.textTheme.bodyLarge!.color,
                          height: 1.4,
                        ),
                        textDirection: TextDirection.rtl,
                        onSubmitted: (_) => _handleSend(),
                        onTap: () => setState(() => _showEmojiPicker = false),
                        enableSuggestions: true,
                        autocorrect: true,
                      ),
                    ),
                  ),
                ),

                // Paste Button
                IconButton(
                  icon: Icon(
                    Icons.content_paste_go_rounded,
                    size: 23,
                    color: Colors.teal.shade600,
                  ),
                  splashRadius: 24,
                  tooltip: 'چسباندن',
                  onPressed: _handlePaste,
                ),

                // Animated Send Button
                AnimatedBuilder(
                  animation: _scaleAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _scaleAnimation.value,
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        transitionBuilder: (child, animation) => ScaleTransition(
                          scale: animation,
                          child: child,
                        ),
                        child: hasText
                            ? Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: _handleSend,
                                  borderRadius: BorderRadius.circular(24),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          Colors.purple.shade500,
                                          Colors.indigo.shade600,
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      borderRadius: BorderRadius.circular(24),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.purple.withOpacity(0.3),
                                          blurRadius: 8,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    padding: const EdgeInsets.all(12),
                                    child: const Icon(
                                      Icons.send_rounded,
                                      color: Colors.white,
                                      size: 22,
                                    ),
                                  ),
                                ),
                              )
                            : Container(
                                padding: const EdgeInsets.all(12),
                                child: Icon(
                                  Icons.send_rounded,
                                  color: Colors.grey.shade400,
                                  size: 22,
                                ),
                              ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
