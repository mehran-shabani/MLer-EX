// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';

class ChatBotProMessageBubble extends StatelessWidget {
  final Map<String, dynamic> msg;
  final int index;
  final VoidCallback onDelete;

  const ChatBotProMessageBubble({
    super.key,
    required this.msg,
    required this.index,
    required this.onDelete,
  });

  String _formatTime(DateTime ts) => DateFormat('HH:mm').format(ts);

  Color _getEmergencyColor(int level) {
    switch (level) {
      case 1:
        return Colors.yellow.shade600;
      case 2:
        return Colors.orange.shade600;
      case 3:
        return Colors.red.shade600;
      default:
        return Colors.green.shade600;
    }
  }

  IconData _getEmergencyIcon(int level) {
    switch (level) {
      case 1:
        return Icons.info_outline;
      case 2:
        return Icons.warning_amber_outlined;
      case 3:
        return Icons.emergency;
      default:
        return Icons.check_circle_outline;
    }
  }

  String _getEmergencyText(int level) {
    switch (level) {
      case 1:
        return 'توجه';
      case 2:
        return 'هشدار';
      case 3:
        return 'اورژانس';
      default:
        return 'عادی';
    }
  }

  @override
  Widget build(BuildContext context) {
    final isUser = msg['sender'] == 'user';
    final theme = Theme.of(context);

    final borderRadius = BorderRadius.only(
      topLeft: const Radius.circular(20),
      topRight: const Radius.circular(20),
      bottomLeft: isUser ? const Radius.circular(20) : const Radius.circular(6),
      bottomRight: isUser ? const Radius.circular(6) : const Radius.circular(20),
    );

    final emergencyLevel = msg['emergency_level'] ?? 0;
    final symptoms = msg['symptoms'] as List<String>? ?? [];
    final domain = msg['domain'] ?? '';

    return Slidable(
      key: ValueKey('${msg['id']}_$index'),
      endActionPane: ActionPane(
        motion: const ScrollMotion(),
        children: [
          SlidableAction(
            onPressed: (_) => onDelete(),
            backgroundColor: Colors.red.shade600,
            foregroundColor: Colors.white,
            icon: Icons.delete,
            label: 'حذف',
            borderRadius: BorderRadius.circular(12),
          ),
        ],
      ),
      child: AnimationConfiguration.staggeredList(
        position: index,
        duration: const Duration(milliseconds: 280),
        child: SlideAnimation(
          verticalOffset: 28,
          child: FadeInAnimation(
            child: Align(
              alignment: isUser
                  ? AlignmentDirectional.centerEnd
                  : AlignmentDirectional.centerStart,
              child: Padding(
                padding: EdgeInsetsDirectional.only(
                  end: isUser ? 8 : 70,
                  start: isUser ? 70 : 8,
                  top: 3,
                  bottom: 3,
                ),
                child: GestureDetector(
                  onTap: () {
                    final time = _formatTime(DateTime.parse(msg['timestamp']));
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('ارسال‌شده در $time'),
                        duration: const Duration(milliseconds: 1200),
                        backgroundColor: Colors.black87,
                        behavior: SnackBarBehavior.floating,
                        margin: const EdgeInsets.symmetric(horizontal: 80, vertical: 12),
                      ),
                    );
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.easeOut,
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.8,
                    ),
                    padding: const EdgeInsets.all(16),
                    decoration: isUser
                        ? BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.indigo.shade500,
                                Colors.purple.shade600,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: borderRadius,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.purple.withOpacity(0.25),
                                blurRadius: 10,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          )
                        : BoxDecoration(
                            color: Colors.white.withOpacity(0.9),
                            borderRadius: borderRadius,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.08),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ],
                            border: Border.all(
                              color: _getEmergencyColor(emergencyLevel).withOpacity(0.3),
                              width: 1.5,
                            ),
                          ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // AI response header with domain info
                        if (!isUser && domain.isNotEmpty) ...[
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.purple.shade100,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'تخصص: $domain',
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.purple.shade700,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                        ],

                        // Message text
                        SelectableText(
                          msg['text'] ?? '',
                          style: TextStyle(
                            color: isUser
                                ? Colors.white
                                : theme.brightness == Brightness.dark
                                    ? Colors.grey[100]
                                    : Colors.grey[800],
                            fontSize: 16,
                            height: 1.5,
                            fontFamily: 'Vazirmatn',
                          ),
                          textDirection: Directionality.of(context),
                        ),

                        // Emergency level indicator for AI messages
                        if (!isUser && emergencyLevel > 0) ...[
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: _getEmergencyColor(emergencyLevel).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: _getEmergencyColor(emergencyLevel).withOpacity(0.4),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  _getEmergencyIcon(emergencyLevel),
                                  size: 16,
                                  color: _getEmergencyColor(emergencyLevel),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  _getEmergencyText(emergencyLevel),
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: _getEmergencyColor(emergencyLevel),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],

                        // Symptoms list for AI messages
                        if (!isUser && symptoms.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.blue.shade200),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.medical_services, size: 14, color: Colors.blue.shade600),
                                    const SizedBox(width: 4),
                                    Text(
                                      'علائم شناسایی شده:',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blue.shade700,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Wrap(
                                  spacing: 4,
                                  runSpacing: 2,
                                  children: symptoms.map((symptom) {
                                    return Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Colors.blue.shade100,
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Text(
                                        symptom,
                                        style: TextStyle(
                                          fontSize: 10,
                                          color: Colors.blue.shade800,
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ],
                            ),
                          ),
                        ],

                        const SizedBox(height: 8),
                        // Time and status row
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          textDirection: Directionality.of(context),
                          children: [
                            Text(
                              _formatTime(DateTime.parse(msg['timestamp'])),
                              style: TextStyle(
                                color: isUser ? Colors.white70 : Colors.grey.shade600,
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            if (isUser) ...[
                              const SizedBox(width: 4),
                              Icon(
                                Icons.done_all,
                                size: 14,
                                color: Colors.white70,
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
