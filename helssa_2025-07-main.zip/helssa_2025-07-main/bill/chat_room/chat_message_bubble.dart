// ignore_for_file: deprecated_member_use
//
// کامل‌ترین بازنویسی برای افزودن افکت «نمایش خط‌به‌خط» روی پیام‌ها

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';

/// ─────────────────────────────────────────────────────────────
/// ❶ ویجت کمکی برای نمایش تدریجی متن (خط‌به‌خط یا کاراکتر‌به‌کاراکتر)
/// ─────────────────────────────────────────────────────────────
class LineRevealText extends StatefulWidget {
  const LineRevealText({
    super.key,
    required this.text,
    this.style,
    this.delayPerItem = const Duration(milliseconds: 120),
    this.animationDuration = const Duration(milliseconds: 300),
    this.splitByLines = true, // اگر false باشد کاراکتر به کاراکتر
    this.textDirection,
    this.textAlign,
  });

  final String text;
  final TextStyle? style;
  final Duration delayPerItem;       // فاصله بین ظاهر شدن آیتم‌ها
  final Duration animationDuration;  // مدت خود انیمیشن Opacity
  final bool splitByLines;           // true => line, false => char
  final TextDirection? textDirection;
  final TextAlign? textAlign;

  @override
  State<LineRevealText> createState() => _LineRevealTextState();
}

class _LineRevealTextState extends State<LineRevealText> {
  late final List<String> _items; // خطوط یا کاراکترها
  int _visibleItems = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    _items = widget.splitByLines
        ? widget.text.split('\n')
        : widget.text.split('');

    // شروع شمارش معکوس برای نمایش آیتم‌های بیشتر
    _timer = Timer.periodic(widget.delayPerItem, (t) {
      if (!mounted) return;
      if (_visibleItems < _items.length) {
        setState(() => _visibleItems++);
      } else {
        t.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // اگر کل متن خالی بود، چیزی رندر نکنیم
    if (_items.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(_items.length, (i) {
        final content = _items[i].isEmpty ? ' ' : _items[i];
        return AnimatedOpacity(
          opacity: i < _visibleItems ? 1 : 0,
          duration: widget.animationDuration,
          curve: Curves.easeOut,
          child: Padding(
            padding: EdgeInsets.only(
              bottom: widget.splitByLines ? 2 : 0,
            ),
            child: SelectableText(
              content,
              style: widget.style,
              textDirection: widget.textDirection,
              textAlign: widget.textAlign,
            ),
          ),
        );
      }),
    );
  }
}

/// ─────────────────────────────────────────────────────────────
/// ❷ حباب پیام چت
/// ─────────────────────────────────────────────────────────────
class ChatMessageBubble extends StatelessWidget {
  const ChatMessageBubble({
    super.key,
    required this.msg,
    required this.index,
    required this.onDelete,
  });

  final Map<String, dynamic> msg;
  final int index;
  final VoidCallback onDelete;

  String _formatTime(DateTime ts) => DateFormat('HH:mm').format(ts);

  @override
  Widget build(BuildContext context) {
    final isUser = msg['sender'] == 'user';
    final theme = Theme.of(context);

    final borderRadius = BorderRadius.only(
      topLeft: const Radius.circular(18),
      topRight: const Radius.circular(18),
      bottomLeft: isUser ? const Radius.circular(18) : const Radius.circular(4),
      bottomRight: isUser ? const Radius.circular(4) : const Radius.circular(18),
    );

    final BoxDecoration botGlassDecoration = BoxDecoration(
      color: Colors.white.withOpacity(0.6),
      borderRadius: borderRadius,
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.04),
          blurRadius: 8,
          offset: const Offset(0, 2),
        ),
      ],
      border: Border.all(color: Colors.grey.withOpacity(0.15)),
    );

    return Slidable(
      key: ValueKey('${msg['id']}_$index'),
      endActionPane: ActionPane(
        motion: const ScrollMotion(),
        children: [
          SlidableAction(
            onPressed: (_) => onDelete(),
            backgroundColor: Colors.red.shade600,
            foregroundColor: Colors.white,
            icon: Icons.delete,
            label: 'حذف',
            borderRadius: BorderRadius.circular(12),
          ),
        ],
      ),
      child: AnimationConfiguration.staggeredList(
        position: index,
        duration: const Duration(milliseconds: 240),
        child: SlideAnimation(
          verticalOffset: 32,
          child: FadeInAnimation(
            child: Align(
              alignment: isUser
                  ? AlignmentDirectional.centerEnd
                  : AlignmentDirectional.centerStart,
              child: Padding(
                padding: EdgeInsetsDirectional.only(
                  end: isUser ? 6 : 60,
                  start: isUser ? 60 : 6,
                  top: 2,
                  bottom: 2,
                ),
                child: GestureDetector(
                  onTap: () {
                    final time = _formatTime(DateTime.parse(msg['timestamp']));
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('ارسال‌شده در $time'),
                        duration: const Duration(milliseconds: 1200),
                        backgroundColor: Colors.black87,
                        behavior: SnackBarBehavior.floating,
                        margin: const EdgeInsets.symmetric(
                            horizontal: 80, vertical: 12),
                      ),
                    );
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOut,
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.75,
                    ),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: isUser
                        ? BoxDecoration(
                            gradient: LinearGradient(
                              colors: theme.brightness == Brightness.light
                                  ? [
                                      Colors.blue.shade400,
                                      Colors.blue.shade700,
                                    ]
                                  : [
                                      Colors.lightBlueAccent.shade200,
                                      Colors.blueGrey.shade800,
                                    ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: borderRadius,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.blue.withOpacity(0.09),
                                blurRadius: 7,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          )
                        : botGlassDecoration,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ── متن با افکت نمایشی جدید ────────────────────────────
                        LineRevealText(
                          text: msg['text'] ?? '',
                          style: TextStyle(
                            color: isUser
                                ? Colors.white
                                : theme.brightness == Brightness.dark
                                    ? Colors.grey[100]
                                    : Colors.grey[900],
                            fontSize: 16,
                            height: 1.45,
                            fontFamily: 'Vazirmatn',
                          ),
                          textDirection: Directionality.of(context),
                          splitByLines:
                              true, // اگر false شود کاراکتر به کاراکتر
                          delayPerItem:
                              const Duration(milliseconds: 110), // شخصی‌سازی
                        ),

                        const SizedBox(height: 6),
                        // ── ردیف زمان و تیک‌ها ───────────────────────────────
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          textDirection: Directionality.of(context),
                          children: [
                            Text(
                              _formatTime(DateTime.parse(msg['timestamp'])),
                              style: TextStyle(
                                color:
                                    isUser ? Colors.white70 : Colors.grey.shade600,
                                fontSize: 11,
                              ),
                            ),
                            if (isUser) ...[
                              const SizedBox(width: 4),
                              const Icon(Icons.done_all,
                                  size: 14, color: Colors.white70),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
