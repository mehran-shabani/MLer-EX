// visit_page.dart
// ignore_for_file: use_build_context_synchronously, deprecated_member_use, library_private_types_in_public_api

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../utils/snackbar.dart';
import 'special_visit_page.dart';
import 'doctor_drawer.dart';
import 'prescription/previous_prescriptions_page.dart';
import 'visit_service.dart';   // ⬅️ سرویس جداشده

class VisitPage extends StatefulWidget {
  const VisitPage({super.key});

  @override
  _VisitPageState createState() => _VisitPageState();
}

class _VisitPageState extends State<VisitPage> with SingleTickerProviderStateMixin {
/*────────────────────────── کنترلرهای فرم ──────────────────────────*/
  final nameController         = TextEditingController();
  final nationalCodeController = TextEditingController();
  final detailsController      = TextEditingController();

/*──────────────────────────── انیمیشن ورودی ─────────────────────────*/
  late final AnimationController _pageAnimCtrl =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))
        ..forward();
  late final Animation<double> _fadeAnimation =
      CurvedAnimation(parent: _pageAnimCtrl, curve: Curves.easeInOut);

/*────────────────────────────  رنگ‌های ثابت  ─────────────────────────*/
  final _accentColor    = const Color(0xFF3E78BB);
  final _lightBlue      = const Color(0xFF6B96D1);
  final _darkBlue       = const Color(0xFF2C5F99);
  final _paleBlue       = const Color(0xFFE8F2FF);
  final _softBlue       = const Color(0xFF4A84C7);
  final _backgroundBlue = const Color(0xFFF5F9FF);

/*────────────────────────────  برچسب‌های راه ارتباطی  ────────────────*/
  static const _contactLabels = <String, String>{
    'whatsapp': 'واتس‌اپ',
    'bale'    : 'بله',
    'eitaa'   : 'ایتا',
    'phone'   : 'تلفن',
  };

/*────────────────────────────  وضعیت صفحه  ───────────────────────────*/
  final _formKey = GlobalKey<FormState>();
  bool   _loading                 = false;
  bool   _needsMedicalCertificate = false;
  bool   _isContactExpanded       = false;
  String _contactMethod           = 'whatsapp';
  bool   _copyPreviousPrescription = false;

/*──────────────────────────── کلید ExpansionTile ─────────────────────*/
  Key _contactTileKey = UniqueKey();

/*──────────────────────────── پذیرش پزشک آن‌کال ───────────────────────*/
  bool _isDoctorLoading = false;
  OverlayEntry? _doctorOverlay;
  Timer?        _overlayTimer;
  static const _autoHideDuration = Duration(seconds: 4);

/*──────────────────────────── ریست فرم ───────────────────────────────*/
  void _resetForm() {
    _formKey.currentState?.reset();
    setState(() {
      nameController.clear();
      nationalCodeController.clear();
      detailsController.clear();
      _contactMethod            = 'whatsapp';
      _needsMedicalCertificate  = false;
      _copyPreviousPrescription = false;
      _isContactExpanded        = false;
      _contactTileKey           = UniqueKey();   // برای بستن کشو
    });
    FocusScope.of(context).unfocus();
  }

/*──────────────────────────── ارسال ویزیت ────────────────────────────*/
  Future<void> _sendVisit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);

    final prefs       = await SharedPreferences.getInstance();
    final accessToken = prefs.getString('access_token');
    if (accessToken == null || accessToken.isEmpty) {
      CustomSnackBar.show('توکن دسترسی پیدا نشد.', context, isError: true);
      setState(() => _loading = false);
      return;
    }

    try {
      final res = await VisitService.sendVisit(
        name            : nameController.text,
        nationalCode    : nationalCodeController.text,
        details         : detailsController.text,
        needsCertificate: _needsMedicalCertificate,
        contactMethod   : _contactLabels[_contactMethod]!,
        accessToken     : accessToken,
      );

      if (res.statusCode >= 200 && res.statusCode < 300) {
        CustomSnackBar.show('ویزیت با موفقیت ثبت شد.', context);
        _resetForm();
      } else if (res.statusCode == 400) {
        final err = jsonDecode(res.body)['error'] ?? 'مشکل در ثبت ویزیت.';
        CustomSnackBar.show(err.toString(), context, isError: true);
      } else if (res.statusCode == 401) {
        CustomSnackBar.show('خطای احراز هویت. لطفاً دوباره وارد شوید.', context, isError: true);
      } else {
        CustomSnackBar.show('خطا (${res.statusCode}).', context, isError: true);
      }
    } catch (e) {
      CustomSnackBar.show('خطا در اتصال: $e', context, isError: true);
    } finally {
      setState(() => _loading = false);
    }
  }

/*──────────────────────────── پزشک آن‌کال ────────────────────────────*/
  Future<void> _toggleDoctorOverlay() async {
    if (_doctorOverlay != null) {
      _removeDoctorOverlay();
      return;
    }
    setState(() => _isDoctorLoading = true);

    try {
      final data = await VisitService.fetchOnCallDoctor();
      if (data == null) {
        _showDoctorOverlay(message: 'پزشکی در دسترس نیست.');
      } else {
        _showDoctorOverlay(
          name     : data['full_name'] ?? '---',
          specialty: data['specialty'] ?? '---',
          imageUrl : data['image']     as String?,
        );
      }
    } catch (_) {
      _showDoctorOverlay(message: 'خطا در اتصال به سرور.');
    } finally {
      setState(() => _isDoctorLoading = false);
    }
  }

  void _showDoctorOverlay({String? name, String? specialty, String? imageUrl, String? message}) {
    final overlay = OverlayEntry(
      builder: (_) => Positioned(
        top  : MediaQuery.of(context).padding.top + 12,
        right: 12,
        child: DoctorDrawer(
          accent   : _accentColor,
          paleBlue : _paleBlue,
          name     : name,
          specialty: specialty,
          imageUrl : imageUrl,
          message  : message,
        ),
      ),
    );
    Overlay.of(context, rootOverlay: true).insert(overlay);
    _doctorOverlay = overlay;

    _overlayTimer?.cancel();
    _overlayTimer = Timer(_autoHideDuration, _removeDoctorOverlay);
  }

  void _removeDoctorOverlay() {
    _overlayTimer?.cancel();
    _overlayTimer = null;
    _doctorOverlay?.remove();
    _doctorOverlay = null;
  }

/*──────────────────────────── انتخاب راه ارتباطی ─────────────────────*/
  void _onContactSelected(String val) {
    setState(() {
      _contactMethod     = val;
      _isContactExpanded = false;
      _contactTileKey    = UniqueKey();  // بسته‌شدن ExpansionTile
    });
  }

/*──────────────────────────── نسخه‌های قبلی ─────────────────────────*/
  void _showPreviousPrescriptionsPage() async {
    final result = await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const PreviousPrescriptionsPage()),
    );
    if (result is String && result.isNotEmpty) {
      setState(() {
        detailsController.text = detailsController.text.isNotEmpty
            ? '${detailsController.text}\n\nنسخه داروها:\n$result'
            : 'نسخه داروها:\n$result';
      });
    }
  }

/*──────────────────────────── UI صفحه ───────────────────────────────*/
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _backgroundBlue,
        appBar: AppBar(
          title: const Text('ثبت ویزیت',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          centerTitle: true,
          elevation: 0,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end  : Alignment.bottomRight,
                colors: [_accentColor, _softBlue, _lightBlue],
              ),
            ),
          ),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: FadeTransition(
          opacity: _fadeAnimation,
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _infoCard(),
                  const SizedBox(height: 12),
                  _doctorButton(),
                  const SizedBox(height: 24),
                  _patientInfoCard(),
                  const SizedBox(height: 20),
                  _descriptionCard(),
                  const SizedBox(height: 20),
                  _contactCard(),
                  const SizedBox(height: 20),
                  _certificateCard(),
                  const SizedBox(height: 24),
                  _submitButton(),
                  const SizedBox(height: 16),
                  _specialVisitButton(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

/*────────────────────────  ویجت‌های ثابت  ───────────────────────────*/

  Widget _doctorButton() => ElevatedButton.icon(
        onPressed: _isDoctorLoading ? null : _toggleDoctorOverlay,
        icon : _isDoctorLoading
            ? const SizedBox(
                width : 18,
                height: 18,
                child : CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            : const Icon(Icons.local_hospital),
        label: Text(
          _isDoctorLoading ? 'در حال جست‌وجو...' : 'پزشک کیه؟',
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: _accentColor,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      );

  Widget _infoCard() => Container(
        decoration: BoxDecoration(
          color: _paleBlue,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _lightBlue.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: _accentColor.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(Icons.info_outline,
                    color: Colors.red.shade600, size: 24),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'لطفاً پیش از ثبت ویزیت از کافی بودن موجودی کیف پول خود اطمینان حاصل کنید (مبلغ ویزیت: ۴۰٬۰۰۰ تومان).',
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      );

  Widget _patientInfoCard() => _cardWrapper(
        'اطلاعات بیمار',
        Icons.person_outline,
        [
          _field(controller: nameController, label: 'نام بیمار', icon: Icons.person),
          const SizedBox(height: 12),
          _field(
            controller: nationalCodeController,
            label     : 'کد ملی',
            icon      : Icons.badge_outlined,
            validator : _validateNationalCode,
          ),
        ],
      );

  Widget _descriptionCard() => _cardWrapper(
        'توضیحات و شرح بیماری',
        Icons.description_outlined,
        [
          _field(
            controller: detailsController,
            label    : 'توضیحات و شرح بیماری',
            icon     : Icons.edit_note,
            maxLines : 4,
          ),
          const SizedBox(height: 16),
          CheckboxListTile(
            value           : _copyPreviousPrescription,
            onChanged       : (value) {
              setState(() => _copyPreviousPrescription = value ?? false);
              if (_copyPreviousPrescription) _showPreviousPrescriptionsPage();
            },
            title           : const Text('میخواهم داروهای مصرفیم را نسخه کنید.',
                style: TextStyle(fontSize: 14)),
            controlAffinity : ListTileControlAffinity.leading,
            contentPadding  : EdgeInsets.zero,
          ),
        ],
      );

  Widget _contactCard() => _cardWrapper(
        'راه ارتباطی',
        Icons.contact_phone_outlined,
        [_contactSelector()],
      );

  Widget _certificateCard() => _cardWrapper(
        'گواهی پزشکی',
        Icons.medical_services_outlined,
        [
          Container(
            decoration: BoxDecoration(
              color: _paleBlue,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _lightBlue.withOpacity(0.3)),
            ),
            child: CheckboxListTile(
              title           : const Text('آیا بیمار نیاز به استعلاجی دارد؟',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              value           : _needsMedicalCertificate,
              onChanged       : (v) =>
                  setState(() => _needsMedicalCertificate = v ?? false),
              controlAffinity : ListTileControlAffinity.leading,
              activeColor     : _accentColor,
              checkColor      : Colors.white,
              shape           : RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      );

  Widget _submitButton() => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: _accentColor.withOpacity(0.4),
              blurRadius: 14,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: _loading ? null : _sendVisit,
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 20),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            elevation: 0,
          ),
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _loading
                    ? [_lightBlue.withOpacity(0.6), _accentColor.withOpacity(0.6)]
                    : [_accentColor, _softBlue],
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Container(
              alignment: Alignment.center,
              child: _loading
                  ? const SizedBox(
                      height: 28,
                      width : 28,
                      child : CircularProgressIndicator(strokeWidth: 2.3, color: Colors.white),
                    )
                  : const Text(
                      'ثبت ویزیت (۴۰٬۰۰۰ تومان)',
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
            ),
          ),
        ),
      );

  Widget _specialVisitButton() => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: _lightBlue.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: OutlinedButton.icon(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const SpecialVisitPage()));
          },
          icon : Icon(Icons.medical_services, color: _accentColor),
          label: Text('ویزیت‌های شایع',
              style: TextStyle(color: _accentColor, fontWeight: FontWeight.w600)),
          style: OutlinedButton.styleFrom(
            foregroundColor: _accentColor,
            side: BorderSide(color: _accentColor, width: 2),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            padding: const EdgeInsets.symmetric(vertical: 16),
            backgroundColor: Colors.white,
          ),
        ),
      );

/*──────────────────────── ویجت‌های کمکی تکرارشونده ──────────────────*/
  Widget _cardWrapper(String title, IconData icon, List<Widget> children) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: _accentColor.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_accentColor, _softBlue]),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(icon, color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: _darkBlue,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ...children,
            ],
          ),
        ),
      );

  Widget _field({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    int maxLines = 1,
    String? Function(String?)? validator,
  }) =>
      TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText : label,
          labelStyle: TextStyle(color: _accentColor.withOpacity(0.8)),
          prefixIcon: Icon(icon, color: _accentColor),
          border    : OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: _lightBlue.withOpacity(0.3)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: _lightBlue.withOpacity(0.3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: _accentColor, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.red),
          ),
          filled: true,
          fillColor: _paleBlue.withOpacity(0.3),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        maxLines : maxLines,
        validator: validator ?? (v) => (v?.isEmpty ?? true) ? 'این فیلد نمی‌تواند خالی باشد' : null,
      );

  String? _validateNationalCode(String? v) {
    if (v == null || v.isEmpty) return 'این فیلد نمی‌تواند خالی باشد';
    if (!RegExp(r'^\d{10}$').hasMatch(v)) return 'کد ملی باید ۱۰ رقم باشد';
    return null;
  }

  Widget _contactSelector() => Container(
        decoration: BoxDecoration(
          color: _paleBlue.withOpacity(0.5),
          border      : Border.all(color: _lightBlue.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            key: _contactTileKey,
            title: Text('انتخاب راه ارتباطی',
                style: TextStyle(fontWeight: FontWeight.w600, color: _darkBlue)),
            leading: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: _accentColor,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.contact_phone, color: Colors.white, size: 16),
            ),
            trailing: Icon(
              _isContactExpanded ? Icons.expand_less : Icons.expand_more,
              color: _accentColor,
            ),
            initiallyExpanded: _isContactExpanded,
            onExpansionChanged: (expanded) =>
                setState(() => _isContactExpanded = expanded),
            childrenPadding: const EdgeInsets.only(right: 12, left: 12, bottom: 12),
            children: [
              _contactRadio('whatsapp', 'واتس‌اپ', Icons.chat_bubble),
              _contactRadio('bale',     'بله',     Icons.chat),
              _contactRadio('eitaa',    'ایتا',    Icons.forum),
              _contactRadio('phone',    'تلفن',    Icons.phone),
            ],
          ),
        ),
      );

  Widget _contactRadio(String v, String label, IconData icon) => Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color      : _contactMethod == v ? _accentColor.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border      : Border.all(
            color: _contactMethod == v ? _accentColor : Colors.transparent,
            width: 1,
          ),
        ),
        child: RadioListTile<String>(
          value: v,
          groupValue: _contactMethod,
          onChanged: (val) => _onContactSelected(val!),
          title: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: _darkBlue)),
          secondary: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _contactMethod == v ? _accentColor : _lightBlue,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.white, size: 16),
          ),
          activeColor: _accentColor,
        ),
      );

/*──────────────────────── پایان UI و lifecycle ──────────────────────*/
  @override
  void dispose() {
    _pageAnimCtrl.dispose();
    _overlayTimer?.cancel();
    _removeDoctorOverlay();
    nameController.dispose();
    nationalCodeController.dispose();
    detailsController.dispose();
    super.dispose();
  }
}
