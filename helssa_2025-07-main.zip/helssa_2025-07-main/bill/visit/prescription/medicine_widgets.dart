// lib/prescription/medicine_widgets.dart
// ویجت‌های قابل‌استفادهٔ مجدد برای کارت افزودن دارو و لیست داروها

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

typedef MedCallback = void Function(int index);
typedef AddOrUpdateCallback = void Function();

/// رنگ‌ها و گرادیانت‌های مشترک
const _blue   = LinearGradient(colors:[Color(0xFF3498DB),Color(0xFF2980B9)]);
const _purple = LinearGradient(colors:[Color(0xFF9B59B6),Color(0xFF8E44AD)]);
const _red    = LinearGradient(colors:[Color(0xFFE74C3C),Color(0xFFC0392B)]);
const _orange = LinearGradient(colors:[Color(0xFFE67E22),Color(0xFFD35400)]);
const _teal   = LinearGradient(colors:[Color(0xFF1ABC9C),Color(0xFF16A085)]);
const _green  = LinearGradient(colors:[Color(0xFF27AE60),Color(0xFF2ECC71)]);
const _grey   = LinearGradient(colors:[Color(0xFF95A5A6),Color(0xFF7F8C8D)]);
const _purpleColor = Color(0xFF9B59B6);
const _blueColor   = Color(0xFF3498DB);

/*───────────────────────────────────────────────────────────*/
/// کارت افزودن یا ویرایش دارو
class AddMedicineCard extends StatelessWidget {
  const AddMedicineCard({
    super.key,
    required this.nameCtl,
    required this.doseCtl,
    required this.qtyCtl,
    required this.selPerIntake,
    required this.selFreq,
    required this.onPerChanged,
    required this.onFreqChanged,
    required this.onAddOrUpdate,
    required this.onClear,
    required this.isEditing,
    required this.scaleAnim,
  });

  final TextEditingController nameCtl;
  final TextEditingController doseCtl;
  final TextEditingController qtyCtl;
  final String?  selPerIntake;
  final String?  selFreq;
  final ValueChanged<String?> onPerChanged;
  final ValueChanged<String?> onFreqChanged;
  final AddOrUpdateCallback   onAddOrUpdate;
  final VoidCallback          onClear;
  final bool                  isEditing;
  final Animation<double>     scaleAnim;

  static const _perIntakes = [
    'یک عدد','دو عدد','سه عدد','چهار عدد',
    'نصف','یک چهارم','یک قطره','دو قطره','سه قطره','طبق دستور',
  ];
  static const _freqs = [
    'هر روز','هر شب','هر 6 ساعت','هر 8 ساعت','هر 12 ساعت',
    'یک روز در میان','دو بار در روز','هفتگی','در صورت نیاز','سایر',
  ];

  @override
  Widget build(BuildContext context) => Container(
    decoration:_cardDeco(),
    child:Padding(
      padding:const EdgeInsets.all(24),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        _header(),
        const SizedBox(height:24),
        _field(ctrl:nameCtl,label:'نام دارو',icon:Icons.medication_liquid_rounded,grad:_blue,required:true),
        const SizedBox(height:20),
        _field(ctrl:doseCtl,label:'دوز دارو',icon:Icons.local_pharmacy_rounded,
            grad:_red,required:true,keyboard:TextInputType.number,
            input:[FilteringTextInputFormatter.allow(RegExp(r'^\d+(\.\d{0,1})?'))],
            suffix:const Text('mg')),
        const SizedBox(height:20),
        _field(ctrl:qtyCtl,label:'تعداد',icon:Icons.numbers_rounded,
            grad:_purple,keyboard:TextInputType.number,
            input:[FilteringTextInputFormatter.digitsOnly]),
        const SizedBox(height:20),
        Row(children:[
          Expanded(child:_dropdown(value:selPerIntake,label:'مقدار مصرف',
              icon:Icons.medical_services_rounded,items:_perIntakes,
              onChanged:onPerChanged,grad:_orange)),
          const SizedBox(width:16),
          Expanded(child:_dropdown(value:selFreq,label:'زمان مصرف',
              icon:Icons.schedule_rounded,items:_freqs,
              onChanged:onFreqChanged,grad:_teal)),
        ]),
        const SizedBox(height:24),
        Row(children:[
          if(isEditing)...[
            Expanded(child:_button(onTap:onClear,icon:Icons.clear,label:'لغو',grad:_grey)),
            const SizedBox(width:16),
          ],
          Expanded(
            child:ScaleTransition(scale:scaleAnim,
              child:_button(onTap:onAddOrUpdate,
                icon:isEditing?Icons.edit:Icons.add,
                label:isEditing?'ویرایش':'افزودن',grad:_green)),
          ),
        ]),
      ]),
    ),
  );

  /*───────── عناصر اتمیک ─────────*/
  Widget _field({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    required Gradient grad,
    bool required=false,
    TextInputType? keyboard,
    List<TextInputFormatter>? input,
    Widget? suffix,
  })=>Container(decoration:_fldShadow(),child:TextField(
    controller:ctrl,keyboardType:keyboard,inputFormatters:input,
    decoration:InputDecoration(
      labelText:required?'$label *':label,
      prefixIcon:_prefix(icon,grad),suffix:suffix,
      filled:true,fillColor:Colors.white,border:_border,
      contentPadding:const EdgeInsets.symmetric(horizontal:20,vertical:16)),));

  Widget _dropdown({
    required String? value,
    required String label,
    required IconData icon,
    required List<String> items,
    required ValueChanged<String?> onChanged,
    required Gradient grad,
  })=>Container(decoration:_fldShadow(),
      child:DropdownButtonFormField<String>(
        value:value,onChanged:onChanged,isExpanded:true,
        decoration:InputDecoration(labelText:label,prefixIcon:_prefix(icon,grad),
            filled:true,fillColor:Colors.white,border:_border,
            contentPadding:const EdgeInsets.symmetric(horizontal:20,vertical:16)),
        items:items.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
        icon:const Icon(Icons.keyboard_arrow_down_rounded),
        dropdownColor:Colors.white,borderRadius:BorderRadius.circular(16),));

  Widget _button({
    required VoidCallback onTap,
    required IconData icon,
    required String label,
    required Gradient grad,
  })=>Container(decoration:_btnShadow(grad),child:Material(
      color:Colors.transparent,borderRadius:BorderRadius.circular(16),
      child:InkWell(borderRadius:BorderRadius.circular(16),onTap:onTap,
        child:Padding(
          padding:const EdgeInsets.symmetric(vertical:16),
          child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[
            Icon(icon,color:Colors.white,size:20),const SizedBox(width:8),
            Text(label,style:const TextStyle(color:Colors.white,fontSize:16,fontWeight:FontWeight.w600)),
          ]),))));

  Widget _header()=>Row(children:[
    Container(padding:const EdgeInsets.all(12),decoration:_btnShadow(_blue,radius:16),
      child:const Icon(Icons.medication_liquid_rounded,color:Colors.white)),
    const SizedBox(width:16),
    Text(isEditing?'ویرایش دارو':'افزودن دارو جدید',
        style:const TextStyle(fontSize:18,fontWeight:FontWeight.w700,color:Color(0xFF2C3E50))),
  ]);

  /*───────── دکوراسیون مشترک ────────*/
  Widget _prefix(IconData i,Gradient g)=>Container(
      margin:const EdgeInsets.all(8),padding:const EdgeInsets.all(8),
      decoration:BoxDecoration(gradient:g,borderRadius:BorderRadius.circular(12)),
      child:Icon(i,color:Colors.white,size:20));

  static BoxDecoration _cardDeco({Color? shadow})=>BoxDecoration(
    gradient:const LinearGradient(colors:[Colors.white,Color(0xFFFAFBFC)]),
    borderRadius:BorderRadius.circular(20),
    boxShadow:[BoxShadow(color:shadow??_blueColor.withOpacity(.1),
        blurRadius:24,offset:const Offset(0,8))]);

  static BoxDecoration _fldShadow()=>BoxDecoration(
    borderRadius:BorderRadius.circular(16),boxShadow:[
      BoxShadow(color:Colors.black.withOpacity(.05),blurRadius:12,offset:const Offset(0,4))]);

  static BoxDecoration _btnShadow(Gradient g,{double radius=16})=>BoxDecoration(
    gradient:g,borderRadius:BorderRadius.circular(radius),
    boxShadow:[BoxShadow(color:g.colors.first.withOpacity(.3),
        blurRadius:20,offset:const Offset(0,8))]);

  static InputBorder get _border=>OutlineInputBorder(
      borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none);
}

/*───────────────────────────────────────────────────────────*/
/// ویجت لیست داروها
class MedicineListCard extends StatelessWidget {
  const MedicineListCard({
    super.key,
    required this.meds,
    required this.onEdit,
    required this.onDelete,
  });

  final List<Map<String, String>> meds;
  final MedCallback onEdit;
  final MedCallback onDelete;

  @override
  Widget build(BuildContext context) {
    if (meds.isEmpty) return const SizedBox();
    return Container(
      decoration:AddMedicineCard._cardDeco(shadow:_purpleColor.withOpacity(.1)),
      child:Column(children:[
        Container(
          padding:const EdgeInsets.all(20),
          decoration:BoxDecoration(gradient:_purple,
              borderRadius:const BorderRadius.vertical(top:Radius.circular(20))),
          child:Row(children:[
            const Icon(Icons.list_alt_rounded,color:Colors.white),
            const SizedBox(width:12),
            const Text('لیست داروها',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700,color:Colors.white)),
            const Spacer(), _chip(meds.length),
          ]),
        ),
        ListView.separated(
          shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
          itemCount:meds.length,
          separatorBuilder:(_,__)=>Divider(height:1,color:Colors.grey[200],indent:20,endIndent:20),
          itemBuilder:(_,i)=>_tile(i)),
        const SizedBox(height:8),
      ]),
    );
  }

  Widget _tile(int i){
    final m=meds[i];
    String v(String? s)=>(s?.trim().isNotEmpty??false)?s!.trim():'—';
    final subtitle='💊 ${v(m['perIntake'])} • ⏰ ${v(m['frequency'])} • 📦 ${v(m['quantity'])}';
    return ListTile(
      leading:_circle(),
      title:Text('${m['name']} ${m['doseMg']} mg',
          style:const TextStyle(fontSize:16,fontWeight:FontWeight.w700,color:Color(0xFF2C3E50))),
      subtitle:Text(subtitle,maxLines:2,overflow:TextOverflow.ellipsis,
          style:TextStyle(fontSize:13,color:Colors.grey[600],height:1.3)),
      trailing:Row(mainAxisSize:MainAxisSize.min,children:[
        _actBtn(onTap:()=>onEdit(i),icon:Icons.edit_rounded,grad:_orange),
        const SizedBox(width:8),
        _actBtn(onTap:()=>onDelete(i),icon:Icons.close_rounded,grad:_red),
      ]),
    );
  }

  /* اتم‌های کوچک */
  Widget _chip(int n)=>Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),
      decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(16)),
      child:Text('$n',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w700)));

  Widget _circle()=>Container(width:50,height:50,
      decoration:AddMedicineCard._btnShadow(_blue,radius:25),
      child:const Icon(Icons.medication_liquid_rounded,color:Colors.white));

  Widget _actBtn({required VoidCallback onTap,required IconData icon,required Gradient grad})=>
      Container(width:36,height:36,decoration:AddMedicineCard._btnShadow(grad,radius:18),
        child:Material(color:Colors.transparent,borderRadius:BorderRadius.circular(18),
          child:InkWell(borderRadius:BorderRadius.circular(18),onTap:onTap,
              child:Icon(icon,color:Colors.white,size:18)),));
}