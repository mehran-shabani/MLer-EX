// lib/prescription/previous_reorder_page.dart
// صفحهٔ مدیریت نسخهٔ قبلی + بازسفارش (Re-order) – تولید نهایی

// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'medicine_widgets.dart';
import 'prescription_service.dart';

class PreviousReorderPage extends StatefulWidget {
  final Prescription order;
  const PreviousReorderPage({super.key, required this.order});

  @override
  State<PreviousReorderPage> createState() => _PreviousReorderPageState();
}

class _PreviousReorderPageState extends State<PreviousReorderPage>
    with TickerProviderStateMixin {
  /*──────── Controllers ─────*/
  final _nameCtl = TextEditingController();
  final _doseCtl = TextEditingController();
  final _qtyCtl  = TextEditingController();
  final ScrollController _scrollCtl = ScrollController();

  /*──────── State ───────────*/
  String? _selPerIntake;
  String? _selFreq;
  int?    _editingIdx;               // index داخل order.items

  /*──────── Animations ───────*/
  late final AnimationController _btnCtl;
  late final AnimationController _listCtl;
  late final Animation<double>   _btnScale;
  late final Animation<double>   _fadeAnim;

  /*──────── Lifecycle ───────*/
  @override
  void initState() {
    super.initState();
    _btnCtl  = AnimationController(vsync:this,duration:const Duration(milliseconds:200));
    _listCtl = AnimationController(vsync:this,duration:const Duration(milliseconds:300));
    _btnScale= Tween(begin:1.0,end:.95).animate(CurvedAnimation(parent:_btnCtl,curve:Curves.easeInOut));
    _fadeAnim= Tween(begin:0.0,end:1.0).animate(CurvedAnimation(parent:_listCtl,curve:Curves.easeInOut));
    _fetchDrugs();
  }

  @override
  void dispose() {
    _nameCtl.dispose();
    _doseCtl.dispose();
    _qtyCtl.dispose();
    _btnCtl.dispose();
    _listCtl.dispose();
    _scrollCtl.dispose();
    super.dispose();
  }

  /*──────── Helpers ─────────*/
  void _snack(String m,[Color c=Colors.red]) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(m),backgroundColor:c));
  bool _isPosNum(String s)=>
      RegExp(r'^\d+(\.\d+)?$').hasMatch(s.trim()) && double.parse(s)>0;

  /*──────── REST ───────────*/
  Future<void> _fetchDrugs() async {
    try {
      widget.order.items = await PrescriptionService.readDrugs(widget.order.id!);
    } catch (_) { _snack('خطا در دریافت اقلام نسخه'); }
    setState((){});
  }

  Future<void> _addOrUpdate() async {
    final name=_nameCtl.text.trim();
    final dose=_doseCtl.text.trim();
    final qty =_qtyCtl.text.trim();
    if(name.isEmpty){ _snack('نام دارو الزامی است'); return; }
    if(!_isPosNum(dose)){ _snack('دوز نامعتبر'); return; }

    await _btnCtl.forward(); await _btnCtl.reverse();
    if(!mounted) return;

    if(_editingIdx==null){
      /* Add drug */
      final item = await PrescriptionService.addDrug(
        widget.order.id!,
        PrescriptionItem(
          drug:name,dose:int.parse(dose),
          perIntake:_selPerIntake??'',frequency:_selFreq??'',
          count:qty.isNotEmpty?int.parse(qty):null,
        ),
      );
      setState(()=>widget.order.items.add(item));
    }else{
      /* Edit drug */
      final itm=widget.order.items[_editingIdx!];
      await PrescriptionService.editDrug(widget.order.id!, itm.id!, {
        'drug'      : name,
        'dose'      : int.parse(dose),
        'per_intake': _selPerIntake??'',
        'frequency' : _selFreq??'',
        'count'     : qty.isNotEmpty?int.parse(qty):null,
      });
      setState(() {
        itm
          ..drug      = name
          ..dose      = int.parse(dose)
          ..perIntake = _selPerIntake??''
          ..frequency = _selFreq??''
          ..count     = qty.isNotEmpty?int.parse(qty):null;
        _editingIdx = null;
      });
    }
    _clear();
  }

  Future<void> _deleteDrug(int idx) async {
    final itm=widget.order.items[idx];
    await PrescriptionService.deleteDrug(widget.order.id!, itm.id!);
    setState(()=>widget.order.items.removeAt(idx));
  }

  Future<void> _registerReorder() async {
    try {
      await PrescriptionService.reorder(widget.order.id!);
    } catch (_) { _snack('بازسفارش ناموفق بود'); return; }

    /* build summary */
    final summary=widget.order.items.map((m){
      final t='${m.drug} ${m.dose}';
      final p=<String>[t];
      if(m.perIntake.isNotEmpty) p.add('💊 ${m.perIntake}');
      if(m.frequency.isNotEmpty) p.add('⏰ ${m.frequency}');
      if(m.count!=null)          p.add('📦 ${m.count}');
      return p.join(' - ');
    }).join('\n');

    Navigator.pop(context, summary);
  }

  /*──────── Edit helpers ─────*/
  void _editStart(int i){
    final m=widget.order.items[i]; setState(()=>_editingIdx=i);
    _nameCtl.text=m.drug;
    _doseCtl.text='${m.dose}';
    _qtyCtl.text=m.count?.toString()??'';
    _selPerIntake=m.perIntake.isNotEmpty?m.perIntake:null;
    _selFreq     =m.frequency.isNotEmpty?m.frequency:null;
    _scrollCtl.animateTo(0,duration:const Duration(milliseconds:400),curve:Curves.easeInOut);
  }
  void _clear(){ _nameCtl.clear(); _doseCtl.clear(); _qtyCtl.clear();
    setState(()=>_selPerIntake=_selFreq=null); }

  /*──────── UI ──────────────*/
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(
      title:Text(widget.order.name),
      actions:[
        TextButton(onPressed:_registerReorder,
          child:const Text('ثبت نهایی',style:TextStyle(color:Colors.white))),
      ],
    ),
    body:SingleChildScrollView(
      controller:_scrollCtl,
      padding:const EdgeInsets.fromLTRB(16,16,16,120),
      child:Column(children:[
        AddMedicineCard(
          nameCtl      : _nameCtl,
          doseCtl      : _doseCtl,
          qtyCtl       : _qtyCtl,
          selPerIntake : _selPerIntake,
          selFreq      : _selFreq,
          onPerChanged : (v)=>setState(()=>_selPerIntake=v),
          onFreqChanged: (v)=>setState(()=>_selFreq=v),
          onAddOrUpdate: _addOrUpdate,
          onClear      : _clear,
          isEditing    : _editingIdx!=null,
          scaleAnim    : _btnScale,
        ),
        const SizedBox(height:20),
        MedicineListCard(
          meds:_toMapList(widget.order.items),
          onEdit:(i)=>_editStart(i),
          onDelete:_deleteDrug,
        ),
      ]),
    ),
  );

  /* helper */
  List<Map<String,String>> _toMapList(List<PrescriptionItem> items)=>items.map((m)=> {
    'name'     : m.drug,
    'doseMg'   : '${m.dose}',
    'perIntake': m.perIntake,
    'frequency': m.frequency,
    'quantity' : m.count?.toString()??'',
  }).toList();
}