// lib/prescription/previous_prescriptions_page.dart
// صفحه «نسخه جدید / نسخه‌های قبلی» ـ کاملاً آمادهٔ اجرا در Production

// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'medicine_widgets.dart';
import 'prescription_service.dart';

class PreviousPrescriptionsPage extends StatefulWidget {
  const PreviousPrescriptionsPage({super.key});

  @override
  State<PreviousPrescriptionsPage> createState() =>
      _PreviousPrescriptionsPageState();
}

class _PreviousPrescriptionsPageState extends State<PreviousPrescriptionsPage>
    with TickerProviderStateMixin {
  /*──────────── Controllers ────────────*/
  final _nameCtl = TextEditingController();
  final _doseCtl = TextEditingController();
  final _qtyCtl  = TextEditingController();
  final ScrollController _scrollCtl = ScrollController();

  /*──────────── State vars ─────────────*/
  String? _selPerIntake;
  String? _selFreq;
  final List<Map<String, String>> _meds = [];
  int?  _editingIdx;

  /*──────────── Orders (old) ───────────*/
  bool _showOld = false;
  List<Prescription> _orders = [];

  /*──────────── Animations ─────────────*/
  late final AnimationController _btnCtl;
  late final AnimationController _listCtl;
  late final Animation<double>   _btnScale;
  late final Animation<double>   _fadeAnim;

  /*──────────── Lifecycle ─────────────*/
  @override
  void initState() {
    super.initState();
    _btnCtl  = AnimationController(vsync:this,duration:const Duration(milliseconds:200));
    _listCtl = AnimationController(vsync:this,duration:const Duration(milliseconds:300));
    _btnScale= Tween(begin:1.0,end:.95).animate(CurvedAnimation(parent:_btnCtl,curve:Curves.easeInOut));
    _fadeAnim= Tween(begin:0.0,end:1.0).animate(CurvedAnimation(parent:_listCtl,curve:Curves.easeInOut));
    _fetchOrders();
  }

  @override
  void dispose() {
    _nameCtl.dispose();
    _doseCtl.dispose();
    _qtyCtl.dispose();
    _btnCtl.dispose();
    _listCtl.dispose();
    _scrollCtl.dispose();
    super.dispose();
  }

  /*──────────── Web helpers ───────────*/
  void _snack(String m,[Color c=Colors.red]) =>
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text(m),backgroundColor:c));

  bool _isPosNum(String s)=>
      RegExp(r'^\d+(\.\d+)?$').hasMatch(s.trim()) && double.parse(s)>0;

  /*──────────── REST calls ────────────*/
  Future<void> _fetchOrders() async {
    try { _orders = await PrescriptionService.readOrders(); }
    catch(e){ _snack('خطا در دریافت نسخه‌ها'); }
    setState((){});
  }

  /*──────────── Add / Update ──────────*/
  Future<void> _addOrUpdate() async {
    final name=_nameCtl.text.trim();
    final dose=_doseCtl.text.trim();
    final qty =_qtyCtl.text.trim();
    if(name.isEmpty){ _snack('نام دارو الزامی است'); return; }
    if(!_isPosNum(dose)){ _snack('دوز عددی معتبر نیست'); return; }

    await _btnCtl.forward(); await _btnCtl.reverse();
    if(!mounted) return;

    final m={
      'name':name,
      'doseMg':dose,
      'perIntake':_selPerIntake??'',
      'frequency':_selFreq??'',
      'quantity':qty,
    };

    setState(() {
      if(_editingIdx==null){
        _meds.add(m); _listCtl.forward(from:0);
      }else{
        _meds[_editingIdx!]=m; _editingIdx=null;
      }
    });
    _clear();
  }

  void _edit(int i){
    final m=_meds[i]; setState(()=>_editingIdx=i);
    _nameCtl.text=m['name']!;
    _doseCtl.text=m['doseMg']!;
    _qtyCtl.text=m['quantity']!;
    _selPerIntake=m['perIntake']!.isEmpty?null:m['perIntake'];
    _selFreq     =m['frequency']!.isEmpty?null:m['frequency'];
    _scrollCtl.animateTo(0,duration:const Duration(milliseconds:400),curve:Curves.easeInOut);
  }
  void _delete(int i){ setState(()=>_meds.removeAt(i)); }
  void _clear(){ _nameCtl.clear(); _doseCtl.clear(); _qtyCtl.clear();
    setState(()=>_selPerIntake=_selFreq=null); }

  /*──────────── Final submit ──────────*/
  Future<void> _finalSubmit() async {
    if(_meds.isEmpty){ _snack('حداقل یک دارو اضافه کنید'); return; }

    await _btnCtl.forward(); await _btnCtl.reverse();
    if(!mounted) return;

    /* 1) create-order */
    final items=_meds.map((m)=>PrescriptionItem(
      drug:m['name']!, dose:int.parse(m['doseMg']!),
      perIntake:m['perIntake']!, frequency:m['frequency']!,
      count:m['quantity']!.isNotEmpty?int.parse(m['quantity']!):null,
    )).toList();

    try{
      await PrescriptionService.createOrder(
        Prescription(name:'نسخه بدون عنوان', items:items));
    }catch(e){ _snack('ثبت نسخه روی سرور ناموفق بود'); return; }

    /* 2) build summary */
    final summary=_meds.map((m){
      final t='${m['name']} ${m['doseMg']}';
      final p=<String>[t];
      if(m['perIntake']!.isNotEmpty) p.add('💊 ${m['perIntake']}');
      if(m['frequency']!.isNotEmpty) p.add('⏰ ${m['frequency']}');
      if(m['quantity']!.isNotEmpty) p.add('📦 ${m['quantity']}');
      return p.join(' - ');
    }).join('\n');

    /* 3) pop back */
    Navigator.pop(context, summary);
  }

  /*──────────── UI ───────────────────*/
  @override
  Widget build(BuildContext c)=>Scaffold(
    backgroundColor:const Color(0xFFF8F9FA),
    appBar:AppBar(
      title:Text(_showOld?'نسخه‌های قبلی':'ثبت داروهای روتین',
          style:const TextStyle(fontSize:18,fontWeight:FontWeight.w700,color:Color(0xFF2C3E50))),
      centerTitle:true,
      leading:IconButton(
        icon:const Icon(Icons.close_rounded,color:Color(0xFFE74C3C)),
        onPressed:()=>Navigator.pop(c)),
      actions:[
        IconButton(
          icon:Icon(_showOld?Icons.add_circle_outline:Icons.history_toggle_off),
          tooltip:_showOld?'نسخه جدید':'نسخه‌های قبلی',
          onPressed:()=>setState(()=>_showOld=!_showOld),
        ),
        if(!_showOld && _meds.isNotEmpty)
          TextButton.icon(
            onPressed:_finalSubmit,
            icon:const Icon(Icons.check_circle_rounded,size:18),
            label:const Text('ثبت نهایی',style:TextStyle(color:Color(0xFF27AE60))),
          ),
      ],
    ),
    body:_showOld?_ordersBody():_newRxBody(),
  );

  /*──────── نسخه جدید UI ─────*/
  Widget _newRxBody()=>Column(children:[
    _gradientBar(),
    Expanded(child:SingleChildScrollView(
      controller:_scrollCtl,
      padding:const EdgeInsets.fromLTRB(16,16,16,100),
      child:Column(children:[
        AddMedicineCard(
          nameCtl      : _nameCtl,
          doseCtl      : _doseCtl,
          qtyCtl       : _qtyCtl,
          selPerIntake : _selPerIntake,
          selFreq      : _selFreq,
          onPerChanged : (v)=>setState(()=>_selPerIntake=v),
          onFreqChanged: (v)=>setState(()=>_selFreq=v),
          onAddOrUpdate: _addOrUpdate,
          onClear      : _clear,
          isEditing    : _editingIdx!=null,
          scaleAnim    : _btnScale,
        ),
        if(_meds.isNotEmpty)...[
          const SizedBox(height:20),
          FadeTransition(
            opacity:_fadeAnim,
            child:MedicineListCard(
              meds:_meds,
              onEdit:_edit,
              onDelete:_delete,
            ),
          ),
        ],
      ]),
    )),
  ]);

  /*──────── نسخه‌های قبلی UI ─────*/
  Widget _ordersBody()=>ListView.builder(
    padding:const EdgeInsets.fromLTRB(16,24,16,120),
    itemCount:_orders.length,
    itemBuilder:(_,i){
      final o=_orders[i];
      return Card(
        child:ListTile(
          leading:const Icon(Icons.medical_services),
          title:Text(o.name),
          subtitle:Text('اقلام: ${o.items.length} • بازسفارش: ${o.reorder}'),
          trailing:const Icon(Icons.chevron_left),
          onTap:()async{
            final summary=await Navigator.push<String>(
              context,MaterialPageRoute(
                builder:(_)=>PreviousReorderPage(order:o)));
            if(summary!=null && summary.trim().isNotEmpty) Navigator.pop(context,summary);
          },
        ),
      );
    });

  /*──────── helpers ─────*/
  Widget _gradientBar()=>Container(height:2,decoration:const BoxDecoration(
    gradient:LinearGradient(colors:[Color(0xFF3498DB),Color(0xFF9B59B6),Color(0xFFE74C3C)])));
}
