import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String apiBase = 'https://api.medogram.ir/api'; // ← production endpoint

/*═══════════════════════════  Data-Classes  ═══════════════════════════*/
class PrescriptionItem {
  int?   id;
  String drug;
  int    dose;          // mg
  String perIntake;
  String frequency;
  int?   count;

  PrescriptionItem({
    this.id,
    required this.drug,
    required this.dose,
    this.perIntake = '',
    this.frequency = '',
    this.count,
  });

  Map<String, dynamic> toJson() => {
        'drug'      : drug,
        'dose'      : dose,
        if (perIntake.isNotEmpty) 'per_intake': perIntake,
        if (frequency.isNotEmpty) 'frequency' : frequency,
        if (count != null)        'count'     : count,
      };

  factory PrescriptionItem.fromJson(Map<String, dynamic> j) => PrescriptionItem(
        id        : j['id'],
        drug      : j['drug'],
        dose      : j['dose'],
        perIntake : j['per_intake'] ?? '',
        frequency : j['frequency']  ?? '',
        count     : j['count'],
      );
}

class Prescription {
  int?   id;
  String name;
  bool   isActive;
  int    reorder;
  DateTime? createdAt;
  List<PrescriptionItem> items;

  Prescription({
    this.id,
    required this.name,
    this.isActive = true,
    this.reorder  = 1,
    this.createdAt,
    this.items = const [],
  });

  Map<String, dynamic> toCreatePayload() => {
        'name' : name,
        'items': items.map((e) => e.toJson()).toList(),
      };

  factory Prescription.fromJson(Map<String, dynamic> j) => Prescription(
        id        : j['id'],
        name      : j['name'],
        isActive  : j['is_active'] ?? true,
        reorder   : j['reorder']   ?? 1,
        createdAt : j['created_at'] != null
            ? DateTime.parse(j['created_at']) : null,
        items     : (j['items'] as List? ?? [])
            .map((e) => PrescriptionItem.fromJson(e)).toList(),
      );
}

/*═══════════════════════════  REST Client  ═══════════════════════════*/
class PrescriptionService {
  static Future<Map<String, String>> _headers() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    return {
      'Content-Type': 'application/json; charset=UTF-8',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  /*── create-order ───────────────────────────────────────────*/
  static Future<void> createOrder(Prescription body) async {
    final r = await http.post(
      Uri.parse('$apiBase/prescription/create-order/'),
      headers: await _headers(),
      body   : jsonEncode(body.toCreatePayload()),
    );
    if (r.statusCode != 201) {
      throw Exception('create-order failed: ${r.statusCode} → ${r.body}');
    }
  }

  /*── read-order ─────────────────────────────────────────────*/
  static Future<List<Prescription>> readOrders() async {
    final r = await http.get(
      Uri.parse('$apiBase/prescription/read-order/'),
      headers: await _headers(),
    );
    if (r.statusCode == 200) {
      final list = jsonDecode(r.body) as List;
      return list.map((e) => Prescription.fromJson(e)).toList();
    }
    throw Exception('read-order failed');
  }

  /*── read-drug ──────────────────────────────────────────────*/
  static Future<List<PrescriptionItem>> readDrugs(int orderId) async {
    final r = await http.get(
      Uri.parse('$apiBase/prescription/read-drug/$orderId/'),
      headers: await _headers(),
    );
    if (r.statusCode == 200) {
      final list = jsonDecode(r.body)['drugs'] as List;
      return list.map((e) => PrescriptionItem.fromJson(e)).toList();
    }
    throw Exception('read-drug failed');
  }

  /*── add-drug ───────────────────────────────────────────────*/
  static Future<PrescriptionItem> addDrug(
      int orderId, PrescriptionItem item) async {
    final r = await http.post(
      Uri.parse('$apiBase/prescription/add-drug/$orderId/'),
      headers: await _headers(),
      body   : jsonEncode(item.toJson()),
    );
    if (r.statusCode == 201) {
      return PrescriptionItem.fromJson(jsonDecode(r.body));
    }
    throw Exception('add-drug failed');
  }

  /*── edit-drug ──────────────────────────────────────────────*/
  static Future<void> editDrug(
      int orderId, int itemId, Map<String, dynamic> fields) async {
    final r = await http.patch(
      Uri.parse('$apiBase/prescription/edit-drug/$orderId/$itemId/'),
      headers: await _headers(),
      body   : jsonEncode(fields),
    );
    if (r.statusCode != 200) throw Exception('edit-drug failed');
  }

  /*── delete-drug ────────────────────────────────────────────*/
  static Future<void> deleteDrug(int orderId, int itemId) async {
    final r = await http.delete(
      Uri.parse('$apiBase/prescription/delete-drug/$orderId/$itemId/'),
      headers: await _headers(),
    );
    if (r.statusCode != 204) throw Exception('delete-drug failed');
  }

  /*── reorder ────────────────────────────────────────────────*/
  static Future<void> reorder(int orderId) async {
    final r = await http.get(
      Uri.parse('$apiBase/prescription/reorder/$orderId/'),
      headers: await _headers(),
    );
    if (r.statusCode != 200) throw Exception('reorder failed');
  }
}
