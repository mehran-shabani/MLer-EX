// ignore_for_file: library_private_types_in_public_api, avoid_print

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bottom_navy_bar/bottom_navy_bar.dart';

import 'visit/visit_page.dart';
import 'chat_room/chat_room.dart';
import 'profile/profile_screen.dart';
import '../widgets/contact_info.dart';
import '../theme_provider.dart';
import 'login/login_page.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 1;
  late AnimationController _animationController;
  late Animation<double> _animation;

  static final List<Widget> _widgetOptions = <Widget>[
    ContactInfo(),
    VisitPage(),
    ChatRoom(),
    Profile(),
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  final Color _selectedIconColor = const Color.fromARGB(255, 133, 128, 128);
  final Color _unselectedIconColor = const Color.fromARGB(255, 145, 135, 135);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 50,
        leading: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginPage()),
                );
              },
            ),
            AnimatedBuilder(
              animation: _animation,
              builder: (context, child) {
                return Opacity(
                  opacity: _animation.value,
                  child: const Text(
                    'HELSSA',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
        leadingWidth: 120,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF1976D2),
                Color(0xFF42A5F5),
                Color(0xFF64B5F6),
              ],
            ),
          ),
        ),
        elevation: 0,
      ),
      body: _widgetOptions.elementAt(_selectedIndex),
      bottomNavigationBar: BottomNavyBar(
        selectedIndex: _selectedIndex,
        onItemSelected: _onItemTapped,
        backgroundColor: const Color.fromARGB(255, 0, 0, 0),
        items: [
          BottomNavyBarItem(
            icon: const Icon(Icons.call),
            title: const Text('تماس'),
            activeColor: _selectedIconColor,
            inactiveColor: _unselectedIconColor,
          ),
          BottomNavyBarItem(
            icon: const Icon(Icons.local_hospital),
            title: const Text('ویزیت'),
            activeColor: _selectedIconColor,
            inactiveColor: _unselectedIconColor,
          ),
          BottomNavyBarItem(
            icon: const Icon(Icons.chat_bubble),
            title: const Text('دکی'),
            activeColor: _selectedIconColor,
            inactiveColor: _unselectedIconColor,
          ),
          BottomNavyBarItem(
            icon: const Icon(Icons.person),
            title: const Text('پروفایل'),
            activeColor: _selectedIconColor,
            inactiveColor: _unselectedIconColor,
          ),
        ],
      ),
    );
  }
}
