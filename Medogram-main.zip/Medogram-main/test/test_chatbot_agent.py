# tests/test_chatbot_agents.py
from django.test import TestCase
from unittest.mock import Mock, patch, MagicMock
import json

class MockLLM:
    """Mock LLM برای تست"""
    def __init__(self, response="پاسخ تستی"):
        self.response = response
        self.chat_calls = []
    
    def chat(self, messages):
        self.chat_calls.append(messages)
        return type('obj', (object,), {
            'message': type('obj', (object,), {'content': self.response})()
        })()

class MockChatMessage:
    def __init__(self, role, content):
        self.role = role
        self.content = content

class MockMessageRole:
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"

# ====================== BaseAgent Tests ======================

class BaseAgentTestCase(TestCase):
    def setUp(self):
        self.mock_llm = MockLLM()
        self.patient_info = {
            "name": "تست",
            "age": 30,
            "gender": "مرد",
            "bmi": 25,
            "chronic_conditions": []
        }
        self.chat_history = [
            {"sender": "patient", "content": "سلام"},
            {"sender": "assistant", "content": "سلام، چطور می‌تونم کمک کنم؟"}
        ]

    @patch('chatbot_pro.utils.llm_config.llm_config.get_llm')
    @patch('llama_index.core.llms.ChatMessage', MockChatMessage)
    @patch('llama_index.core.llms.MessageRole', MockMessageRole)
    def test_base_agent_consult(self, mock_get_llm):
        """تست اصلی BaseAgent.consult"""
        mock_get_llm.return_value = self.mock_llm
        
        # ایجاد یک agent ساده برای تست
        from chatbot_pro.agents.base_agent import BaseAgent
        
        class TestAgent(BaseAgent):
            domain_name = "test"
            trigger_keywords = ["test"]
            
            def _build_domain_prompt(self, message, patient_info):
                return f"TEST:{message}:{patient_info['age']}"
        
        agent = TestAgent()
        result = agent.consult("پیام تست", self.patient_info, self.chat_history)
        
        # بررسی نتیجه
        self.assertEqual(result, "پاسخ تستی")
        self.assertEqual(len(self.mock_llm.chat_calls), 1)
        
        # بررسی پیام‌های ارسالی به LLM
        messages = self.mock_llm.chat_calls[0]
        self.assertEqual(messages[0].role, "system")
        self.assertEqual(messages[-1].content, "پیام تست")

    @patch('chatbot_pro.utils.llm_config.llm_config.get_llm')
    def test_build_messages_structure(self, mock_get_llm):
        """تست ساختار پیام‌های ارسالی"""
        mock_get_llm.return_value = self.mock_llm
        
        from chatbot_pro.agents.base_agent import BaseAgent
        
        class TestAgent(BaseAgent):
            domain_name = "test"
            trigger_keywords = ["test"]
            
            def _build_domain_prompt(self, message, patient_info):
                return f"PROMPT:{message}"
        
        agent = TestAgent()
        agent.consult("سوال تست", self.patient_info, self.chat_history)
        
        messages = self.mock_llm.chat_calls[0]
        
        # بررسی ترتیب پیام‌ها
        self.assertEqual(messages[0].role, "system")
        self.assertIn("PROMPT:سوال تست", messages[0].content)
        
        # بررسی تاریخچه چت
        self.assertEqual(messages[1].role, "user")
        self.assertEqual(messages[1].content, "سلام")
        self.assertEqual(messages[2].role, "assistant")
        
        # بررسی پیام جدید
        self.assertEqual(messages[-1].role, "user")
        self.assertEqual(messages[-1].content, "سوال تست")

# ====================== Specialist Agents Tests ======================

class SpecialistAgentsTestCase(TestCase):
    """تست تمامی agent های تخصصی"""
    
    def setUp(self):
        self.patient_info = {
            "age": 30,
            "gender": "مرد",
            "bmi": 25,
            "chronic_conditions": []
        }
        
        self.agent_modules = [
            "chatbot_pro.agents.family_agent",
            "chatbot_pro.agents.obgyn_agent", 
            "chatbot_pro.agents.internal_agent",
            "chatbot_pro.agents.psychaitry_agent",
            "chatbot_pro.agents.cardiology_agent",
            "chatbot_pro.agents.surgery_agent",
            "chatbot_pro.agents.ent_derm_agent",
            "chatbot_pro.agents.neurology_agent",
            "chatbot_pro.agents.nephrology_agent",
            "chatbot_pro.agents.gastro_agent",
            "chatbot_pro.agents.rheumatology_agent",
        ]

    def _get_agent_class(self, module_name):
        """دریافت کلاس agent از ماژول"""
        import importlib
        from chatbot_pro.agents import base_agent
        
        try:
            mod = importlib.import_module(module_name)
            for value in mod.__dict__.values():
                if (isinstance(value, type) and 
                    issubclass(value, base_agent.BaseAgent) and 
                    value is not base_agent.BaseAgent):
                    return value
        except ImportError:
            self.skipTest(f"Module {module_name} not found")
        
        raise RuntimeError(f"Agent class not found in {module_name}")

    def test_all_agents_have_domain_name(self):
        """تست وجود domain_name در همه agent ها"""
        for module_name in self.agent_modules:
            with self.subTest(module=module_name):
                agent_cls = self._get_agent_class(module_name)
                agent = agent_cls()
                self.assertTrue(hasattr(agent, 'domain_name'))
                self.assertIsInstance(agent.domain_name, str)
                self.assertGreater(len(agent.domain_name), 0)

    def test_all_agents_have_trigger_keywords(self):
        """تست وجود trigger_keywords در همه agent ها"""
        for module_name in self.agent_modules:
            with self.subTest(module=module_name):
                agent_cls = self._get_agent_class(module_name)
                agent = agent_cls()
                self.assertTrue(hasattr(agent, 'trigger_keywords'))
                self.assertIsInstance(agent.trigger_keywords, list)
                self.assertGreater(len(agent.trigger_keywords), 0)

    @patch('chatbot_pro.utils.llm_config.llm_config.get_llm')
    def test_all_agents_build_domain_prompt(self, mock_get_llm):
        """تست متد _build_domain_prompt در همه agent ها"""
        mock_llm = MockLLM()
        mock_get_llm.return_value = mock_llm
        
        for module_name in self.agent_modules:
            with self.subTest(module=module_name):
                agent_cls = self._get_agent_class(module_name)
                agent = agent_cls()
                
                prompt = agent._build_domain_prompt("پیام تست", self.patient_info)
                
                self.assertIsInstance(prompt, str)
                self.assertIn("پیام تست", prompt)
                self.assertGreater(len(prompt), 0)

    @patch('chatbot_pro.utils.llm_config.llm_config.get_llm')
    def test_all_agents_consult_method(self, mock_get_llm):
        """تست متد consult در همه agent ها"""
        mock_llm = MockLLM("پاسخ تست")
        mock_get_llm.return_value = mock_llm
        
        for module_name in self.agent_modules:
            with self.subTest(module=module_name):
                agent_cls = self._get_agent_class(module_name)
                agent = agent_cls()
                
                result = agent.consult("سوال تست", self.patient_info, [])
                
                self.assertIsInstance(result, str)
                self.assertEqual(result, "پاسخ تست")

# ====================== Medical Agent Tests ======================

class MedicalAgentTestCase(TestCase):
    """تست MedicalAgent اصلی"""
    
    def setUp(self):
        self.patient_info = {"age": 40, "gender": "زن"}
        self.chat_history = []

    @patch('chatbot_pro.agents.medical_agent.MedicalAgent')
    def test_medical_agent_selects_specialist(self, MockMedicalAgent):
        """تست انتخاب متخصص مناسب"""
        # Mock analyzer
        mock_analyzer = Mock()
        mock_analyzer.extract_keywords.return_value = ["درد کلیه"]
        mock_analyzer.emergency_level.return_value = 2
        
        # Mock specialists
        mock_nephro_agent = Mock()
        mock_nephro_agent.domain_name = "nephro_urology"
        mock_nephro_agent.consult.return_value = "پاسخ کلیه"
        
        mock_family_agent = Mock()
        mock_family_agent.domain_name = "family"
        mock_family_agent.consult.return_value = "پاسخ خانواده"
        
        # Mock medical agent
        mock_medical_agent = Mock()
        mock_medical_agent.analyzer = mock_analyzer
        mock_medical_agent.specialists = [mock_nephro_agent, mock_family_agent]
        
        def mock_consult(message, patient_info, history):
            keywords = mock_analyzer.extract_keywords(message)
            emergency_level = mock_analyzer.emergency_level(message)
            
            # انتخاب متخصص بر اساس کلمات کلیدی
            selected_agent = mock_nephro_agent if "کلیه" in " ".join(keywords) else mock_family_agent
            reply = selected_agent.consult(message, patient_info, history)
            
            return {
                "domain": selected_agent.domain_name,
                "reply": reply,
                "symptoms": keywords,
                "emergency": emergency_level > 3,
                "emergency_level": emergency_level
            }
        
        mock_medical_agent.consult = mock_consult
        
        # تست
        result = mock_medical_agent.consult("سنگ کلیه دارم", self.patient_info, self.chat_history)
        
        self.assertEqual(result["domain"], "nephro_urology")
        self.assertEqual(result["reply"], "پاسخ کلیه")
        self.assertEqual(result["symptoms"], ["درد کلیه"])
        self.assertFalse(result["emergency"])
        self.assertEqual(result["emergency_level"], 2)

    @patch('chatbot_pro.agents.medical_agent.MedicalAgent')
    def test_medical_agent_fallback_to_family(self, MockMedicalAgent):
        """تست بازگشت به پزشک خانواده"""
        # Mock analyzer
        mock_analyzer = Mock()
        mock_analyzer.extract_keywords.return_value = []
        mock_analyzer.emergency_level.return_value = 0
        
        # Mock family agent
        mock_family_agent = Mock()
        mock_family_agent.domain_name = "family"
        mock_family_agent.consult.return_value = "پاسخ عمومی"
        
        # Mock medical agent
        mock_medical_agent = Mock()
        mock_medical_agent.analyzer = mock_analyzer
        mock_medical_agent.specialists = [mock_family_agent]
        
        def mock_consult(message, patient_info, history):
            keywords = mock_analyzer.extract_keywords(message)
            emergency_level = mock_analyzer.emergency_level(message)
            
            # در صورت عدم وجود کلمات کلیدی، به family برگرد
            selected_agent = mock_family_agent
            reply = selected_agent.consult(message, patient_info, history)
            
            return {
                "domain": selected_agent.domain_name,
                "reply": reply,
                "symptoms": keywords,
                "emergency": emergency_level > 3,
                "emergency_level": emergency_level
            }
        
        mock_medical_agent.consult = mock_consult
        
        # تست
        result = mock_medical_agent.consult("پیام عادی", self.patient_info, [])
        
        self.assertEqual(result["domain"], "family")
        self.assertEqual(result["reply"], "پاسخ عمومی")
        self.assertEqual(result["symptoms"], [])
        self.assertFalse(result["emergency"])

# ====================== Symptoms Analyzer Tests ======================

class SymptomsAnalyzerTestCase(TestCase):
    """تست SymptomsAnalyzer"""
    
    def setUp(self):
        # Mock SymptamsAnalyzer
        self.analyzer = Mock()

    def test_extract_keywords_and_systems(self):
        """تست استخراج کلمات کلیدی"""
        self.analyzer.extract_keywords.return_value = ["سرفه", "درد شکم", "تهوع", "درد"]
        
        text = "سرفه و درد شکم و تهوع"
        result = self.analyzer.extract_keywords(text)
        
        expected = {"سرفه", "درد شکم", "تهوع", "درد"}
        self.assertEqual(set(result), expected)

    def test_emergency_level_always_zero(self):
        """تست سطح اورژانس"""
        self.analyzer.emergency_level.return_value = 0
        self.analyzer.is_emergency.return_value = False
        
        result_level = self.analyzer.emergency_level("تنگی نفس شدید")
        result_emergency = self.analyzer.is_emergency("تنگی نفس شدید")
        
        self.assertEqual(result_level, 0)
        self.assertFalse(result_emergency)

# ====================== Text Cleaner Tests ======================

class TextCleanerTestCase(TestCase):
    """تست Text Cleaner"""
    
    def test_refine_text_empty(self):
        """تست متن خالی"""
        from chatbot_pro.utils.text_cleaner import refine_text
        
        result = refine_text("")
        self.assertEqual(result, "")

    def test_refine_text_cleanup(self):
        """تست پاکسازی متن"""
        from chatbot_pro.utils.text_cleaner import refine_text
        
        input_text = "مي  روم ... سلام  ,  خوبم"
        expected = "می‌روم… سلام, خوبم."
        
        result = refine_text(input_text)
        self.assertEqual(result, expected)

    def test_refine_text_persian_improvements(self):
        """تست بهبود متن فارسی"""
        from chatbot_pro.utils.text_cleaner import refine_text
        
        test_cases = [
            ("مي خوام", "می‌خوام"),
            ("نمي دونم", "نمی‌دونم"),
            ("...", "…"),
            ("  فاصله  ", "فاصله"),
        ]
        
        for input_text, expected in test_cases:
            with self.subTest(input_text=input_text):
                result = refine_text(input_text)
                self.assertIn(expected.strip(), result)

# ====================== Integration Tests ======================

class ChatbotIntegrationTestCase(TestCase):
    """تست‌های یکپارچه سیستم چت‌بات"""
    
    @patch('chatbot_pro.utils.llm_config.llm_config.get_llm')
    def test_complete_consultation_flow(self, mock_get_llm):
        """تست جریان کامل مشاوره"""
        mock_llm = MockLLM("پاسخ کامل تست")
        mock_get_llm.return_value = mock_llm
        
        # شبیه‌سازی یک سناریو کامل
        patient_info = {
            "name": "احمد",
            "age": 35,
            "gender": "مرد",
            "bmi": 27,
            "chronic_conditions": ["دیابت"]
        }
        
        chat_history = [
            {"sender": "patient", "content": "سلام دکتر"},
            {"sender": "assistant", "content": "سلام، چه مشکلی دارید؟"}
        ]
        
        # تست با family agent
        try:
            from chatbot_pro.agents.family_agent import FamilyAgent
            agent = FamilyAgent()
            result = agent.consult("درد سر دارم", patient_info, chat_history)
            
            self.assertIsInstance(result, str)
            self.assertEqual(result, "پاسخ کامل تست")
            
        except ImportError:
            self.skipTest("FamilyAgent not available")

# ====================== Performance Tests ======================

class PerformanceTestCase(TestCase):
    """تست‌های عملکرد"""
    
    @patch('chatbot_pro.utils.llm_config.llm_config.get_llm')
    def test_multiple_consultations_performance(self, mock_get_llm):
        """تست عملکرد چندین مشاوره"""
        mock_llm = MockLLM()
        mock_get_llm.return_value = mock_llm
        
        try:
            from chatbot_pro.agents.family_agent import FamilyAgent
            agent = FamilyAgent()
            
            patient_info = {"age": 30, "gender": "زن"}
            
            # تست ۱۰ مشاوره
            for i in range(10):
                result = agent.consult(f"سوال {i}", patient_info, [])
                self.assertIsInstance(result, str)
                
        except ImportError:
            self.skipTest("FamilyAgent not available")

# ====================== Error Handling Tests ======================

class ErrorHandlingTestCase(TestCase):
    """تست مدیریت خطاها"""
    
    @patch('chatbot_pro.utils.llm_config.llm_config.get_llm')
    def test_llm_failure_handling(self, mock_get_llm):
        """تست مدیریت خطای LLM"""
        # Mock LLM که خطا بدهد
        mock_llm = Mock()
        mock_llm.chat.side_effect = Exception("LLM Error")
        mock_get_llm.return_value = mock_llm
        
        try:
            from chatbot_pro.agents.family_agent import FamilyAgent
            agent = FamilyAgent()
            
            with self.assertRaises(Exception):
                agent.consult("تست خطا", {"age": 30}, [])
                
        except ImportError:
            self.skipTest("FamilyAgent not available")

    def test_invalid_patient_info(self):
        """تست اطلاعات نامعتبر بیمار"""
        try:
            from chatbot_pro.agents.family_agent import FamilyAgent
            agent = FamilyAgent()
            
            # تست با اطلاعات ناقص
            invalid_info = {"age": "نامعتبر"}
            
            # باید خطا ندهد یا خطای مناسب بدهد
            try:
                result = agent._build_domain_prompt("تست", invalid_info)
                self.assertIsInstance(result, str)
            except (KeyError, TypeError, ValueError):
                # خطاهای قابل قبول
                pass
                
        except ImportError:
            self.skipTest("FamilyAgent not available")