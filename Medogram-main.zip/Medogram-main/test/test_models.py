from django.test import TestCase
from telemedicine.models import CustomUser, Visit, Transaction, Blog, Comment, BoxMoney


class CustomUserModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser", email="test@example.com")

    def test_user_creation(self):
        user = CustomUser.objects.get(phone_number="1234567890")
        self.assertEqual(user.username, "testuser")
        self.assertEqual(user.email, "test@example.com")

    def test_user_string_representation(self):
        user = CustomUser.objects.get(phone_number="1234567890")
        self.assertEqual(str(user), "testuser")


class VisitModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser", email="test@example.com")
        self.visit = Visit.objects.create(user=self.user, name="John Doe", urgency="diet", general_symptoms="fever")

    def test_visit_creation(self):
        self.assertEqual(self.visit.name, "John Doe")
        self.assertEqual(self.visit.urgency, "diet")
        self.assertEqual(self.visit.general_symptoms, "fever")

    def test_visit_string_representation(self):
        self.assertEqual(str(self.visit), "John Doe")


class TransactionModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser", email="test@example.com")
        self.transaction = Transaction.objects.create(user=self.user, trans_id="1234", amount=30000, status="pending")

    def test_transaction_creation(self):
        self.assertEqual(self.transaction.amount, 30000)
        self.assertEqual(self.transaction.status, "pending")

    def test_transaction_string_representation(self):
        self.assertEqual(str(self.transaction), f"Transaction {self.user.phone_number} - 30000 - pending")


class BlogModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser", email="test@example.com")
        self.blog = Blog.objects.create(author=self.user, title="Sample Blog", content="This is a test blog.")

    def test_blog_creation(self):
        self.assertEqual(self.blog.title, "Sample Blog")
        self.assertEqual(self.blog.content, "This is a test blog.")

    def test_blog_string_representation(self):
        self.assertEqual(str(self.blog), "Sample Blog")


class CommentModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser", email="test@example.com")
        self.blog = Blog.objects.create(author=self.user, title="Sample Blog", content="This is a test blog.")
        self.comment = Comment.objects.create(user=self.user, blog=self.blog, comment="This is a comment")

    def test_comment_creation(self):
        self.assertEqual(self.comment.comment, "This is a comment")
        self.assertEqual(self.comment.blog, self.blog)

    def test_comment_string_representation(self):
        self.assertEqual(str(self.comment), f"Comment by {self.user.username}")

    def test_comment_like(self):
        self.comment.like()
        self.assertEqual(self.comment.likes, 1)


class BoxMoneyModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser", email="test@example.com")
        self.box_money = BoxMoney.objects.get(user=self.user)
        self.box_money.amount = 5000
        self.box_money.save()
        self.user.box_money.refresh_from_db()


    def test_box_money_creation(self):
        self.assertEqual(self.box_money.amount, 5000)

    def test_box_money_string_representation(self):
        self.assertEqual(str(self.box_money), f"BoxMoney {self.user.phone_number} - 5000")
