from django.test import TestCase
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase, APIClient

from telemedicine.models import CustomUser, Blog, Comment, Transaction, Visit, BoxMoney


class RegisterOrLoginViewTest(APITestCase):
    def setUp(self):
        self.url = reverse('register_or_login')
        self.client = APIClient()

    def test_register_or_login_user(self):
        data = {'phone_number': '09113078859'}
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('کد احراز هویت به شماره موبایل شما ارسال شد.', response.data['message'])


class VerifyOTPViewTest(APITestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", auth_code="123456")
        self.url = reverse('verify_otp')

    def test_verify_correct_otp(self):
        data = {'phone_number': '1234567890', 'code': '123456'}
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)

    def test_verify_incorrect_otp(self):
        data = {'phone_number': '1234567890', 'code': '654321'}
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['message'], 'کد وارد شده صحیح نیست.')


class UserProfileViewTest(APITestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.url = reverse('profile')

    def test_get_user_profile(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['username'], 'testuser')


class UserProfileUpdateViewTest(APITestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.url = reverse('update-profile')

    def test_update_user_profile(self):
        data = {'username': 'updateduser'}
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.user.refresh_from_db()
        self.assertEqual(self.user.username, 'updateduser')


class BlogDetailViewTest(APITestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser")
        self.blog = Blog.objects.create(title="Test Blog", content="Content", author=self.user)
        self.url = reverse('blog-detail', args=[self.blog.id])

    def test_get_blog_detail(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['title'], 'Test Blog')


class BlogCommentsViewTest(APITestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser")
        self.blog = Blog.objects.create(title="Test Blog", content="Content", author=self.user)
        self.comment = Comment.objects.create(user=self.user, blog=self.blog, comment="Test comment")
        self.url = reverse('blog-comments', args=[self.blog.id])

    def test_get_blog_comments(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data[0]['comment'], 'Test comment')


class CommentLikeDislikeViewTest(APITestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser")
        self.blog = Blog.objects.create(title="Test Blog", content="Content", author=self.user)
        self.comment = Comment.objects.create(user=self.user, comment="Test comment", blog_id=1)
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.url_like = reverse('comment-like-dislike', args=[self.comment.id, 'like'])
        self.url_dislike = reverse('comment-like-dislike', args=[self.comment.id, 'dislike'])

    def test_like_comment(self):
        response = self.client.post(self.url_like)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.comment.refresh_from_db()
        self.assertEqual(self.comment.likes, 1)

    def test_dislike_comment(self):
        self.comment.likes = 5
        self.comment.save()
        response = self.client.post(self.url_dislike)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.comment.refresh_from_db()
        self.assertEqual(self.comment.likes, 4)


class ShowBoxMoneyViewTest(APITestCase):
    def setUp(self):
        # User with BoxMoney created by signal
        self.user_with_box = CustomUser.objects.create(phone_number="1234567890", username="testuser")

        # Manually set a non-default value for box money in one case
        self.user_with_box.box_money.amount = 10000
        self.user_with_box.box_money.save()

        # User without manually set box money (defaults to 0 due to the signal)
        self.user_without_box = CustomUser.objects.create(phone_number="0987654321", username="testuser2")

        self.client = APIClient()

    def test_get_box_money_with_existing_box(self):
        """
        Test for a user who has a non-default box money amount.
        """
        self.client.force_authenticate(user=self.user_with_box)
        response = self.client.get(reverse('box-money'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['amount'], 10000)

    def test_get_box_money_default(self):
        """
        Test for a user whose box money defaults to 0 due to the signal.
        """
        self.client.force_authenticate(user=self.user_without_box)
        response = self.client.get(reverse('box-money'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['amount'], 0)


class CustomUserSignalTest(TestCase):
    def test_box_money_creation_on_user_creation(self):
        # Create a new user
        user = CustomUser.objects.create(phone_number="1234567890", username="testuser")

        # Check that the BoxMoney object was created
        box_money = BoxMoney.objects.get(user=user)
        self.assertEqual(box_money.amount, 0)


class CreateVisitViewTest(APITestCase):
    def setUp(self):
        # Create a user with BoxMoney
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser")
        self.user.box_money.amount = 50000  # Set user’s BoxMoney to 50,000
        self.user.box_money.save()
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.url = reverse('visit')

        # Create some visits for the user
        self.visit1 = Visit.objects.create(
            user=self.user,
            name="Test Visit 1",
            urgency="diet",
            general_symptoms="fever"
        )
        self.visit2 = Visit.objects.create(
            user=self.user,
            name="Test Visit 2",
            urgency="prescription",
            general_symptoms="fatigue"
        )

    def test_create_visit_with_sufficient_box_money(self):
        """
        Test creating a visit when the user has enough BoxMoney (at least 30,000 Toman).
        """
        data = {
            "name": "Test Visit",
            "urgency": "diet",
            "general_symptoms": "fever"
        }
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Check that the visit is created and money is deducted
        self.assertEqual(Visit.objects.count(), 3)
        visit = Visit.objects.get(name='Test Visit')
        self.assertEqual(visit.name, 'Test Visit')

        # Check that the amount in BoxMoney is deducted by 30,000
        self.user.box_money.refresh_from_db()
        self.assertEqual(self.user.box_money.amount, 20000)

    def test_create_visit_with_insufficient_box_money(self):
        """
        Test creating a visit when the user does not have enough BoxMoney.
        """
        # Set user's BoxMoney to less than 30,000
        self.user.box_money.amount = 20000
        self.user.box_money.save()

        data = {
            "name": "Test Visit",
            "urgency": "diet",
            "general_symptoms": "fever"
        }
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['error'], 'موجودی کیف پول شما کافی نیست. لطفا کیف پول خود را شارژ کنید.')

        # Ensure no visit is created
        self.assertEqual(Visit.objects.count(), 2)

    def test_get_visits(self):
        """
        Test retrieving all visits for the authenticated user.
        """
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify the correct number of visits is returned
        self.assertEqual(len(response.data), 2)

        # Check that the visits returned are correct
        visit_names = [visit['name'] for visit in response.data]
        self.assertIn("Test Visit 1", visit_names)
        self.assertIn("Test Visit 2", visit_names)


class CreateVisitViewTest2(APITestCase):
    def setUp(self):
        # Create a user (BoxMoney will be created automatically by the signal)
        self.user = CustomUser.objects.create(phone_number="1234567890", username="testuser")

        # Set up the APIClient and authenticate the user
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

        self.url = reverse('visit')

    def test_create_visit_after_successful_transaction(self):
        """
        Test creating a visit after a successful transaction that adds 30,000 to BoxMoney.
        """
        # Step 1: Ensure the user starts with 0 in BoxMoney
        self.assertEqual(self.user.box_money.amount, 0)

        # Step 2: Create a successful transaction that adds 30,000 to BoxMoney
        Transaction.objects.create(
            user=self.user,
            amount=30000,
            status='success'
        )

        # Check if BoxMoney was updated after the transaction
        self.user.box_money.refresh_from_db()
        self.assertEqual(self.user.box_money.amount, 30000)

        # Step 3: Try to create a visit now that the user has enough money in BoxMoney
        data = {
            "name": "Test Visit",
            "urgency": "diet",
            "general_symptoms": "fever"
        }
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Step 4: Ensure the visit is created and money is deducted from BoxMoney
        self.assertEqual(Visit.objects.count(), 1)
        self.user.box_money.refresh_from_db()
        self.assertEqual(self.user.box_money.amount, 0)  # After deducting 30,000 for the visit
