from pathlib import Path
import environ

# 1) پایهٔ پروژه
BASE_DIR = Path(__file__).resolve().parent.parent

# 2) بارگذاری متغیرهای محیطی
env = environ.Env(
    DEBUG=(bool, False)
)
# خواندن فایل .env
environ.Env.read_env(BASE_DIR / '.env')

# 3) تنظیمات امنیتی
SECRET_KEY     = env('SECRET_KEY')
DEBUG          = env('DEBUG')
ALLOWED_HOSTS  = env.list('ALLOWED_HOSTS')  # رشتهٔ کاما جدا را به لیست تبدیل می‌کند

# 4) ایمیل
EMAIL_BACKEND        = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST           = env('EMAIL_HOST')
EMAIL_PORT           = env.int('EMAIL_PORT')
EMAIL_USE_SSL        = env.bool('EMAIL_USE_SSL')
EMAIL_HOST_USER      = env('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD  = env('EMAIL_HOST_PASSWORD')
DEFAULT_FROM_EMAIL   = env('DEFAULT_FROM_EMAIL')

# 5) API Keys
TALKBOT_API         = env('TALKBOT_API')
BITPAY_API_KEY      = env('BITPAY_API_KEY')
KAVEH_NEGAR_API_KEY = env('KAVEH_NEGAR_API_KEY')

CORS_ALLOWED_ORIGINS = [
    'http://localhost:3000',
    'http://127.0.0.1:3000',

]
# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'telemedicine.apps.TelemedicineConfig',
    'kavenegar',
    'rest_framework',
    'rest_framework_simplejwt',
    'drf_yasg',
    'corsheaders',
    "chatbot.apps.ChatbotConfig",
    'subscriber.apps.SubscriberConfig',
    'chronic_prediction.apps.ChronicPredictionConfig',
   
    "certificate.apps.CertificateConfig",
    "order.apps.OrderConfig",
    
    "down",
    'doctor_online',
    'chatbot_pro.apps.ChatbotProConfig',
    
]



AUTH_USER_MODEL = 'telemedicine.CustomUser'
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 3,
}

from datetime import timedelta

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=28800),  # عمر توکن دسترسی
    'REFRESH_TOKEN_LIFETIME': timedelta(days=100),  # عمر توکن تازه‌سازی
    'ROTATE_REFRESH_TOKENS': True,  # توکن تازه‌سازی قدیمی را غیرفعال می‌کند
    'BLACKLIST_AFTER_ROTATION': True,  # امکان اضافه کردن توکن به لیست سیاه پس از دوران
    'ALGORITHM': 'HS256',  # الگوریتم رمزنگاری
    'SIGNING_KEY': SECRET_KEY,  # کلید امضای JWT
    'VERIFYING_KEY': None,
    'AUTH_HEADER_TYPES': ('Bearer',),  # نوع هدر JWT
    'AUTH_TOKEN_CLASSES': ('rest_framework_simplejwt.tokens.AccessToken',),
    'USER_ID_FIELD': 'id',
    'USER_ID_CLAIM': 'user_id',
    'AUTH_HEADER_NAME': 'HTTP_AUTHORIZATION',
    'TOKEN_TYPE_CLAIM': 'token_type',
    'JTI_CLAIM': 'jti',

    'SLIDING_TOKEN_REFRESH_EXP_CLAIM': 'refresh_exp',
    'SLIDING_TOKEN_LIFETIME': timedelta(minutes=5),
    'SLIDING_TOKEN_REFRESH_LIFETIME': timedelta(days=1),
}


MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]


# یا برای اجازه دادن به همه دامنه‌ها:
CORS_ALLOW_ALL_ORIGINS = True
ROOT_URLCONF = 'medogram.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates',

                 ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'medogram.wsgi.application'


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
        'OPTIONS': {
            'timeout': 30,  # مقدار Timeout به ثانیه
        },
    }
}





AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]




LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True

STATIC_URL = 'static/'


DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

MEDIA_ROOT = BASE_DIR / 'media'
MEDIA_URL = '/media/'
# Maximum upload file size (10MB)
MAX_UPLOAD_SIZE = 10485760

# lofgging
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'WARNING',
    },
}



# pass


CORS_ALLOW_HEADERS = [
    'authorization',
    'content-type',
    'x-csrftoken',
    'accept'
]
# main_site
SITE_URL = 'https://medogram.ir'

CORS_ALLOWED_ORIGINS = [
    'http://localhost:3000',
    'http://127.0.0.1:3000',
]

