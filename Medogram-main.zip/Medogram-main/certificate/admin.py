# certificate/admin.py
from django.contrib import admin
from .models import MedicalCertificate


@admin.register(MedicalCertificate)
class MedicalCertificateAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'national_code', 'sick_days', 'sick_name', 'is_downloadable',
                    'pdf_file_path')
    list_filter = ('is_downloadable', 'sick_name')
    search_fields = ('first_name', 'last_name', 'national_code', 'sick_name')
    readonly_fields = ('pdf_file_path',)

    fieldsets = (
        (None, {
            'fields': ('first_name', 'last_name', 'national_code', 'sick_days', 'sick_name', 'is_downloadable',
                       'pdf_file_path')
        }),
    )
