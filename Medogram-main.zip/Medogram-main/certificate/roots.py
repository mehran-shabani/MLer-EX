# certificate/urls.py
from django.urls import path
from .views import (
    CreateCertificateView,
    CertificateStatusView,
    CertificateDownloadView,
    VerifyCertificateView,
    DownloadUrlView,
)

urlpatterns = [
    path('create/', CreateCertificateView.as_view(), name='create_certificate'),
    path('status/<str:certificate_national_code>/', CertificateStatusView.as_view(), name='certificate_status'),
    path('download/<str:certificate_national_code>/', CertificateDownloadView.as_view(), name='certificate_download'),
    path('verify/<str:certificate_national_code>/', VerifyCertificateView.as_view(), name='verify_certificate'),
    path('downloadurl/<str:certificate_national_code>/', DownloadUrlView.as_view(), name='download_url'),
]