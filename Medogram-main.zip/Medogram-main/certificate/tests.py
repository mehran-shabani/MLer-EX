from rest_framework.test import APITestCase, APIClient
from django.urls import reverse
from rest_framework import status
from certificate.models import MedicalCertificate
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
import os

CustomUser = get_user_model()


class CertificateAPITests(APITestCase):
    def setUp(self):
        # ایجاد کاربر آزمایشی
        self.user = CustomUser.objects.create_user(phone_number="1234567890", username="testuser",
                                                   password="testpass123")

        # ایجاد کلاینت API
        self.client = APIClient()

        # گرفتن توکن احراز هویت برای کاربر
        refresh = RefreshToken.for_user(self.user)
        self.access_token = str(refresh.access_token)

        # تنظیم URLهای ویوها
        self.create_url = reverse('create-certificate')  # URL برای ایجاد گواهی
        self.status_url = lambda cert_id: reverse('certificate-status', args=[cert_id])  # URL برای بررسی وضعیت
        self.download_url = lambda cert_id: reverse('certificate-download', args=[cert_id])  # URL برای دانلود

        # مسیر فایل PDF در پوشه‌ی `pdf` که درون اپلیکیشن قرار دارد
        self.pdf_dir = os.path.join(os.path.dirname(__file__), 'pdf')
        if not os.path.exists(self.pdf_dir):
            os.makedirs(self.pdf_dir)

    def test_certificate_download_authenticated(self):
        """تست دانلود گواهی پزشکی با احراز هویت"""
        # ایجاد مسیر فایل PDF در پوشه `pdf` داخل اپلیکیشن
        pdf_file_path = os.path.join(self.pdf_dir, 'medical_certificate_Ali_Shabani.pdf')

        # نوشتن یک فایل PDF فرضی (برای شبیه‌سازی)
        with open(pdf_file_path, 'w') as f:
            f.write('This is a test PDF file.')

        # ابتدا یک گواهی پزشکی ایجاد می‌کنیم که قابل دانلود است
        certificate = MedicalCertificate.objects.create(
            first_name="علی",
            last_name="شبانی",
            sick_days=3,
            sick_name="سرما خوردگی",
            is_downloadable=True,
            pdf_file_path=pdf_file_path  # فایل PDF در مسیر `pdf/` ذخیره می‌شود
        )

        # تنظیم هدر Authorization با توکن JWT
        self.client.credentials(HTTP_AUTHORIZATION='Bearer ' + self.access_token)

        # ارسال درخواست GET برای دانلود گواهی
        response = self.client.get(self.download_url(certificate.id))

        # بررسی وضعیت درخواست (200 OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # بررسی اینکه محتوای پاسخ یک فایل PDF باشد
        self.assertEqual(response['Content-Type'], 'application/pdf')
