# certificate/ views.py
import os
import time

from rest_framework import status
import logging

from medogram import settings
from django.contrib.auth import get_user_model
from django.http import FileResponse
from django.views.generic import TemplateView
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import MedicalCertificate
from .util import create_medical_certificate

User = get_user_model()


class CreateCertificateView(APIView):
    def post(self, request):
        first_name = request.data.get('first_name', 'نام')
        last_name = request.data.get('last_name', 'نام خانوادگی')
        national_code = request.data.get('national_code', 'کد ملی')
        sick_days = request.data.get('sick_days', 3)
        sick_name = request.data.get('sick_name', 'نام بیماری')

        # ایجاد گواهی پزشکی در دیتابیس
        certificate = MedicalCertificate.objects.create(
            first_name=first_name,
            last_name=last_name,
            national_code=national_code,
            sick_days=sick_days,
            sick_name=sick_name,
            is_downloadable=False,
            user=request.user
        )

        # لینک تایید
        verification_link = f'https://api.medogram.ir/api/certificate/verify/{certificate.national_code}/'
        certificate.verification_link = verification_link

        # تنظیم مسیر پوشه pdf در media/pdf
        pdf_dir = os.path.join(settings.MEDIA_ROOT, 'pdf')
        if not os.path.exists(pdf_dir):
            os.makedirs(pdf_dir)  # ساخت پوشه اگر وجود نداشته باشد

        # نام فایل PDF
        file_name = f'medical_certificate_{national_code}.pdf'
        file_path = os.path.join(pdf_dir, file_name)

        # فراخوانی تابع برای ساخت PDF
        pdf_created = create_medical_certificate(first_name, last_name, national_code, sick_days, sick_name,
                                                 verification_link)

        if pdf_created:
            # اگر PDF با موفقیت ساخته شد، مسیر فایل را ذخیره کنید
            certificate.pdf_file_path = file_path
        else:
            # اگر ساخت PDF موفقیت‌آمیز نبود، می‌توانید در لاگ ذخیره کنید و ادامه دهید
            logging.warning(f"Failed to create PDF for {national_code}")

        # ذخیره گواهی در دیتابیس، حتی اگر ساخت PDF با شکست مواجه شده باشد
        certificate.save()

        # ایجاد وقفه 7 ثانیه‌ای قبل از ارسال پاسخ
        time.sleep(7)

        # ارسال پاسخ به کاربر
        return Response({
            "message": "Medical certificate created successfully, the PDF is being generated.",
            "id": certificate.id,
            "first_name": certificate.first_name,
            "last_name": certificate.last_name,
            "national_code": certificate.national_code,
            "sick_days": certificate.sick_days,
            "sick_name": certificate.sick_name,
            "file_path": certificate.pdf_file_path if certificate.pdf_file_path else "PDF not generated",
            "is_downloadable": "no" if not certificate.pdf_file_path else "yes"
        }, status=status.HTTP_201_CREATED)


class CertificateStatusView(APIView):
    def get(self, request, certificate_national_code):
        try:
            certificate = MedicalCertificate.objects.get(national_code=certificate_national_code)
            return Response({
                "first_name": certificate.first_name,
                "last_name": certificate.last_name,
                "is_downloadable": "yes" if certificate.is_downloadable else "no"
                'download_url'
            })
        except MedicalCertificate.DoesNotExist:
            return Response({"error": "Certificate not found"}, status=404)


class CertificateDownloadView(APIView):
    def get(self, request, certificate_national_code):
        try:
            # پیدا کردن گواهی بر اساس کد ملی
            certificate = MedicalCertificate.objects.get(national_code=certificate_national_code)

            # بررسی اگر گواهی قابل دانلود نیست
            if not certificate.is_downloadable:
                return Response({"error": "این گواهی هنوز برای دانلود آماده نیست"}, status=403)

            # بررسی وجود فایل PDF
            if not os.path.exists(certificate.pdf_file_path):
                return Response({"error": "فایل PDF یافت نشد"}, status=404)

            # ارسال فایل PDF برای دانلود
            pdf_file = open(certificate.pdf_file_path, 'rb')
            response = FileResponse(pdf_file, as_attachment=True, filename=os.path.basename(certificate.pdf_file_path))
            return response

        except MedicalCertificate.DoesNotExist:
            return Response({"error": "گواهی مورد نظر یافت نشد"}, status=404)


class VerifyCertificateView(TemplateView):
    template_name = 'certificate/verify_certificate.html'

    def get_context_data(self, **kwargs):
        certificate_national_code = kwargs.get('certificate_national_code')
        context = super().get_context_data(**kwargs)

        try:
            certificate = MedicalCertificate.objects.get(national_code=certificate_national_code)

            if certificate.is_downloadable:
                context.update({
                    "status": "valid",
                    "message": "This medical certificate is valid.",
                    "first_name": certificate.first_name,
                    "last_name": certificate.last_name,
                    "national_code": certificate.national_code,
                    "sick_days": certificate.sick_days,
                    "sick_name": certificate.sick_name
                })
            else:
                context.update({
                    "status": "not_downloadable",
                    "message": "This certificate is not downloadable yet."
                })
        except MedicalCertificate.DoesNotExist:
            context.update({
                "status": "invalid",
                "message": "This medical certificate is invalid or does not exist."
            })

        return context


class DownloadUrlView(APIView):
    def get(self, request, certificate_national_code):
        try:
            certificate = MedicalCertificate.objects.get(national_code=certificate_national_code)
            file_name = f'medical_certificate_{certificate_national_code}.pdf'
            if certificate.is_downloadable:
                return Response({"download_url": f'https://api.medogram.ir/media/pdf/{file_name}'}, status=200)
            else:
                return Response({"error": "This certificate is not downloadable yet."}, status=403)
        except MedicalCertificate.DoesNotExist:
            return Response({"error": "Certificate not found"}, status=404)
