from django.db import models


class UserInput(models.Model):
    name = models.CharField(max_length=100, blank=True, unique=False)
    n_pregnant = models.FloatField()
    glucose = models.FloatField()
    tension = models.FloatField()
    thickness = models.FloatField()
    height = models.FloatField()
    weight = models.FloatField()
    bmi = models.FloatField(blank=True, null=True)  # مقدار محاسبه شده
    pedigree = models.FloatField(blank=True, null=True)  # مقدار محاسبه شده
    age = models.IntegerField()
    actual_outcome = models.BooleanField(blank=True, null=True)  # مقدار برای ویو دوم
    num_parents = models.IntegerField()
    num_siblings = models.IntegerField()
    num_grandparents = models.IntegerField()
    num_uncles_aunts = models.IntegerField()
    probability = models.FloatField(blank=True, null=True)  # ذخیره پیش‌بینی

    def __str__(self):
        return f"User input for prediction (Glucose: {self.glucose}, Age: {self.age})"
