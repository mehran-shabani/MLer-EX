from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import UserInput


class DiabetesPredictionTests(TestCase):
    def setUp(self):
        self.client = APIClient()

        # داده‌های پیش‌فرض برای تست
        self.valid_data = {
            "n_pregnant": 2,
            "glucose": 130,
            "tension": 85,
            "thickness": 20,
            "height": 165,
            "weight": 75,
            "age": 35,
            "num_parents": 1,
            "num_siblings": 2,
            "num_grandparents": 2,
            "num_uncles_aunts": 1,
            "name": "Test User"
        }

        self.valid_outcome_data = {
            "n_pregnant": 2,
            "glucose": 130,
            "tension": 85,
            "thickness": 20,
            "height": 165,
            "weight": 75,
            "age": 35,
            "num_parents": 1,
            "num_siblings": 2,
            "num_grandparents": 2,
            "num_uncles_aunts": 1,
            "actual_outcome": True,
            "name": "Test User"
        }

    # تست برای ویوی predict_diabetes
    def test_predict_diabetes(self):
        response = self.client.post('/predict/api/diabetes/', self.valid_data, format='json')

        # تست موفقیت درخواست
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # تست اینکه احتمال پیش‌بینی و DPF در پاسخ وجود دارد
        self.assertIn('probability', response.data)

    # تست برای ویوی store_user_input
    def test_store_user_input(self):
        response = self.client.post('/predict/api/store_user_input/', self.valid_outcome_data, format='json')

        # تست موفقیت درخواست
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # تست اینکه داده‌ها در دیتابیس ذخیره شده‌اند
        self.assertTrue(UserInput.objects.filter(name="Test User").exists())

        # تست ذخیره actual_outcome
        saved_input = UserInput.objects.get(name="Test User")
        self.assertEqual(saved_input.actual_outcome, True)

        # تست ذخیره مقدار BMI و DPF
        self.assertIsNotNone(saved_input.bmi)
        self.assertIsNotNone(saved_input.pedigree)
