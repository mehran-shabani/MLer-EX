from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from .serializers import PredictionSerializer, UpdateModelSerializer
from .models import UserInput # اطمینان از اینکه مدل وارد شده باشد

# Load the saved model and scaler




# Function to calculate Diabetes Pedigree Function (DPF)
def calculate_dpf(num_parents, num_siblings, num_grandparents, num_uncles_aunts):
    parent_weight = 0.5
    sibling_weight = 0.3
    grandparent_weight = 0.2
    uncle_aunt_weight = 0.1

    # Calculate the DPF
    dpf = (num_parents * parent_weight) + (num_siblings * sibling_weight) + \
          (num_grandparents * grandparent_weight) + (num_uncles_aunts * uncle_aunt_weight)

    return dpf


# Function to calculate BMI
def calculate_bmi(weight, height):
    # BMI = weight (kg) / (height (m))^2
    height_in_meters = height / 100  # Convert height from cm to meters
    bmi = weight / (height_in_meters ** 2)
    return bmi


def adjust_probability(probability):
    if probability >= 0.9:
        probability += 0.05  # Add 5% for high probabilities
    elif probability >= 0.6:
        probability += 0.10  # Add 10% for medium-high probabilities
    elif probability >= 0.3:
        probability += 0.15  # Add 15% for medium-low probabilities
    else:
        probability += 0.20  # Add 20% for low probabilities

    # Ensure the probability doesn't exceed 100%
    return min(probability, 1.0)


# Prediction API (no authentication required)
@api_view(['POST'])
@permission_classes([AllowAny])
def predict_diabetes(request):
    # سریالایزر داده‌های ورودی را از درخواست می‌گیرد
    serializer = PredictionSerializer(data=request.data)

    if serializer.is_valid():
        data = serializer.validated_data

        

        return Response('Its a test response', status=200)

    # اگر داده‌ها معتبر نباشند، خطا برگردانده می‌شود
    return Response(serializer.errors, status=400)


# API to store user input and calculate BMI and DPF
@api_view(['POST'])
@permission_classes([AllowAny])
def store_user_input(request):
    # سریالایزر داده‌های ورودی را از درخواست می‌گیرد
    serializer = UpdateModelSerializer(data=request.data)

    if serializer.is_valid():
        data = serializer.validated_data

        # دریافت قد و وزن از ورودی کلاینت
        height = data['height']
        weight = data['weight']

        # محاسبه BMI
        bmi = calculate_bmi(weight, height)

        num_parents = data['num_parents']
        num_siblings = data['num_siblings']  # خواهر و برادر
        num_grandparents = data['num_grandparents']
        num_uncles_aunts = data['num_uncles_aunts']

        # محاسبه DPF
        dpf = calculate_dpf(num_parents, num_siblings, num_grandparents, num_uncles_aunts)

        # ذخیره ورودی کاربر به همراه actual_outcome
        user_input = UserInput.objects.create(
            name=data['name'],
            n_pregnant=data['n_pregnant'],
            glucose=data['glucose'],
            tension=data['tension'],
            thickness=data['thickness'],
            height=data['height'],
            weight=data['weight'],
            bmi=bmi,
            pedigree=dpf,
            age=data['age'],
            num_parents=num_parents,
            num_siblings=num_siblings,
            num_grandparents=num_grandparents,
            num_uncles_aunts=num_uncles_aunts,
            actual_outcome=data['actual_outcome']  # ذخیره actual_outcome از سمت کلاینت
        )

        return Response({'message': 'User input stored successfully', 'bmi': bmi, 'pedigree': dpf,
                         'actual_outcome': data['actual_outcome']})

    return Response(serializer.errors, status=400)


def hamster(request):
    return render(request, 'hamster.html')