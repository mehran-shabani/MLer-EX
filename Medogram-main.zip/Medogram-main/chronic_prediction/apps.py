from django.apps import AppConfig


class ChronicPredictionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chronic_prediction'

