from rest_framework import serializers

from .models import UserInput


# سریالایزر برای پیش‌بینی دیابت
class PredictionSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserInput
        fields = [
            'n_pregnant', 'glucose', 'tension', 'thickness',
            'height', 'weight', 'age', 'num_parents', 'num_siblings',
            'num_grandparents', 'num_uncles_aunts', 'name'
        ]


# سریالایزر برای ذخیره اطلاعات کاربر
class UpdateModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserInput
        fields = [
            'n_pregnant', 'glucose', 'tension', 'thickness',
            'height', 'weight', 'age', 'num_parents', 'num_siblings',
            'num_grandparents', 'num_uncles_aunts', 'actual_outcome', 'name'
        ]
