from django.urls import path
from .views import predict_diabetes, store_user_input, hamster

urlpatterns = [
    path('api/diabetes/', predict_diabetes, name='predict_diabetes'),
    path('api/store_user_input/', store_user_input, name='store_user_input'),
    path('hamster/', hamster, name='hamster'),
]
