# Security Policy

## Supported Versions

At 2024.Jun
currently being supported with security updates.

| Version | Supported          |
|---------|--------------------|
| 5.1.1x  | :white_check_mark: |
| 5.1.x   | :x:                |
| 4.0.x   | :x:                |
| < 4.0   | :x:                |
