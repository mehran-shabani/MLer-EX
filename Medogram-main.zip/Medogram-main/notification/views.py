# views.py
from rest_framework import viewsets, permissions
from .models import Device
from .serializers import DeviceSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .utils import send_push_notification


class DeviceViewSet(viewsets.ModelViewSet):
    queryset = Device.objects.all()
    serializer_class = DeviceSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user)


class NotifyUserView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        title = request.data.get('title', 'سلام')
        body = request.data.get('body', 'پیام جدید')
        data_payload = request.data.get('data', {})

        response = send_push_notification(request.user, title, body, data_payload)
        return Response({'status': 'پوش نوتیفیکیشن ارسال شد', 'response': response})
