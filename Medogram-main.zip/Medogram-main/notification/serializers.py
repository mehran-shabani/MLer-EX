# serializers.py
from rest_framework import serializers
from .models import Device


class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = ['id', 'device_type', 'player_id', 'created_at']
        read_only_fields = ['id', 'created_at']

    def create(self, validated_data):
        user = self.context['request'].user
        device, created = Device.objects.update_or_create(
            user=user,
            player_id=validated_data.get('player_id'),
            defaults={'device_type': validated_data.get('device_type')}
        )
        return device
