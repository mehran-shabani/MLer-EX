# utils.py
from onesignal_sdk.client import Client
from django.conf import settings
from .models import Device


def send_push_notification(user, headings, contents, data_payload=None):
    client = Client(app_id=settings.ONESIGNAL_APP_ID, rest_api_key=settings.ONESIGNAL_REST_API_KEY)

    # دریافت Player IDهای دستگاه‌های کاربر
    player_ids = list(Device.objects.filter(user=user).values_list('player_id', flat=True))

    if not player_ids:
        return

    notification = {
        'include_player_ids': player_ids,
        'headings': {'en': headings},
        'contents': {'en': contents},
    }

    if data_payload:
        notification['data'] = data_payload

    response = client.send_notification(notification)
    return response
