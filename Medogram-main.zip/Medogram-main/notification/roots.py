# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DeviceViewSet, NotifyUserView

router = DefaultRouter()
router.register('devices', DeviceViewSet, basename='device')

urlpatterns = [
    path('', include(router.urls)),
    path('notify/', NotifyUserView.as_view(), name='notify_user'),
]