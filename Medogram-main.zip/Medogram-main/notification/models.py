# models.py
from django.db import models
from medogram import settings


class Device(models.Model):
    WEB = 'web'
    ANDROID = 'android'
    IOS = 'ios'

    DEVICE_TYPE_CHOICES = [
        (WEB, 'وب'),
        (ANDROID, 'اندروید'),
        (IOS, 'iOS'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='devices')
    device_type = models.CharField(max_length=10, choices=DEVICE_TYPE_CHOICES)
    player_id = models.CharField(max_length=200, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user} - {self.device_type}"
