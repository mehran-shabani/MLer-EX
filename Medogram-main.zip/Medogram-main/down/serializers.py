# down/serializers.py
from rest_framework import serializers
from .models import AppUpdate


class AppUpdateSerializer(serializers.ModelSerializer):
    """سریالایزر کامل رکورد دیتابیس (برای استفاده داخل ویو یا سایر APIها)"""
    class Meta:
        model  = AppUpdate
        fields = (
            'version',
            'release_notes',
            'force_update',
            'is_update_available',   # ← اطمینان از موجود بودن این فیلد در مدل
            'created_at',
        )


class AppUpdateStatusSerializer(serializers.Serializer):
    """ساختار پاسخ API برای اپلیکیشن"""
    status            = serializers.CharField()
    update_available  = serializers.BooleanField()
    version           = serializers.CharField(required=False, allow_blank=True)
    release_notes     = serializers.CharField(required=False, allow_blank=True)
    force_update      = serializers.BooleanField(required=False)
    message           = serializers.CharField()
