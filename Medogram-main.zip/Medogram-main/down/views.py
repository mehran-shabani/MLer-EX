# down/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny

from .models import AppUpdate
from .serializers import AppUpdateStatusSerializer, AppUpdateSerializer


class AppUpdateStatusView(APIView):
    """
    آخرین نسخهٔ اپلیکیشن را برمی‌گرداند.
    کلاینت با مقایسهٔ فیلد «version» با نسخهٔ محلی تصمیم می‌گیرد که
    پیام به‌روزرسانی را نمایش دهد یا خیر.
    """
    permission_classes = [AllowAny]

    def get(self, request):
        try:
            latest = AppUpdate.objects.order_by('-id').first()
            if not latest:
                return Response(
                    {'status': 'error', 'message': 'رکوردی یافت نشد'},
                    status=status.HTTP_404_NOT_FOUND,
                )

            data = AppUpdateSerializer(latest).data
            response = {
                'status'           : 'success',
                'update_available' : bool(data['is_update_available']),
                'version'          : data['version'],
                'release_notes'    : data['release_notes'],
                'force_update'     : data['force_update'],
                'message'          : f"آخرین نسخهٔ منتشرشده: {data['version']}",
            }

            serializer = AppUpdateStatusSerializer(data=response)
            serializer.is_valid(raise_exception=True)
            return Response(serializer.validated_data, status=status.HTTP_200_OK)

        except Exception as exc:
            return Response(
                {
                    'status'  : 'error',
                    'message' : 'خطا در بررسی آپدیت',
                    'error'   : str(exc),
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
