from django.forms import ModelForm, forms
from .models import Subscriber


class SubscriberForm(ModelForm):
    class Meta:
        model = Subscriber
        fields = ['first_name', 'last_name', 'email', 'phone_number', 'age', 'gender']
        labels = {
            'first_name': 'نام',
            'last_name': 'نام خانوادگی',
            'email': 'ایمیل',
            'phone_number': 'شماره تلفن',
            'age': 'سن',
            'gender': 'جنسیت'
        }

    def clean(self):
        cleaned_data = super().clean()
        email = cleaned_data.get("email")
        phone_number = cleaned_data.get("phone_number")
        if not email and not phone_number:
            raise forms.ValidationError("لطفاً حداقل یکی از فیلدهای ایمیل یا شماره تلفن را پر کنید.")
