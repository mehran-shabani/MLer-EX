from django.shortcuts import render
from django.urls import path
from .views import subscribe_view

urlpatterns = [
    path('subscribe/', subscribe_view, name='subscribe'),
    path('success/', lambda request: render(request, 'success.html'), name='success'),
]