# signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from django.template.loader import render_to_string
from .models import Subscriber
from kavenegar import KavenegarAPI, APIException, HTTPException
from medogram import settings


@receiver(post_save, sender=Subscriber)
def send_notification(sender, instance, created, **kwargs):
    if created:
        if instance.email:
            html_message = render_to_string('welcome_email.html',
                                            {'first_name': instance.first_name, 'last_name': instance.last_name})
            send_mail(
                'خوش آمدید به مجله سلامتی مدوگرام',
                '',
                settings.DEFAULT_FROM_EMAIL,
                [instance.email],
                fail_silently=False,
                html_message=html_message
            )

        if instance.phone_number:
            try:
                api = KavenegarAPI(settings.KAVEH_NEGAR_API_KEY)
                params = {
                    'receptor': instance.phone_number,
                    'token': instance.first_name,
                    'template': 'form'
                }
                api.verify_lookup(params)
            except (APIException, HTTPException) as e:
                print(f"An error occurred while sending SMS: {e}")
