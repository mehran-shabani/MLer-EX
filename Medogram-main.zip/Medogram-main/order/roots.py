from django.urls import path
from .views import order_verification

urlpatterns = [
    path('verification/<str:national_code>/', order_verification, name='order-verification'),
]