from django.db import models

from telemedicine.models import CustomUser


class Order(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=True, blank=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    national_code = models.CharField(max_length=12)
    order_number = models.CharField(max_length=255, unique=True)
    disease_name = models.CharField(max_length=50, null=True, blank=True)
    download_url = models.URLField(max_length=200, unique=True, blank=True)

    def save(self, *args, **kwargs):
        # ساخت خودکار مسیر دانلود
        if not self.download_url:  # اگر مسیر دانلود خالی بود
            self.download_url = f"https://api.medogram.ir/media/pdf/order/prescription_{self.national_code}.pdf"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
