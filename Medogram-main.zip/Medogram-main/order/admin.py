from django.conf import settings
from django.contrib import admin
from kavenegar import KavenegarAPI, APIException, HTTPException
from .models import Order


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'first_name', 'last_name', 'national_code', 'order_number', 'disease_name', 'download_url']
    search_fields = ['first_name', 'last_name', 'national_code']
    list_filter = ['id', 'national_code']
    list_per_page = 10

    # تعریف اکشن ارسال پیام
    actions = ['send_sms']

    def send_sms(self, request, queryset):
        """
        ارسال پیام به شماره کاربر
        """
        apikey = settings.KAVEH_NEGAR_API_KEY
        api = KavenegarAPI(apikey)

        for order in queryset:
            try:
                phone_number = order.user.phone_number  # شماره تلفن کاربر
                params = {
                    'receptor': phone_number,
                    'template': 'order',
                    'token': order.first_name,  # نام کاربر
                    'token2': f'prescription_{order.national_code}.pdf',  # کد ملی کاربر
                    'type': 'sms',  # نوع پیام
                }
                api.verify_lookup(params)
                self.message_user(request, f"پیام با موفقیت به {order.user} ارسال شد.")
            except (APIException, HTTPException) as e:
                self.message_user(request, f"خطا در ارسال پیام برای {order.user}: {e}", level='error')

    send_sms.short_description = "ارسال پیام به کاربران"


