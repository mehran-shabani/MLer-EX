from django.shortcuts import render

from .models import Order


def order_verification(request, national_code):
    try:
        order = Order.objects.get(national_code=national_code)
        context = {'order': order, 'not_found': False}
    except Order.DoesNotExist:
        context = {'not_found': True, 'national_code': national_code}

    return render(request, 'order/verification_order.html', context)
