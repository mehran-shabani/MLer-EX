# Medogram

Medogram is an advanced telemedicine platform that leverages React for a beautiful and modern user interface. It currently consists of two main applications:

1. **Chatbot** – An AI-powered chatbot that conducts initial patient assessments.
2. **Telemedicine** – A home visit management system that enables healthcare providers to deliver high-quality medical care.

The platform allows seamless integration between AI-driven initial consultations and real doctors, providing a smooth and efficient healthcare experience. Currently, Medogram supports up to 70 patients per hour.

**Note**: This repository contains only the Django backend for the server-side logic.

## Table of Contents

- [Introduction](#introduction)
- [Features](#features)
    - [Chatbot](#chatbot)
    - [Telemedicine](#telemedicine)
- [Installation](#installation)
- [Usage](#usage)
    - [Chatbot Usage](#chatbot-usage)
    - [Telemedicine Usage](#telemedicine-usage)
- [Contributing](#contributing)
- [License](#license)

## Introduction

Medogram is designed to revolutionize telemedicine by combining AI-based initial assessments with human healthcare professionals. The platform provides a fast, efficient, and modern way to manage home visits and patient assessments. The integration of React on the frontend ensures a sleek and user-friendly experience.

## Features

### Chatbot

- **AI-Driven Initial Consultation**: The chatbot handles the initial patient consultation by analyzing symptoms and providing a preliminary assessment.
- **Symptom Analysis**: Patients can input their symptoms, and the AI will provide possible diagnoses and recommendations.
- **Seamless Handoff to Doctors**: After the initial consultation, the patient is seamlessly handed over to a real doctor for further evaluation.

### Telemedicine

- **Schedule and Manage Home Visits**: The Telemedicine app allows patients to schedule and manage home visits with healthcare professionals.
- **Real-Time Doctor Interaction**: Once the AI assessment is complete, patients are transferred to a healthcare provider for in-depth medical consultations.
- **Efficient Patient Management**: The platform is capable of handling up to 70 patients per hour, ensuring timely and effective care.

## Installation

To get started with Medogram, follow these steps:

1. Clone the repository:

   ```bash
   git clone https://github.com/MLer-EX/medogram.git


2. Navigate to the project directory:

    ```bash
    cd medogram

3. Install dependencies:
   ```bash
    pip install -r requirements.txt
4. Apply migrations:
    ```bash
     python manage.py migrate
5. Run the development server:
    ```bash
     python manage.py runserver
## Usage:


Once the server is running, you can access the applications at the following URLs:

- **Chatbot and Telemedicine**: [http://localhost:8000/](http://localhost:8000/)

## Chatbot Usage

- **AI-Powered Consultations**: Engage with the chatbot for an AI-driven initial consultation.
- **Symptom Input**: Enter your symptoms and receive a preliminary diagnosis from the chatbot.
- **Doctor Handoff**: After the chatbot’s assessment, a doctor will review the case and provide further consultation.

## Telemedicine Usage

- **Schedule Home Visits**: Patients can easily schedule home visits with healthcare providers.
- **Doctor Consultation**: After the AI's initial assessment, doctors can conduct in-depth consultations and manage the patient's care.

## Contributing

We welcome contributions to Medogram! If you'd like to contribute, please follow these steps:

1. Fork the repository.

2. Create a new branch:

    ```bash
    git checkout -b feature/YourFeature
    ```

3. Commit your changes:

    ```bash
    git commit -m 'Add some feature'
    ```

4. Push to the branch:

    ```bash
    git push origin feature/YourFeature
    ```

5. Open a pull request.

## License

Medogram is licensed under the MIT License. See the LICENSE file for more information.








