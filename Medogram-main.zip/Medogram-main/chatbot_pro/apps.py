from django.apps import AppConfig


class ChatbotProConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatbot_pro'
