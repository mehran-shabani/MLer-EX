import sys
import types
import importlib.util
from pathlib import Path
import pytest

# ----------------- Stub external dependencies -----------------
# Minimal stand-ins for llama_index classes
llms = types.ModuleType("llama_index.core.llms")
class ChatMessage:
    def __init__(self, role, content):
        self.role = role
        self.content = content

class MessageRole:
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"

llms.ChatMessage = ChatMessage
llms.MessageRole = MessageRole
sys.modules["llama_index.core.llms"] = llms

# Dummy LLM for testing
class DummyLLM:
    def __init__(self):
        self.chats = []

    def chat(self, messages):
        self.chats.append(messages)
        return types.SimpleNamespace(message=types.SimpleNamespace(content="پاسخ تستی"))

dummy_llm = DummyLLM()
llm_mod = types.ModuleType("chatbot_pro.utils.llm_config")
llm_mod.llm_config = types.SimpleNamespace(get_llm=lambda: dummy_llm)
sys.modules["chatbot_pro.utils.llm_config"] = llm_mod

# ----------------- Load chatbot_pro package -----------------
ROOT = Path(__file__).resolve().parents[2]
CHATBOT_PRO = ROOT / "chatbot_pro"

# Set up package structure
pkg = types.ModuleType("chatbot_pro")
pkg.__path__ = [str(CHATBOT_PRO)]
sys.modules["chatbot_pro"] = pkg

# Set up agents package
agents_pkg = types.ModuleType("chatbot_pro.agents")
agents_pkg.__path__ = [str(CHATBOT_PRO / "agents")]
sys.modules["chatbot_pro.agents"] = agents_pkg

# Load base_agent
base_spec = importlib.util.spec_from_file_location(
    "chatbot_pro.agents.base_agent",
    CHATBOT_PRO / "agents" / "base_agent.py"
)
base_mod = importlib.util.module_from_spec(base_spec)
sys.modules["chatbot_pro.agents.base_agent"] = base_mod
base_spec.loader.exec_module(base_mod)

# ----------------- Fixtures -----------------
@pytest.fixture
def dummy_llm_obj():
    """Return clean DummyLLM instance for each test"""
    dummy_llm.chats.clear()
    return dummy_llm

@pytest.fixture
def base_agent():
    """Create a basic agent for testing"""
    class TestAgent(base_mod.BaseAgent):
        domain_name = "test"
        trigger_keywords = ["test"]
        def _build_domain_prompt(self, message, patient_info):
            return f"TEST:{message}"
    return TestAgent()

@pytest.fixture
def patient_info():
    """Sample patient info for testing"""
    return {
        "name": "تست",
        "age": 30,
        "gender": "مرد"
    }

@pytest.fixture
def chat_history():
    """Sample chat history for testing"""
    return [
        {"sender": "patient", "content": "سلام"},
        {"sender": "assistant", "content": "سلام، چطور می‌تونم کمک کنم؟"}
    ]