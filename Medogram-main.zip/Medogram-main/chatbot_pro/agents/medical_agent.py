"""
MedicalAgent (Dispatcher)
=========================
درگاه واحد مشاوره: پیام بیمار را دریافت کرده و به Agent تخصصی مناسب
ارجاع می‌دهد. در صورت عدم تطابق، «پزشک خانواده» پاسخ می‌دهد.
"""
from __future__ import annotations

from typing import Dict, List

from ..knowledge.symptoms_analyzer import SymptomsAnalyzer
from .base_agent import BaseAgent

# ----------- وارد کردن همهٔ Agentهای تخصصی -----------
from .family_agent import FamilyPhysicianAgent
from .obgyn_agent import ObstetricsGynecologyAgent
from .internal_agent import InternalMedicineAgent
from .psychaitry_agent import PsychiatryAgent
from .cardiology_agent import CardiologyAgent
from .surgery_agent import SurgeryAgent
from .ent_derm_agent import EntDermatologyAgent
from .neurology_agent import NeurologyAgent
from .nephrology_agent import NephrologyUrologyAgent
from .gastro_agent import GastroenterologyAgent
from .rheumatology_agent import RheumatologyAgent

# ----------- مپینگ دامنه → نمونهٔ Agent --------------
_DOMAIN_AGENT_MAP: Dict[str, BaseAgent] = {
    cls.domain_name: cls()  # type: ignore[misc]
    for cls in [
        FamilyPhysicianAgent,
        ObstetricsGynecologyAgent,
        InternalMedicineAgent,
        PsychiatryAgent,
        CardiologyAgent,
        SurgeryAgent,
        EntDermatologyAgent,
        NeurologyAgent,
        NephrologyUrologyAgent,
        GastroenterologyAgent,
        RheumatologyAgent,
    ]
}


class MedicalAgent:
    """
    عامل Dispatch:
      • انتخاب Agent مناسب با نگاه به کلیدواژه‌ها.  
      • استفاده از SymptomsAnalyzer برای استخراج علائم و فوریت.
    """

    def __init__(self) -> None:
        self.analyzer = SymptomsAnalyzer()
        self.family_agent: BaseAgent = _DOMAIN_AGENT_MAP["family"]

        # ترتیب اولویت: همهٔ متخصص‌ها (به‌جز خانواده) سپس خانواده
        self.specialists: List[BaseAgent] = [
            agent for key, agent in _DOMAIN_AGENT_MAP.items() if key != "family"
        ] + [self.family_agent]

    # ---------------- انتخاب Agent ----------------
    def _select_agent(self, message: str) -> BaseAgent:
        """
        اولین Agentی که کلیدواژه‌اش در پیام یافت شود انتخاب می‌شود.
        در غیر این صورت، پزشک خانواده پاسخ‌گو خواهد بود.
        """
        for agent in self.specialists:
            if any(kw.lower() in message.lower() for kw in agent.trigger_keywords):
                return agent
        return self.family_agent

    # ---------------- متد اصلی -------------------
    def consult(
        self,
        message: str,
        patient_info: Dict,
        history: List[Dict] | None = None,
    ) -> Dict:
        """
        خروجی:
        {
          "reply": متن پاسخ,
          "symptoms": [ ... ],
          "emergency": bool,
          "emergency_level": int,
          "domain": "internal" | ...
        }
        """
        history = history or []
        agent = self._select_agent(message)
        reply_text = agent.consult(message, patient_info, history)

        symptoms = self.analyzer.extract_keywords(message)
        emergency_level = self.analyzer.emergency_level(message)

        return {
            "reply": reply_text,
            "symptoms": symptoms,
            "emergency": emergency_level == 3,
            "emergency_level": emergency_level,
            "domain": agent.domain_name,
        }
