"""
ObstetricsGynecologyAgent
=========================
پاسخ‌گوی سؤالات مربوط به بارداری، ناباروری، عفونت‌های واژن
و غربالگری سرطان پستان.
"""
from __future__ import annotations

from datetime import datetime
from typing import Dict, List
from .base_agent import BaseAgent


class ObstetricsGynecologyAgent(BaseAgent):
    """
    وظایف:
      • مراقبت بارداری هفته‌به‌هفته  
      • محاسبه سن بارداری بر مبنای آخرین قاعدگی (LMP)  
      • تشخیص و درمان اولیه عفونت‌های واژینال  
      • راهنمایی زوج‌های نابارور  
      • غربالگری و پیشگیری سرطان پستان
    """

    domain_name: str = "obgyn"
    trigger_keywords: List[str] = [
        "بارداری",
        "هفته بارداری",
        "lmp",
        "نازایی",
        "ناباروری",
        "عفونت واژن",
        "عفونت قارچی",
        "تریکوموناس",
        "سرطان سینه",
        "ماموگرافی",
    ]

    # ------------------------- پرامپت -------------------------
    def _build_domain_prompt(self, message: str, patient_info: Dict) -> str:  # noqa: D401
        lmp_weeks = self._extract_lmp_weeks(message)
        preg_info = f"سن بارداری تخمینی: {lmp_weeks} هفته.\n" if lmp_weeks else ""

        return (
            "شما متخصص زنان و زایمان هستید. لطفاً به موارد زیر توجه کنید:\n"
            "• در صورت باردار بودن: مراقبت‌های هفته به هفته و هشدار علائم خطر.\n"
            "• در صورت شکایت عفونت: افتراق قارچی، باکتریایی، تریکومونایی.\n"
            "• مشاوره ناباروری: بررسی سیکل، آزمایش‌های هورمونی، سونوگرافی و IVF.\n"
            "• غربالگری سرطان پستان: توصیه ماموگرافی دوره‌ای و سونو در سنین مناسب.\n\n"
            f"{preg_info}"
            f"اطلاعات بیمار: سن {patient_info.get('age')} سال، "
            f"BMI {patient_info.get('bmi')}\n"
            f"پیام بیمار: «{message}»\n\n"
            "به فارسی روان و دقیق پاسخ دهید."
        )

    # --------------------- متد کمکی LMP ----------------------
    @staticmethod
    def _extract_lmp_weeks(message: str) -> int | None:
        """
        در متن به‌دنبال الگوی «LMP: YYYY-MM-DD» می‌گردد
        و هفتهٔ بارداری را محاسبه می‌کند.
        """
        if "lmp:" not in message.lower():
            return None
        try:
            lmp_str = (
                message.lower().split("lmp:")[1].strip().split()[0].replace("/", "-")
            )
            lmp_date = datetime.strptime(lmp_str, "%Y-%m-%d").date()
            delta_days = (datetime.today().date() - lmp_date).days
            return delta_days // 7
        except Exception:  # pylint: disable=broad-except
            return None
