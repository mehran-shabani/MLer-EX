"""
chatbot_pro.agents
==================
درگاه مرکزی همهٔ عامل‌های تخصصی (Agents).

🔹 هنگام بارگذاری Django، این پکیج مپینگ `DOMAIN_AGENT_MAP` را آماده می‌کند
   تا سایر بخش‌ها (مثلاً ConsultationService) بتوانند به‌سادگی عامل مناسب
   را فراخوانی کنند.  
🔹 در این پیام فقط سه فایل پایه ارائه شده‌اند؛ فایل‌های تخصصی دیگر در
   پیام‌های بعدی افزوده خواهند شد.
"""

# ------------------------------- Imports -------------------------------
from chatbot_pro.agents.cardiology_agent import CardiologyAgent
from chatbot_pro.agents.ent_derm_agent import EntDermatologyAgent
from chatbot_pro.agents.gastro_agent import GastroenterologyAgent
from chatbot_pro.agents.internal_agent import InternalMedicineAgent
from chatbot_pro.agents.medical_agent import MedicalAgent
from chatbot_pro.agents.nephrology_agent import NephrologyUrologyAgent
from chatbot_pro.agents.neurology_agent import NeurologyAgent
from chatbot_pro.agents.obgyn_agent import ObstetricsGynecologyAgent
from chatbot_pro.agents.psychaitry_agent import PsychiatryAgent
from chatbot_pro.agents.rheumatology_agent import RheumatologyAgent
from chatbot_pro.agents.surgery_agent import SurgeryAgent
from .family_agent import FamilyPhysicianAgent

# ↓↓↓ سایر Agentها در پیام‌های بعدی به این مپینگ افزوده خواهند شد ↓↓↓
# from .obgyn_agent import ObstetricsGynecologyAgent
# from .internal_agent import InternalMedicineAgent
# ...

# -------------------------- Mapping (domain → agent) -------------------
DOMAIN_AGENT_MAP = {
    "family": FamilyPhysicianAgent(),
    "obgyn": ObstetricsGynecologyAgent(),
    "internal": InternalMedicineAgent(),
    "cardiology": CardiologyAgent(),
    "psychiatry": PsychiatryAgent(),
    "neurology": NeurologyAgent(),
    "rheumatology": RheumatologyAgent(),
    "surgery": SurgeryAgent(),
    "gastro": GastroenterologyAgent(),
    "ent": EntDermatologyAgent(),
    "medical": MedicalAgent(),
    "nephrology": NephrologyUrologyAgent(),

   
}

__all__ = ["DOMAIN_AGENT_MAP", "FamilyPhysicianAgent"]
