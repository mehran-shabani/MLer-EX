# chatbot/models
from django.db import models

from telemedicine.models import CustomUser


class ChatSession(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    last_activity = models.DateTimeField(auto_now=True)  # زمان آخرین فعالیت در جلسه

    def __str__(self):
        return f"Session {self.id} for {self.user.username}"


class UserMessageLimit(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    message_count = models.PositiveIntegerField(default=0)
    message_limit = models.PositiveIntegerField(default=25)

    def increment_message_count(self):
        if self.message_count <= self.message_limit:
            self.message_count += 1
            self.save()
        pass


class ChatMessage(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE)
    message = models.TextField()
    is_bot = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Get or create a UserMessageLimit instance for the user
        user_message_limit, created = UserMessageLimit.objects.get_or_create(user=self.user)

        # Increment the message count and check the limit
        user_message_limit.increment_message_count()

        # Save the message after checking the limit
        super(ChatMessage, self).save(*args, **kwargs)

    def __str__(self):
        return f"{'Bot' if self.is_bot else 'User'}: {self.message[:50]}"
