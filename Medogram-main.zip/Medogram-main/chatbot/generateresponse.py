# chatbot/generateresponse.py

import requests  # کتابخانه برای درخواست‌های HTTP همگام
from medogram import settings
from .friendly_utils import FriendlyUtils
from .models import ChatMessage
from .cleaner import clean_bot_message

# دریافت کلید API از تنظیمات
apikey = settings.TALKBOT_API


def get_previous_response(user, user_message):
    """
    بررسی پیام‌های قبلی کاربر برای یافتن پاسخ تکراری و بازیابی پاسخ مربوط به آن.
    """
    # جستجو برای پیام مشابه از کاربر
    previous_message = ChatMessage.objects.filter(
        user=user,
        message=user_message,
        is_bot=False  # پیام کاربر (نه بات)
    ).first()

    if previous_message:
        # اگر پیام مشابهی وجود داشت، پاسخ مرتبط با آن را پیدا کنید
        bot_response = ChatMessage.objects.filter(
            id=previous_message.id + 1,  # ID پیام پاسخ
            is_bot=True  # پیام ربات (پاسخ)
        ).first()

        if bot_response:
            return bot_response.message  # بازگرداندن پیام ربات

    return None  # اگر پیام قبلی وجود نداشت


def generate_chat_context(session, max_history_length=3):
    """
    تولید تاریخچه چت برای ارسال به API.
    پیام‌ها را بازیابی کرده و تعداد آن‌ها را محدود می‌کند.
    """
    chat_messages = ChatMessage.objects.filter(session=session).order_by('-created_at')[:max_history_length]
    chat_messages = reversed(chat_messages)  # معکوس کردن ترتیب برای بازگشت به حالت اصلی

    messages = []
    for chat_message in chat_messages:
        role = "assistant" if chat_message.is_bot else "user"
        messages.append({"role": role, "content": chat_message.message})

    return messages


def send_request(payload, headers):
    """
    ارسال درخواست همگام به API.
    """
    url = 'https://api.talkbot.ir/v1/chat/completions'
    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error: {response.status_code} - {response.text}")
        return None


def complete_message(past_messages, user_message, bot_message, headers):
    """
    تکمیل پیام ناقص با استفاده از درخواست همگام.
    """
    additional_payload = {
        "model": "gpt-4o-mini",
        "messages": past_messages + [{"role": "user", "content": user_message}] + [
            {"role": "assistant", "content": bot_message}],
        "max_token": 100,
        "temperature": 0.7
    }

    response = send_request(additional_payload, headers)
    if response:
        return response.get('choices', [{}])[0].get('message', {}).get('content', '')
    return ""


def generate_gpt_response(session, user_message, max_history_length=5):
    """
    تولید پاسخ GPT برای پیام کاربر.
    --------------------------------------------------------------------------
    در این تابع ابتدا از توابع فرندلی یوتیل (FriendlyUtils) برای بررسی
    1) محتوای نامناسب
    2) پرسش درباره سرور
    3) پرسش درباره سازنده
    4) پرسش درباره اسم هوش
    استفاده می‌کنیم؛
    اگر هیچ‌کدام از این حالت‌ها نبود، پیام کاربر به API ارسال شده و نتیجه را برمی‌گردانیم.
    --------------------------------------------------------------------------
    """

    # 1) بررسی محتوای نامناسب
    inappropriate_content_response = FriendlyUtils.handle_inappropriate_content(user_message)
    if inappropriate_content_response:
        return inappropriate_content_response

    # 2) بررسی پرسش درباره محل سرور
    server_location_response = FriendlyUtils.get_server_location_response(user_message)
    if server_location_response:
        return server_location_response

    # 3) بررسی پیام درباره سازنده یا ماهیت ربات
    creator_response = FriendlyUtils.get_creator_response(user_message)
    if creator_response:
        return creator_response

    # 4) بررسی پیام درباره اسم هوش مصنوعی
    name_response = FriendlyUtils.get_ai_name_response(user_message)
    if name_response:
        return name_response


    # بررسی اینکه آیا کاربر قبلاً همین پیام را فرستاده و پاسخ مشابهی وجود دارد یا خیر
    previous_response = get_previous_response(session.user, user_message)
    if previous_response:
        return previous_response  # بازگرداندن پاسخ قبلی

    # تولید تاریخچه چت
    past_messages = generate_chat_context(session, max_history_length)

    # اضافه کردن پیام سیستمی برای تعیین نقش ربات
    past_messages.insert(0, {
        "role": "system",
        "content": (
            "شما یک پزشک بسیار دانا و با تجربه هستید. وظیفه شما تشخیص بیماری‌ها و "
            "پیشنهاد درمان‌های مناسب است. علائم بیمار را با دقت بررسی کنید و پیشنهادهای درمانی بدهید."
        )
    })

    # تنظیمات درخواست
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {apikey}'
    }
    payload = {
        "model": "gpt-4o-mini",
        "messages": past_messages + [{"role": "user", "content": user_message}],
        "max_token": 300,
        "temperature": 0.3,
        "stream": False,
        "top_p": 1.0,
        "frequency_penalty": 0.0,
        "presence_penalty": 0.0
    }

    # ارسال درخواست به API
    response = send_request(payload, headers)
    if response:
        bot_message = response.get('choices', [{}])[0].get('message', {}).get('content', '')

        # حذف جملات تکراری
        bot_message = FriendlyUtils.remove_repeated_phrases(bot_message)

        # تکمیل پیام‌های ناقص
        while not FriendlyUtils.is_message_complete(bot_message):
            bot_message += " " + complete_message(past_messages, user_message, bot_message, headers)
            break  # فقط یک بار تکمیل پیام کافی است

        # پاکسازی پیام ربات
        bot_message = clean_bot_message(bot_message)

        # اضافه کردن حس صمیمیت و شوخ‌طبعی
        bot_message = FriendlyUtils.add_emojis_and_friendly_tone(bot_message)

        # ذخیره پیام کاربر و پاسخ ربات در پایگاه داده
        ChatMessage.objects.create(session=session, user=session.user, message=user_message, is_bot=False)
        ChatMessage.objects.create(session=session, user=session.user, message=bot_message, is_bot=True)

        return bot_message
    else:
        return "🤔 متأسفانه مشکلی در ارتباط با سرور رخ داده است. لطفاً دوباره تلاش کنید. 🔄"
