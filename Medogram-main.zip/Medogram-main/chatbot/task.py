from celery import shared_task
from django.contrib.auth import get_user_model
from .models import UserMessageLimit


@shared_task
def reset_message_limit():
    User = get_user_model()
    users = User.objects.all()

    for user in users:
        user_limit, created = UserMessageLimit.objects.get_or_create(user=user)
        user_limit.message_count = 5
        user_limit.save()

    return "User message limits reset to 5 for all users"
