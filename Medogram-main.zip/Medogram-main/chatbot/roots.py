# chatbot/roots
from django.urls import path
from .views import ChatbotAPIView

urlpatterns = [
    path('api/chat/message', ChatbotAPIView.as_view(), name='chatbot_view'),
]