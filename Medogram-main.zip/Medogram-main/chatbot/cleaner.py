# chatbot/cleaner
import re


def clean_bot_message(message):
    """
    تمیزکاری پیام بدون حذف ایموجی‌ها
    """
    # 1. حذف فاصله‌های اضافی از ابتدا و انتهای پیام
    cleaned_message = message.strip()

    # 2. حذف فاصله‌های دوبل داخل متن
    cleaned_message = re.sub(r'\s+', ' ', cleaned_message)

    # 3. تبدیل خط‌های جدید به <br> برای نمایش در HTML
    cleaned_message = cleaned_message.replace('\n', '<br>')

    # 4. اصلاح علائم نگارشی در زبان فارسی
    cleaned_message = cleaned_message.replace(',', '،')  # ویرگول فارسی
    cleaned_message = re.sub(r'\.{2,}', '…', cleaned_message)  # تبدیل چند نقطه به …

    # 5. اصلاح نیم‌فاصله‌ها (در صورت نیاز)
    cleaned_message = re.sub(r'\s*-\s*', '‌', cleaned_message)  # استفاده از نیم‌فاصله صحیح

    # 6. حذف کاراکترهای غیرمجاز (بدون حذف ایموجی‌ها)
    # ایموجی‌ها در محدوده‌های یونیکد باقی می‌مانند
    cleaned_message = re.sub(r'[^\w\s\.\،\؟\!\-\«\»\"\(\)\[\]\{\}]', '', cleaned_message)

    # 7. اصلاح فاصله‌گذاری علائم نگارشی
    cleaned_message = re.sub(r'\s*([،.؟!…])', r'\1', cleaned_message)  # حذف فاصله قبل از علائم
    cleaned_message = re.sub(r'([،.؟!…])\s*', r'\1 ', cleaned_message)  # افزودن فاصله بعد از علائم

    # 8. تبدیل نقل‌قول‌ها به شکل استاندارد
    cleaned_message = cleaned_message.replace('"', '«').replace("'", "»")

    # 9. جایگزینی پرانتزهای انگلیسی با فارسی
    cleaned_message = cleaned_message.replace('(', '«').replace(')', '»')

    # 10. حذف تکرار کلمات یا علائم نگارشی (مثل !!! -> !!)
    cleaned_message = re.sub(r'(.)\1{2,}', r'\1\1', cleaned_message)

    return cleaned_message
