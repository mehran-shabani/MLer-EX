# chatbot/views
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.core.exceptions import ValidationError
from django.db import transaction
from .models import ChatSession, ChatMessage, UserMessageLimit
from telemedicine.models import BoxMoney
from .generateresponse import generate_gpt_response
import logging
from datetime import timedelta
from django.utils.timezone import now

logger = logging.getLogger(__name__)


def deduct_from_box_money(user, amount):
    try:
        box_money = BoxMoney.objects.get(user=user)
        if box_money.amount >= amount:
            box_money.amount -= amount
            box_money.save()
        else:
            raise ValidationError("Insufficient funds in BoxMoney.")
    except BoxMoney.DoesNotExist:
        raise ValidationError("BoxMoney does not exist for this user.")


def get_or_create_session(user):
    """
    بازیابی یا ایجاد یک جلسه فعال برای کاربر.
    اگر جلسه‌ای فعال نباشد یا منقضی شده باشد، یک جلسه جدید ایجاد می‌شود.
    """
    # تعریف بازه زمانی برای انقضای جلسه (مثلاً 30 دقیقه)
    session_expiry_time = timedelta(minutes=30)

    # جستجوی جلسه فعال برای کاربر
    session = ChatSession.objects.filter(user=user).order_by('-created_at').first()

    if session and (now() - session.created_at <= session_expiry_time):
        # اگر جلسه‌ای فعال و معتبر وجود داشت، همان بازگردانده می‌شود
        return session
    else:
        # در غیر این صورت، یک جلسه جدید ایجاد می‌شود
        return ChatSession.objects.create(user=user)


def create_user_message(session, user, message):
    ChatMessage.objects.create(session=session, user=user, message=message, is_bot=False)


def handle_message_limit(user, session, bot_response):
    try:
        user_limit = UserMessageLimit.objects.get(user=user)
        if user_limit.message_count < user_limit.message_limit:
            user_limit.message_count += 1
            user_limit.save()
        else:
            deduct_from_box_money(user, 250)

        ChatMessage.objects.create(session=session, user=user, message=bot_response, is_bot=True)
    except UserMessageLimit.DoesNotExist:
        raise ValidationError("User message limit not set for this user.")


def get_bot_response(session, user_message):
    """
    دریافت پاسخ بات به صورت همگام.
    """
    bot_message = generate_gpt_response(session, user_message)
    return bot_message


class ChatbotAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        user_message = request.data.get('message')

        if not user_message:
            return Response({"error": "Message is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with transaction.atomic():
                # دریافت جلسه فعال یا ایجاد جلسه جدید
                session = get_or_create_session(user)

                # ثبت پیام کاربر
                create_user_message(session, user, user_message)

                # دریافت پاسخ بات
                bot_response = get_bot_response(session, user_message)

                if bot_response is None:
                    return Response({"error": "Timeout: Bot did not respond in time."},
                                    status=status.HTTP_408_REQUEST_TIMEOUT)

                # مدیریت محدودیت پیام‌ها و ذخیره پیام بات
                handle_message_limit(user, session, bot_response)

            return Response({"bot_response": bot_response}, status=status.HTTP_200_OK)

        except ValidationError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error(f"Unexpected error in ChatbotAPIView: {str(e)}")
            return Response({"error": "An unexpected error occurred."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
