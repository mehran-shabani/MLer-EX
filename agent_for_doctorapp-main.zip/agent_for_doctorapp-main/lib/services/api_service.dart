import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:8000/chat';
  String? _accessToken;

  // Singleton pattern
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  String get baseUrl => 'http://localhost:8000/chat';

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_accessToken != null) 'Authorization': 'Bearer $_accessToken',
  };

  // OTP Request
  Future<Map<String, dynamic>> requestOtp(String phoneNumber) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/request-otp/'),
        headers: _headers,
        body: jsonEncode({'phone_number': phoneNumber}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to request OTP: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // OTP Verification
  Future<Map<String, dynamic>> verifyOtp(String phoneNumber, String otpCode) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/verify-otp/'),
        headers: _headers,
        body: jsonEncode({
          'phone_number': phoneNumber,
          'otp_code': otpCode,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['access_token'] != null) {
          _accessToken = data['access_token'];
        }
        return data;
      } else {
        throw Exception('Failed to verify OTP: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Create User Session
  Future<Map<String, dynamic>> createSession() async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/create-session/'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to create session: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Create Doctor Session
  Future<Map<String, dynamic>> createDoctorSession(String phoneNumber) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/create-session-for-doctor/'),
        headers: _headers,
        body: jsonEncode({'phone_number': phoneNumber}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to create doctor session: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Send Message
  Future<Map<String, dynamic>> sendMessage(String sessionId, String message, {String? imageUrl}) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/send-message/'),
        headers: _headers,
        body: jsonEncode({
          'session_id': sessionId,
          'message': message,
          if (imageUrl != null) 'image_url': imageUrl,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to send message: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Upload Image
  Future<Map<String, dynamic>> uploadImage(String sessionId, File imageFile) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/upload-image/'),
      );

      // Add headers
      if (_accessToken != null) {
        request.headers['Authorization'] = 'Bearer $_accessToken';
      }

      // Add fields
      request.fields['session_id'] = sessionId;

      // Add file
      request.files.add(
        await http.MultipartFile.fromPath('image', imageFile.path),
      );

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to upload image: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // End Session
  Future<Map<String, dynamic>> endSession(String sessionId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/end-session/'),
        headers: _headers,
        body: jsonEncode({'session_id': sessionId}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to end session: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get Patient Summary
  Future<Map<String, dynamic>> getPatientSummary(String patientId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/patient-summary/$patientId/'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get patient summary: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get Session Summary
  Future<Map<String, dynamic>> getSessionSummary(String sessionId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/session-summary/$sessionId/'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get session summary: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Clear token (logout)
  void clearToken() {
    _accessToken = null;
  }

  // Check if authenticated
  bool get isAuthenticated => _accessToken != null;
}
