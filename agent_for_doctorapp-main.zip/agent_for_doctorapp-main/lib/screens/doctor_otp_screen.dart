import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/api_service.dart';
import '../theme/app_colors.dart';

class DoctorOTPScreen extends StatefulWidget {
  const DoctorOTPScreen({super.key});

  @override
  State<DoctorOTPScreen> createState() => _DoctorOTPScreenState();
}

class _DoctorOTPScreenState extends State<DoctorOTPScreen> {
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();
  final ApiService _apiService = ApiService();
  
  bool _isPhoneValid = false;
  bool _isOtpSent = false;
  bool _isLoading = false;
  String? _phoneError;
  String? _otpError;
  int _timerSeconds = 60;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _phoneController.addListener(_validatePhone);
    _otpController.addListener(_validateOtp);
  }

  void _validatePhone() {
    final phone = _phoneController.text;
    final phoneRegex = RegExp(r'^09\d{9}$');
    
    setState(() {
      _isPhoneValid = phoneRegex.hasMatch(phone);
      if (phone.isNotEmpty && !_isPhoneValid) {
        _phoneError = 'شماره موبایل باید 11 رقم و با 09 شروع شود';
      } else {
        _phoneError = null;
      }
    });
  }

  void _validateOtp() {
    final otp = _otpController.text;
    
    setState(() {
      if (otp.isNotEmpty && otp.length != 6) {
        _otpError = 'کد تأیید باید 6 رقم باشد';
      } else {
        _otpError = null;
      }
    });

    // Auto-submit when 6 digits entered
    if (otp.length == 6) {
      _verifyOtp();
    }
  }

  Future<void> _requestOtp() async {
    if (!_isPhoneValid) return;

    setState(() {
      _isLoading = true;
    });

    try {
      await _apiService.requestOtp(_phoneController.text);
      
      setState(() {
        _isOtpSent = true;
        _isLoading = false;
        _timerSeconds = 60;
      });

      _startTimer();
      _showSuccess('کد تأیید ارسال شد');
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showError('خطا در ارسال کد: $e');
    }
  }

  Future<void> _verifyOtp() async {
    if (_otpController.text.length != 6) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Verify OTP
      final otpResponse = await _apiService.verifyOtp(
        _phoneController.text,
        _otpController.text,
      );

      // Create doctor session
      final sessionResponse = await _apiService.createDoctorSession(
        _phoneController.text,
      );

      setState(() {
        _isLoading = false;
      });

      // Return session ID to previous screen
      Navigator.pop(context, sessionResponse['session_id']);
      
    } catch (e) {
      setState(() {
        _isLoading = false;
        _otpError = 'کد تأیید نادرست است';
      });
      _showError('خطا در تأیید کد: $e');
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_timerSeconds > 0) {
          _timerSeconds--;
        } else {
          timer.cancel();
        }
      });
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ورود پزشک',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: AppColors.primaryGreen,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.primaryGradient,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 40),

                // Header
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Icon(
                        Icons.medical_services,
                        size: 60,
                        color: AppColors.primaryGreen,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'دسترسی به پرونده بیمار',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _isOtpSent 
                          ? 'کد تأیید ارسال شده را وارد کنید'
                          : 'شماره موبایل خود را وارد کنید',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 32),

                // Phone Input
                if (!_isOtpSent) ...[
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      textDirection: TextDirection.ltr,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(11),
                      ],
                      decoration: InputDecoration(
                        labelText: 'شماره موبایل',
                        hintText: '09123456789',
                        hintTextDirection: TextDirection.ltr,
                        prefixIcon: const Icon(Icons.phone),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Colors.white,
                        errorText: _phoneError,
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Send OTP Button
                  ElevatedButton(
                    onPressed: _isPhoneValid && !_isLoading ? _requestOtp : null,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 5,
                    ).copyWith(
                      backgroundColor: MaterialStateProperty.resolveWith((states) {
                        if (states.contains(MaterialState.disabled)) {
                          return Colors.grey[300];
                        }
                        return AppColors.primaryGreen;
                      }),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : const Text(
                            'ارسال کد تأیید',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                  ),
                ],

                // OTP Input
                if (_isOtpSent) ...[
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _otpController,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(6),
                      ],
                      decoration: InputDecoration(
                        labelText: 'کد تأیید',
                        hintText: '123456',
                        prefixIcon: const Icon(Icons.security),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Colors.white,
                        errorText: _otpError,
                      ),
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 8,
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Timer and Resend
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (_timerSeconds > 0)
                        Text(
                          'ارسال مجدد در $_timerSeconds ثانیه',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 14,
                          ),
                        )
                      else
                        TextButton(
                          onPressed: _requestOtp,
                          child: Text(
                            'ارسال مجدد کد',
                            style: TextStyle(
                              color: AppColors.primaryGreen,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      
                      Text(
                        'کد دمو: 123456',
                        style: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // Loading indicator when verifying
                  if (_isLoading)
                    const Center(
                      child: Column(
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 16),
                          Text(
                            'در حال تأیید کد...',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],

                const Spacer(),

                // Info
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.blue[200]!),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: Colors.blue[600]),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'این بخش فقط برای پزشکان جهت دسترسی به اطلاعات بیماران می‌باشد.',
                          style: TextStyle(
                            color: Colors.blue[800],
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _otpController.dispose();
    _timer?.cancel();
    super.dispose();
  }
}
