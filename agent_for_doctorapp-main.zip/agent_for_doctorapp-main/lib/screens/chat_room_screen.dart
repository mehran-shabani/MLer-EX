import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/api_service.dart';
import '../models/chat_models.dart';
import '../theme/app_colors.dart';
import '../widgets/message_bubble.dart';
import '../widgets/typing_indicator.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'doctor_otp_screen.dart';

class ChatRoomScreen extends StatefulWidget {
  final String? sessionId;
  final bool isDoctor;

  const ChatRoomScreen({
    super.key,
    this.sessionId,
    this.isDoctor = false,
  });

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  final ApiService _apiService = ApiService();
  final ImagePicker _imagePicker = ImagePicker();
  
  bool _isTyping = false;
  String? _currentSessionId;

  @override
  void initState() {
    super.initState();
    _currentSessionId = widget.sessionId;
    _initializeSession();
  }

  Future<void> _initializeSession() async {
    if (_currentSessionId == null) {
      try {
        final response = await _apiService.createSession();
        setState(() {
          _currentSessionId = response['session_id'];
        });
      } catch (e) {
        _showError('خطا در ایجاد جلسه: $e');
      }
    }
  }

  String get _appBarTitle {
    if (widget.isDoctor && _currentSessionId != null) {
      return 'Visit $_currentSessionId';
    }
    return 'MedAgent Assistant';
  }

  Future<void> _sendMessage(String content, {File? imageFile}) async {
    if (content.trim().isEmpty && imageFile == null) return;

    final message = ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      content: content,
      isUser: true,
      timestamp: DateTime.now(),
      status: MessageStatus.sending,
    );

    setState(() {
      _messages.add(message);
      _messageController.clear();
    });

    _scrollToBottom();

    try {
      String? imageUrl;
      
      // Upload image if provided
      if (imageFile != null && _currentSessionId != null) {
        setState(() {
          final index = _messages.indexOf(message);
          _messages[index] = message.copyWith(content: 'در حال آپلود تصویر...');
        });

        final uploadResponse = await _apiService.uploadImage(_currentSessionId!, imageFile);
        imageUrl = uploadResponse['image_url'];
        
        setState(() {
          final index = _messages.indexOf(message);
          _messages[index] = message.copyWith(
            content: content.isEmpty ? 'تصویر ارسال شد ✓' : content,
            imageUrl: imageUrl,
          );
        });
      }

      // Send message to API
      if (_currentSessionId != null) {
        final response = await _apiService.sendMessage(
          _currentSessionId!,
          content.isEmpty ? 'تصویر ارسال شد' : content,
          imageUrl: imageUrl,
        );

        // Update message status to sent
        setState(() {
          final index = _messages.indexOf(message);
          _messages[index] = message.copyWith(status: MessageStatus.sent);
        });

        // Show typing indicator
        setState(() {
          _isTyping = true;
        });

        // Simulate AI response delay
        await Future.delayed(const Duration(seconds: 2));

        // Add AI response
        final aiResponse = ChatMessage(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          content: response['ai_response'] ?? _getRandomAIResponse(),
          isUser: false,
          timestamp: DateTime.now(),
        );

        setState(() {
          _isTyping = false;
          _messages.add(aiResponse);
        });

        _scrollToBottom();
      }
    } catch (e) {
      // Update message status to error
      setState(() {
        final index = _messages.indexOf(message);
        _messages[index] = message.copyWith(
          status: MessageStatus.error,
          content: '${message.content} ❌',
        );
      });
      _showError('خطا در ارسال پیام: $e');
    }
  }

  String _getRandomAIResponse() {
    final responses = [
      'سلام! من دستیار پزشکی هوشمند هستم. چطور می‌تونم کمکتون کنم؟',
      'لطفاً علائم خود را با جزئیات بیشتر توضیح دهید تا بتوانم راهنمایی بهتری ارائه دهم.',
      'بر اساس توضیحات شما، توصیه می‌کنم با پزشک متخصص مشورت کنید.',
      'آیا این علائم اخیراً شروع شده یا مدتی است که دارید؟',
      'لطفاً سابقه پزشکی و داروهای مصرفی خود را ذکر کنید.',
      'توصیه می‌کنم استراحت کافی داشته باشید و مایعات زیادی مصرف کنید.',
      'در صورت تداوم علائم، حتماً به پزشک مراجعه کنید.',
      'آیا سوال دیگری دارید که بتوانم کمکتان کنم؟',
    ];
    return responses[DateTime.now().millisecond % responses.length];
  }

  Future<void> _takePicture() async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.camera,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        final File imageFile = File(image.path);
        await _sendMessage('', imageFile: imageFile);
      }
    } catch (e) {
      _showError('خطا در گرفتن عکس: $e');
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _navigateToDoctorOTP() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const DoctorOTPScreen(),
      ),
    );

    if (result != null && result is String) {
      // Doctor authenticated successfully, update session
      setState(() {
        _currentSessionId = result;
      });
      
      // Navigate to new chat room with doctor session
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ChatRoomScreen(
            sessionId: result,
            isDoctor: true,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _appBarTitle,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: AppColors.primaryGreen,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.primaryGradient,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: Column(
          children: [
            // Doctor Access Button (only show if not already a doctor session)
            if (!widget.isDoctor)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                child: ElevatedButton.icon(
                  onPressed: _navigateToDoctorOTP,
                  icon: const Icon(Icons.medical_services, color: Colors.white),
                  label: const Text(
                    'ورود به پرونده بیمار',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accentGreen,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    elevation: 3,
                  ),
                ),
              ),

            // Messages List
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                itemCount: _messages.length + (_isTyping ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == _messages.length && _isTyping) {
                    return const TypingIndicator();
                  }
                  return MessageBubble(message: _messages[index]);
                },
              ),
            ),

            // Message Input
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  // Camera Button
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.primaryGreen,
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: IconButton(
                      onPressed: _takePicture,
                      icon: const Icon(Icons.camera_alt, color: Colors.white),
                      tooltip: 'گرفتن عکس',
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Message Input Field
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(color: Colors.grey[300]!),
                      ),
                      child: TextField(
                        controller: _messageController,
                        textDirection: TextDirection.rtl,
                        decoration: const InputDecoration(
                          hintText: 'پیام خود را بنویسید...',
                          hintTextDirection: TextDirection.rtl,
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                        ),
                        maxLines: null,
                        onSubmitted: (value) => _sendMessage(value),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Send Button
                  Container(
                    decoration: BoxDecoration(
                      gradient: AppColors.primaryGradient,
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: IconButton(
                      onPressed: () => _sendMessage(_messageController.text),
                      icon: const Icon(Icons.send, color: Colors.white),
                      tooltip: 'ارسال پیام',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}
