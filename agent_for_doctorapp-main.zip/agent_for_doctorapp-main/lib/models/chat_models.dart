enum MessageStatus { sending, sent, error }

class ChatMessage {
  final String id;
  final String content;
  final bool isUser;
  final DateTime timestamp;
  final String? imageUrl;
  final MessageStatus status;

  ChatMessage({
    required this.id,
    required this.content,
    required this.isUser,
    required this.timestamp,
    this.imageUrl,
    this.status = MessageStatus.sent,
  });

  bool get hasImage => imageUrl != null && imageUrl!.isNotEmpty;
  bool get isSending => status == MessageStatus.sending;
  bool get isSent => status == MessageStatus.sent;
  bool get hasError => status == MessageStatus.error;

  ChatMessage copyWith({
    String? id,
    String? content,
    bool? isUser,
    DateTime? timestamp,
    String? imageUrl,
    MessageStatus? status,
  }) {
    return ChatMessage(
      id: id ?? this.id,
      content: content ?? this.content,
      isUser: isUser ?? this.isUser,
      timestamp: timestamp ?? this.timestamp,
      imageUrl: imageUrl ?? this.imageUrl,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'isUser': isUser,
      'timestamp': timestamp.toIso8601String(),
      'imageUrl': imageUrl,
      'status': status.toString(),
    };
  }

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'],
      content: json['content'],
      isUser: json['isUser'],
      timestamp: DateTime.parse(json['timestamp']),
      imageUrl: json['imageUrl'],
      status: MessageStatus.values.firstWhere(
        (e) => e.toString() == json['status'],
        orElse: () => MessageStatus.sent,
      ),
    );
  }
}

class UserSession {
  final String sessionId;
  final String userId;
  final bool isDoctor;
  final DateTime createdAt;
  final DateTime? endedAt;

  UserSession({
    required this.sessionId,
    required this.userId,
    required this.isDoctor,
    required this.createdAt,
    this.endedAt,
  });

  bool get isActive => endedAt == null;

  Map<String, dynamic> toJson() {
    return {
      'sessionId': sessionId,
      'userId': userId,
      'isDoctor': isDoctor,
      'createdAt': createdAt.toIso8601String(),
      'endedAt': endedAt?.toIso8601String(),
    };
  }

  factory UserSession.fromJson(Map<String, dynamic> json) {
    return UserSession(
      sessionId: json['sessionId'],
      userId: json['userId'],
      isDoctor: json['isDoctor'],
      createdAt: DateTime.parse(json['createdAt']),
      endedAt: json['endedAt'] != null ? DateTime.parse(json['endedAt']) : null,
    );
  }
}

class DoctorSession extends UserSession {
  final String doctorId;
  final String patientId;
  final String phoneNumber;

  DoctorSession({
    required String sessionId,
    required this.doctorId,
    required this.patientId,
    required this.phoneNumber,
    required DateTime createdAt,
    DateTime? endedAt,
  }) : super(
          sessionId: sessionId,
          userId: doctorId,
          isDoctor: true,
          createdAt: createdAt,
          endedAt: endedAt,
        );

  @override
  Map<String, dynamic> toJson() {
    final json = super.toJson();
    json.addAll({
      'doctorId': doctorId,
      'patientId': patientId,
      'phoneNumber': phoneNumber,
    });
    return json;
  }

  factory DoctorSession.fromJson(Map<String, dynamic> json) {
    return DoctorSession(
      sessionId: json['sessionId'],
      doctorId: json['doctorId'],
      patientId: json['patientId'],
      phoneNumber: json['phoneNumber'],
      createdAt: DateTime.parse(json['createdAt']),
      endedAt: json['endedAt'] != null ? DateTime.parse(json['endedAt']) : null,
    );
  }
}

class ApiResponse<T> {
  final bool success;
  final T? data;
  final String? error;
  final int? statusCode;

  ApiResponse({
    required this.success,
    this.data,
    this.error,
    this.statusCode,
  });

  factory ApiResponse.success(T data) {
    return ApiResponse(
      success: true,
      data: data,
    );
  }

  factory ApiResponse.error(String error, {int? statusCode}) {
    return ApiResponse(
      success: false,
      error: error,
      statusCode: statusCode,
    );
  }
}
