import 'package:flutter/material.dart';
import 'screens/chat_room_screen.dart';

void main() {
  runApp(const MedAgentChatApp());
}

class MedAgentChatApp extends StatelessWidget {
  const MedAgentChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MedAgent Chat',
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Vazir',
        useMaterial3: true,
      ),
      home: const ChatRoomScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
