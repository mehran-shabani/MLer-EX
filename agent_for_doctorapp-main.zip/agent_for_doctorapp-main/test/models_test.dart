import 'package:flutter_test/flutter_test.dart';
import 'package:medagent_chat/models/chat_models.dart';

void main() {
  group('Chat Models Tests', () {
    test('ChatMessage should create correctly', () {
      final message = ChatMessage(
        id: '1',
        content: 'Test message',
        isUser: true,
        timestamp: DateTime.now(),
      );

      expect(message.id, '1');
      expect(message.content, 'Test message');
      expect(message.isUser, true);
      expect(message.timestamp, isA<DateTime>());
    });

    test('ChatMessage should handle image messages', () {
      final message = ChatMessage(
        id: '2',
        content: 'Image message',
        isUser: true,
        timestamp: DateTime.now(),
        imageUrl: 'path/to/image.jpg',
      );

      expect(message.imageUrl, 'path/to/image.jpg');
      expect(message.hasImage, true);
    });

    test('ChatMessage should handle status correctly', () {
      final message = ChatMessage(
        id: '3',
        content: 'Test message',
        isUser: true,
        timestamp: DateTime.now(),
        status: MessageStatus.sending,
      );

      expect(message.status, MessageStatus.sending);
      expect(message.isSending, true);
      expect(message.isSent, false);
      expect(message.hasError, false);
    });

    test('UserSession should create correctly', () {
      final session = UserSession(
        sessionId: 'session123',
        userId: 'user456',
        isDoctor: false,
        createdAt: DateTime.now(),
      );

      expect(session.sessionId, 'session123');
      expect(session.userId, 'user456');
      expect(session.isDoctor, false);
      expect(session.createdAt, isA<DateTime>());
    });

    test('DoctorSession should create correctly', () {
      final session = DoctorSession(
        sessionId: 'doc_session123',
        doctorId: 'doctor456',
        patientId: 'patient789',
        phoneNumber: '09123456789',
        createdAt: DateTime.now(),
      );

      expect(session.sessionId, 'doc_session123');
      expect(session.doctorId, 'doctor456');
      expect(session.patientId, 'patient789');
      expect(session.phoneNumber, '09123456789');
      expect(session.createdAt, isA<DateTime>());
    });
  });
}
