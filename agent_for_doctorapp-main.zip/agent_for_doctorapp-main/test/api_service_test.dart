import 'package:flutter_test/flutter_test.dart';
import 'package:medagent_chat/services/api_service.dart';

void main() {
  group('ApiService Tests', () {
    late ApiService apiService;

    setUp(() {
      apiService = ApiService();
    });

    test('should initialize with correct base URL', () {
      expect(apiService.baseUrl, 'http://localhost:8000/chat');
    });

    test('should validate phone number format correctly', () {
      // This would test the phone validation logic
      // In a real scenario, you'd extract the validation to a separate method
      final phoneRegex = RegExp(r'^09\d{9}$');
      
      expect(phoneRegex.hasMatch('09123456789'), true);
      expect(phoneRegex.hasMatch('09987654321'), true);
      expect(phoneRegex.hasMatch('9123456789'), false);
      expect(phoneRegex.hasMatch('091234567890'), false);
    });

    test('should format session ID correctly', () {
      const sessionId = 'abc123def456';
      const expected = 'Visit abc123def456';
      
      expect('Visit $sessionId', expected);
    });

    // Add more API service tests here
    // Note: For real HTTP testing, you'd use packages like mockito or http_mock_adapter
  });
}
