import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:medagent_chat/main.dart';

void main() {
  group('MedAgent Chat App Tests', () {
    testWidgets('App should start with chat room', (WidgetTester tester) async {
      // Build our app and trigger a frame.
      await tester.pumpWidget(const MedAgentChatApp());

      // Verify that the app starts with the chat room
      expect(find.text('MedAgent Assistant'), findsOneWidget);
      expect(find.byType(TextField), findsOneWidget);
      
      // Verify the doctor access button exists
      expect(find.text('ورود به پرونده بیمار'), findsOneWidget);
    });

    testWidgets('Doctor access button should navigate to OTP screen', (WidgetTester tester) async {
      await tester.pumpWidget(const MedAgentChatApp());

      // Tap the doctor access button
      await tester.tap(find.text('ورود به پرونده بیمار'));
      await tester.pumpAndSettle();

      // Verify navigation to OTP screen
      expect(find.text('ورود پزشک'), findsOneWidget);
      expect(find.text('شماره موبایل خود را وارد کنید'), findsOneWidget);
    });

    testWidgets('Phone number validation should work correctly', (WidgetTester tester) async {
      await tester.pumpWidget(const MedAgentChatApp());

      // Navigate to OTP screen
      await tester.tap(find.text('ورود به پرونده بیمار'));
      await tester.pumpAndSettle();

      // Test invalid phone number
      await tester.enterText(find.byType(TextField), '123456789');
      await tester.pump();

      // Should show error for invalid format
      expect(find.text('شماره موبایل باید 11 رقم و با 09 شروع شود'), findsOneWidget);

      // Test valid phone number
      await tester.enterText(find.byType(TextField), '09123456789');
      await tester.pump();

      // Error should disappear
      expect(find.text('شماره موبایل باید 11 رقم و با 09 شروع شود'), findsNothing);
    });

    testWidgets('Chat message should be sent correctly', (WidgetTester tester) async {
      await tester.pumpWidget(const MedAgentChatApp());

      // Find the message input field
      final messageField = find.byType(TextField);
      expect(messageField, findsOneWidget);

      // Enter a test message
      await tester.enterText(messageField, 'سلام، چطور می‌تونم کمکتون کنم؟');
      await tester.pump();

      // Tap send button
      await tester.tap(find.byIcon(Icons.send));
      await tester.pump();

      // Verify message appears in chat
      expect(find.text('سلام، چطور می‌تونم کمکتون کنم؟'), findsOneWidget);
    });

    testWidgets('Camera button should be present', (WidgetTester tester) async {
      await tester.pumpWidget(const MedAgentChatApp());

      // Verify camera button exists
      expect(find.byIcon(Icons.camera_alt), findsOneWidget);
    });
  });

  group('API Service Tests', () {
    test('Phone number validation regex should work', () {
      final phoneRegex = RegExp(r'^09\d{9}$');
      
      // Valid phone numbers
      expect(phoneRegex.hasMatch('09123456789'), true);
      expect(phoneRegex.hasMatch('09987654321'), true);
      
      // Invalid phone numbers
      expect(phoneRegex.hasMatch('9123456789'), false);
      expect(phoneRegex.hasMatch('091234567890'), false);
      expect(phoneRegex.hasMatch('08123456789'), false);
      expect(phoneRegex.hasMatch('abc'), false);
    });

    test('OTP validation should work', () {
      final otpRegex = RegExp(r'^\d{6}$');
      
      // Valid OTP
      expect(otpRegex.hasMatch('123456'), true);
      expect(otpRegex.hasMatch('000000'), true);
      
      // Invalid OTP
      expect(otpRegex.hasMatch('12345'), false);
      expect(otpRegex.hasMatch('1234567'), false);
      expect(otpRegex.hasMatch('abc123'), false);
    });
  });
}
