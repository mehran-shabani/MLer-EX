from django.db import models
from django.utils.timezone import now

class BaleUser(models.Model):
    chat_id = models.CharField(max_length=50, unique=True)
    phone_number = models.CharField(max_length=15, unique=True)
    otp = models.CharField(max_length=6, blank=True, null=True)
    is_authenticated = models.BooleanField(default=False)
    daily_message_limit = models.PositiveIntegerField(default=23)
    current_message_count = models.PositiveIntegerField(default=0)
    token_limit = models.PositiveIntegerField(
        default=300,
        help_text="Maximum tokens for the response. Must be between 300 and 1000."
    )

    ASSISTANT_ROLES = [
        ('general_physician', 'پزشک عمومی'),
        ('surgeon', 'جراح'),
        ('psychologist', 'روانشناس'),
        ('psychiatrist', 'روانپزشک'),
        ('pain_specialist', 'متخصص درد'),
        ('cardiologist', 'متخصص قلب'),
        ('neurologist', 'متخصص مغز و اعصاب'),
        ('endocrinologist', 'متخصص غدد'),
        ('pediatrician', 'متخصص اطفال'),
        ('dermatologist', 'متخصص پوست'),
        ('orthopedic', 'متخصص ارتوپدی'),
    ]
    assistant_role = models.CharField(
        max_length=50,
        choices=ASSISTANT_ROLES,
        default='general_physician'
    )

    SYSTEM_ROLES = [
        ('therapeutic', 'سیستم درمانی'),
        ('diagnostic', 'سیستم تشخیصی'),
        ('triage', 'سیستم تریاژ'),
        ('predictive', 'سیستم پیش‌بینی'),
        ('educational', 'سیستم آموزشی'),
        ('research', 'سیستم پژوهشی'),
    ]
    system_role = models.CharField(
        max_length=50,
        choices=SYSTEM_ROLES,
        default='therapeutic'
    )

    ROLE_DESCRIPTIONS = {
        'general_physician': "شما یک پزشک عمومی بسیار با تجربه هستید.",
        'surgeon': "شما یک جراح متخصص با مهارت بالا هستید.",
        'psychologist': "شما یک روانشناس دلسوز هستید.",
        'psychiatrist': "شما یک روانپزشک حرفه‌ای هستید.",
        'pain_specialist': "شما متخصص درد با تجربه هستید.",
        'cardiologist': "شما متخصص قلب با دانش بالا هستید.",
        'neurologist': "شما متخصص مغز و اعصاب هستید.",
        'endocrinologist': "شما متخصص غدد هستید.",
        'pediatrician': "شما متخصص اطفال هستید.",
        'dermatologist': "شما متخصص پوست هستید.",
        'orthopedic': "شما متخصص ارتوپدی هستید.",
    }
    def get_assistant_description(self):
        return self.ROLE_DESCRIPTIONS.get(self.assistant_role, "توضیحی موجود نیست.")
    
    def reset_daily_count(self):
        self.current_message_count = 0
        self.save()
    
    def increment_message_count(self):
        if self.current_message_count < self.daily_message_limit:
            self.current_message_count += 1
            self.save()
            return True
        return False
    
    def __str__(self):
        return f"{self.phone_number} - Auth: {self.is_authenticated}"

class ChatSession(models.Model):
    user = models.ForeignKey(BaleUser, on_delete=models.CASCADE, related_name='chat_sessions')
    is_active = models.BooleanField(default=False)
    user_message = models.TextField()
    bot_response = models.TextField()
    assistant_role = models.CharField(max_length=50)
    system_role = models.CharField(max_length=50)
    created_at = models.DateTimeField(default=now)
    
    def __str__(self):
        return f"Session {self.id} - User: {self.user.phone_number}"
    
    class Meta:
        ordering = ['-created_at']

class Transaction(models.Model):
    user = models.ForeignKey(BaleUser, on_delete=models.CASCADE, related_name='transactions')
    trans_id = models.CharField(max_length=100, blank=True, null=True)
    amount = models.PositiveIntegerField()
    card_num = models.CharField(max_length=100, blank=True, null=True)
    factor_id = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(max_length=20, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Transaction {self.user.phone_number} - {self.amount} - {self.status}"

class Visit(models.Model):
    URGENCY_CHOICES = [
        ('renewal', 'تمدید نسخ دارویی'),
        ('consultation', 'مشاوره آنلاین'),
    ]
    user = models.ForeignKey(BaleUser, on_delete=models.CASCADE, related_name='visits')
    name = models.CharField(max_length=100)
    national_code = models.BigIntegerField()
    urgency = models.CharField(max_length=20, choices=URGENCY_CHOICES)
    description = models.TextField(blank=True, null=True)
    visit_state = models.CharField(
        max_length=20,
        default='initiated',
        choices=[('initiated', 'Initiated'), ('completed', 'Completed')]
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Visit {self.name} - {self.national_code} - {self.visit_state}"
