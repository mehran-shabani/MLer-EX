from django.contrib import admin
from .models import BaleUser, ChatSession, Transaction, BoxMoney, Visit

@admin.register(BaleUser)
class BaleUserAdmin(admin.ModelAdmin):
    list_display = (
        'phone_number', 
        'chat_id', 
        'is_authenticated', 
        'daily_message_limit', 
        'current_message_count', 
        'assistant_role', 
        'system_role', 
        'token_limit'
    )
    list_filter = ('is_authenticated', 'assistant_role', 'system_role')
    search_fields = ('phone_number', 'chat_id')
    readonly_fields = ('current_message_count',)
    fieldsets = (
        ('Basic Information', {'fields': ('phone_number', 'chat_id', 'is_authenticated')}),
        ('Settings', {'fields': ('daily_message_limit', 'current_message_count', 'token_limit', 'assistant_role', 'system_role')}),
    )
    list_per_page = 25

@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ('user', 'assistant_role', 'system_role', 'created_at')
    list_filter = ('assistant_role', 'system_role', 'created_at')
    search_fields = ('user__phone_number', 'assistant_role', 'system_role')
    readonly_fields = ('created_at',)
    fieldsets = (
        ('User Information', {'fields': ('user',)}),
        ('Chat Details', {'fields': ('user_message', 'bot_response', 'assistant_role', 'system_role', 'created_at')}),
    )
    list_per_page = 25

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('user', 'amount', 'status', 'trans_id', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('user__phone_number', 'trans_id')
    list_per_page = 25

@admin.register(Visit)
class VisitAdmin(admin.ModelAdmin):
    list_display = ('name', 'national_code', 'urgency', 'visit_state', 'created_at')
    list_filter = ('urgency', 'visit_state', 'created_at')
    search_fields = ('name', 'national_code', 'user__phone_number')
    list_per_page = 25
