from django.urls import path
from .views import bale_webhook_view, VerifyPredictionView

urlpatterns = [
    path('bale-webhook/', bale_webhook_view, name='bale_webhook'),
    path('verifyprediction/', VerifyPredictionView.as_view(), name='verifyprediction'),
]

