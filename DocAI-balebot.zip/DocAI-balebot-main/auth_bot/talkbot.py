import json
import requests
from django.conf import settings

def talk_to_bot(
    user_messages,
    assistant_messages=None,
    system_role_description=None,
    model="gpt-4o-mini",
    max_tokens=100,
    temperature=0.7,
    top_p=1.0,
    frequency_penalty=0.0,
    presence_penalty=0.0
):
    """
    این تابع جهت ارتباط با API مدل زبانی استفاده می‌شود.
    شما می‌توانید بسته به نیاز خود، آن را با یک سرویس واقعی جایگزین کنید.
    """
    messages = []
    if system_role_description:
        messages.append({"role": "system", "content": system_role_description})
    if user_messages and assistant_messages:
        for u_msg, a_msg in zip(user_messages, assistant_messages):
            messages.append(u_msg)
            messages.append(a_msg)
        if len(user_messages) > len(assistant_messages):
            messages.append(user_messages[-1])
    elif user_messages:
        for um in user_messages:
            messages.append(um)
    
    payload = {
        "model": model,
        "messages": messages,
        "max-token": max_tokens,
        "temperature": temperature,
        "stream": False,
        "top_p": top_p,
        "frequency_penalty": frequency_penalty,
        "presence_penalty": presence_penalty
    }
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {settings.TALKBOT_API_KEY}'
    }
    url = "https://api.example.com/talk_to_bot"
    try:
        response = requests.post(url, data=json.dumps(payload), headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}
