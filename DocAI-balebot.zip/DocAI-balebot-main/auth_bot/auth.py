import random
from django.conf import settings
from kavenegar import KavenegarAPI, APIException, HTTPException
from .models import BaleUser
from .utils import send_message_to_bale

# در اینجا از دیکشنری درون‌حافظه‌ای برای مدیریت مراحل لاگین استفاده می‌کنیم:
LOGIN_STATE = {}

def handle_login_command(chat_id):
    """
    دستور /login اجرا شده، از کاربر می‌خواهیم شماره موبایل را وارد کند.
    """
    LOGIN_STATE[chat_id] = {'step': 'ask_phone'}
    send_message_to_bale(chat_id, "لطفاً شماره موبایل خود را وارد کنید (مثلاً: 09123456789).")

def process_login_steps(chat_id, text):
    """
    این تابع متن (text) کاربر را دریافت کرده و بسته به قدم جاری در LOGIN_STATE عمل می‌کند.
    """
    if chat_id not in LOGIN_STATE:
        send_message_to_bale(chat_id, "ابتدا دستور /login را وارد کنید.")
        return

    state = LOGIN_STATE[chat_id]
    step = state['step']

    if step == 'ask_phone':
        # چک ابتدایی برای فرمت گوشی؛ شما می‌توانید هر اعتبارسنجی دلخواه اضافه کنید
        phone = text.strip()
        if len(phone) < 10 or len(phone) > 14:
            send_message_to_bale(chat_id, "شماره موبایل معتبر نیست. دوباره سعی کنید.")
            return
        state['phone_number'] = phone
        # ارسال OTP
        otp = str(random.randint(100000, 999999))
        try:
            user, _ = BaleUser.objects.get_or_create(chat_id=chat_id)
            user.phone_number = phone
            user.otp = otp
            user.is_authenticated = False
            user.save()

            api = KavenegarAPI(settings.KAVEH_NEGAR_API_KEY)
            params = {'receptor': phone, 'token': otp, 'template': 'users'}
            api.verify_lookup(params)

            state['step'] = 'ask_otp'
            send_message_to_bale(chat_id, "کد تأیید به شماره شما ارسال شد. لطفاً کد 6 رقمی را وارد کنید.")
        except (APIException, HTTPException) as e:
            send_message_to_bale(chat_id, "خطا در ارسال کد OTP. لطفاً مجدداً تلاش کنید.")
            print("Kavenegar error:", e)

    elif step == 'ask_otp':
        # بررسی صحت OTP
        try:
            user = BaleUser.objects.get(chat_id=chat_id)
            if text.strip() == user.otp:
                user.is_authenticated = True
                user.otp = ''
                user.save()

                send_message_to_bale(chat_id, "احراز هویت شما با موفقیت انجام شد!")
                LOGIN_STATE.pop(chat_id, None)  # مرحله لاگین تمام شود
            else:
                send_message_to_bale(chat_id, "کد واردشده نادرست است. دوباره تلاش کنید.")
        except BaleUser.DoesNotExist:
            send_message_to_bale(chat_id, "ابتدا دستور /login را وارد کنید.")

def handle_logout_command(chat_id):
    user = BaleUser.objects.filter(chat_id=chat_id).first()
    if user:
        user.is_authenticated = False
        user.save()
        send_message_to_bale(chat_id, "از سیستم خارج شدید.")
    else:
        send_message_to_bale(chat_id, "ابتدا /login را بزنید؛ کاربری ثبت‌نام نشده است.")
