# auth_bot/test/test_auth.py

from django.test import TestCase
from rest_framework.test import APIClient
from django.urls import reverse
from unittest.mock import patch

from auth_bot.models import BaleUser
from auth_bot.auth import handle_login_command, handle_phone_number, handle_otp

class AuthTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        # اگر view webhook دارید:
        self.url = reverse("bale_webhook")

        # پچ کردن KavenegarAPI در فایل auth_bot.auth
        # به این ترتیب وقتی کد در auth.py از KavenegarAPI(...) استفاده می‌کند،
        # از نسخه Mock استفاده می‌شود و درخواست واقعی ارسال نمی‌گردد.
        patcher = patch("auth_bot.auth.KavenegarAPI")
        self.mock_kavenegar_class = patcher.start()
        self.addCleanup(patcher.stop)

        # می‌توانیم نمونه بازگشتی این کلاس را هم بسازیم
        self.mock_kavenegar_instance = self.mock_kavenegar_class.return_value

        # همچنین verify_lookup را هم Mock می‌کنیم
        self.mock_kavenegar_instance.verify_lookup.return_value = True

    def test_handle_login_command(self):
        """کاربر دستور /login را ارسال می‌کند و ما انتظار داریم پیام درخواست شماره موبایل برگردد."""
        # سناریو ساده: فرضاً ما با فراخوانی مستقیم تابع handle_login_command تست می‌کنیم
        chat_id = "123"
        handle_login_command(chat_id)
        user = BaleUser.objects.get(chat_id=chat_id)
        self.assertFalse(user.is_authenticated)

    def test_handle_phone_number(self):
        """وارد کردن شماره موبایل و تست OTP، بدون ارسال واقعی به کاونگار."""
        chat_id = "222"
        BaleUser.objects.create(chat_id=chat_id, is_authenticated=False)

        phone_number = "09123456789"
        handle_phone_number(chat_id, phone_number)
        user = BaleUser.objects.get(chat_id=chat_id)
        
        self.assertEqual(user.phone_number, phone_number)
        self.assertFalse(user.is_authenticated)
        self.assertTrue(len(user.otp) == 6)

        # بررسی این‌که تابع verify_lookup فراخوانی شده است
        self.mock_kavenegar_instance.verify_lookup.assert_called_once()
        # مثلاً انتظار داریم پارامتر رسپتور و توکن داخل این فراخوانی باشد
        # در صورت نیاز می‌توانید جزئیات بیشتر را با assert_called_with چک کنید
        # self.mock_kavenegar_instance.verify_lookup.assert_called_with(
        #     {'receptor': phone_number, 'token': user.otp, 'template': 'users'}
        # )

    def test_handle_otp_correct(self):
        """احراز هویت موفق با کد درست."""
        chat_id = "333"
        user = BaleUser.objects.create(
            chat_id=chat_id,
            phone_number="0912000",
            otp="123456",
            is_authenticated=False
        )
        handle_otp(chat_id, "123456")
        user.refresh_from_db()
        self.assertTrue(user.is_authenticated)
        self.assertEqual(user.otp, "")

    def test_handle_otp_incorrect(self):
        """احراز هویت ناموفق با کد اشتباه."""
        chat_id = "444"
        BaleUser.objects.create(
            chat_id=chat_id,
            phone_number="0912000",
            otp="999999",
            is_authenticated=False
        )
        handle_otp(chat_id, "000000")  # کد اشتباه
        user = BaleUser.objects.get(chat_id=chat_id)
        self.assertFalse(user.is_authenticated)
        self.assertEqual(user.otp, "999999")

    def test_handle_logout_command(self):
        """خروج کاربر از سیستم."""
        from auth_bot.auth import handle_logout_command

        chat_id = "555"
        BaleUser.objects.create(chat_id=chat_id, is_authenticated=True)
        handle_logout_command(chat_id)
        user = BaleUser.objects.get(chat_id=chat_id)
        self.assertFalse(user.is_authenticated)

    # اگر تست‌های مرتبط با views/bale_webhook دارید:
    # def test_webhook_phone_number(self):
    #     ...

