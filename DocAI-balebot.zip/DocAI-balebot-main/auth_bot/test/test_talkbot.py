import json
from unittest.mock import patch
from django.test import TestCase
from requests.exceptions import RequestException
from auth_bot.talkbot import talk_to_bot


class TalkbotTests(TestCase):
    @patch("auth_bot.talkbot.requests.post")
    def test_talk_to_bot_success(self, mock_post):
        # Mock a successful response
        mock_post.return_value.ok = True
        mock_post.return_value.json.return_value = {
            "choices": [
                {
                    "message": {"role": "assistant", "content": "Test response"}
                }
            ]
        }

        response = talk_to_bot(
            user_messages=[{"role": "user", "content": "Hello"}],
            assistant_messages=None,
            system_role_description="System prompt here",
            model="gpt-4o-mini"
        )
        self.assertIn("choices", response)
        self.assertTrue(mock_post.called)

    @patch("auth_bot.talkbot.requests.post")
    def test_talk_to_bot_error(self, mock_post):
        # Mock an error response
        mock_post.return_value.ok = False
        mock_post.return_value.status_code = 400
        mock_post.return_value.text = "Bad request"
        mock_post.return_value.json.return_value = {"error": "Bad request"}

        response = talk_to_bot(
            user_messages=[{"role": "user", "content": "Hello"}]
        )
        self.assertIn("error", response)
        self.assertIn("Bad request", response["error"])
        self.assertTrue(mock_post.called)

    @patch("auth_bot.talkbot.requests.post")
    def test_talk_to_bot_request_exception(self, mock_post):
        # در اینجا به جای Exception عمومی از RequestException استفاده می‌کنیم
        mock_post.side_effect = RequestException("Connection error")

        response = talk_to_bot(
            user_messages=[{"role": "user", "content": "Hello"}]
        )
        self.assertIn("error", response)
        self.assertIn("Connection error", response["error"])
        self.assertTrue(mock_post.called)
