from django.test import TestCase
from rest_framework.test import APIClient
from django.urls import reverse
from auth_bot.models import BaleUser, ChatSession
from unittest.mock import patch

class ViewsTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.url = reverse("bale_webhook")

        # --- پچ کردن Kavenegar ---
        # به این ترتیب وقتی در auth.py از KavenegarAPI(...) استفاده شود، نسخه Mock برمی‌گردد
        patcher = patch("auth_bot.auth.KavenegarAPI")
        self.mock_kavenegar_class = patcher.start()
        self.addCleanup(patcher.stop)

        # نمونهٔ mock از KavenegarAPI
        self.mock_kavenegar_instance = self.mock_kavenegar_class.return_value
        # مثلاً می‌گوییم verify_lookup همیشه موفق باشد
        self.mock_kavenegar_instance.verify_lookup.return_value = True

    def test_start_command(self):
        data = {
            "message": {
                "chat": {"id": "111"},
                "text": "/start"
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)

    def test_login_command(self):
        data = {
            "message": {
                "chat": {"id": "111"},
                "text": "/login"
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)
        user = BaleUser.objects.get(chat_id="111")
        self.assertFalse(user.is_authenticated)

    def test_phone_number_input(self):
        # ایجاد کاربر غیراهلک
        BaleUser.objects.create(chat_id="222", is_authenticated=False)
        data = {
            "message": {
                "chat": {"id": "222"},
                "text": "09123456789"
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)
        user = BaleUser.objects.get(chat_id="222")
        self.assertEqual(user.phone_number, "09123456789")
        # آیا OTP ساخته شده؟
        self.assertTrue(len(user.otp) == 6)

        # بررسی این‌که واقعاً متد verify_lookup از طریق Mock صدا شده
        self.mock_kavenegar_instance.verify_lookup.assert_called_once()

    def test_otp_input(self):
        BaleUser.objects.create(
            chat_id="333",
            phone_number="0912000",
            otp="123456",
            is_authenticated=False
        )
        data = {
            "message": {
                "chat": {"id": "333"},
                "text": "123456"  # کد درست
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)
        user = BaleUser.objects.get(chat_id="333")
        self.assertTrue(user.is_authenticated)
        self.assertEqual(user.otp, "")

    def test_logout_command(self):
        BaleUser.objects.create(chat_id="444", is_authenticated=True)
        data = {
            "message": {
                "chat": {"id": "444"},
                "text": "/logout"
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)
        user = BaleUser.objects.get(chat_id="444")
        self.assertFalse(user.is_authenticated)

    def test_startchat_without_auth(self):
        BaleUser.objects.create(chat_id="555", is_authenticated=False)
        data = {
            "message": {
                "chat": {"id": "555"},
                "text": "/startchat"
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 400)

    def test_startchat_with_auth(self):
        BaleUser.objects.create(chat_id="666", is_authenticated=True)
        data = {
            "message": {
                "chat": {"id": "666"},
                "text": "/startchat"
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)

    def test_role_selection_invalid(self):
        BaleUser.objects.create(chat_id="777", is_authenticated=True)
        data = {
            "message": {
                "chat": {"id": "777"},
                "text": "999"  # role index نامعتبر
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)

    def test_role_selection_and_confirmation(self):
        user = BaleUser.objects.create(chat_id="888", is_authenticated=True)
        data = {
            "message": {
                "chat": {"id": "888"},
                "text": "1"
            }
        }
        resp = self.client.post(self.url, data, format="json")
        self.assertEqual(resp.status_code, 200)
        user.refresh_from_db()
        self.assertTrue(user.assistant_role)

        data_confirm = {
            "message": {
                "chat": {"id": "888"},
                "text": "1"
            }
        }
        resp2 = self.client.post(self.url, data_confirm, format="json")
        self.assertEqual(resp2.status_code, 200)

    def test_chat_message_flow(self):
        user = BaleUser.objects.create(
            chat_id="999",
            phone_number="0912xxx",
            is_authenticated=True,
            assistant_role="psychologist",
            system_role="therapeutic"
        )
        data = {
            "message": {
                "chat": {"id": "999"},
                "text": "Hello doctor."
            }
        }
        # ممکن است نیاز باشد تعداد کوئری را به 8 یا عددی دیگر تغییر دهید
        with self.assertNumQueries(8):
            response = self.client.post(self.url, data, format="json")

        self.assertEqual(response.status_code, 200)
        session = ChatSession.objects.filter(user=user, is_active=True).first()
        self.assertIsNotNone(session)
        self.assertIn("Hello doctor.", session.user_message)

    def test_end_chat(self):
        user = BaleUser.objects.create(
            chat_id="1010",
            phone_number="09xxx",
            is_authenticated=True
        )
        ChatSession.objects.create(user=user, is_active=True)
        data = {
            "message": {
                "chat": {"id": "1010"},
                "text": "#"
            }
        }
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)
        session = ChatSession.objects.filter(user=user).first()
        self.assertFalse(session.is_active)

    def test_no_message_key(self):
        data = {}
        response = self.client.post(self.url, data, format="json")
        self.assertEqual(response.status_code, 200)
