from rest_framework import serializers
from .models import BaleUser, Visit, Transaction, BoxMoney

class MinimalVisitSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(read_only=True)
    
    class Meta:
        model = Visit
        fields = ['id', 'national_code', 'name', 'urgency', 'description', 'visit_state', 'created_at']
        read_only_fields = ['id', 'visit_state', 'created_at']
    
    def validate_national_code(self, value):
        val_str = str(value)
        if len(val_str) != 10 or not val_str.isdigit():
            raise serializers.ValidationError("کد ملی باید دقیقاً 10 رقمی باشد.")
        return value
    
    def create(self, validated_data):
        request = self.context.get('request')
        validated_data['user'] = request.user
        return super().create(validated_data)
