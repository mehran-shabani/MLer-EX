from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from .models import Transaction, Visit

@receiver(post_save, sender=Transaction)
def send_transaction_email(sender, instance, created, **kwargs):
    if not created and instance.status == 'successful':
        # آخرین ویزیت کاربر را پیدا می‌کنیم
        visit = Visit.objects.filter(user=instance.user).order_by('-created_at').first()
        if visit:
            html_content = render_to_string('visit_email.html', {'visit': visit})
            email = EmailMessage(
                subject=f"ویزیت و پرداخت موفق: {visit.name}",
                body=html_content,
                from_email='info@medogram.ir',
                to=['shabanimehran@gmail.com'],
            )
            email.content_subtype = "html"
            email.send()
