import json
import requests
from django.conf import settings
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from .models import BaleUser, ChatSession, Transaction, Visit
from .talkbot import talk_to_bot
from .utils import send_message_to_bale
from .auth import (
    handle_login_command,
    handle_logout_command,
    process_login_steps,
)

from .serializers import MinimalVisitSerializer
from django.db import transaction

FIXED_AMOUNT = 289000

# ---------------------------
# متغیرهای سراسری در حافظه
# ---------------------------
LOGIN_STATE = {}   # در auth.py هم تعریف شده، صرفاً برای دسترسی سراسری
CHAT_STATE = {}    # برای مدیریت چت /startchat
VISIT_STATE = {}   # برای مدیریت ویزیت مرحله‌ای

# در VISIT_STATE[chat_id] ساختاری مشابه زیر نگه خواهیم داشت:
# {
#   'steps': ['ask_name', 'ask_national', 'ask_type', 'ask_meds_or_symptoms', 'confirm'],
#   'current_step': 0,
#   'data': {
#       'name': '',
#       'national_code': '',
#       'type': '',  # renewal | consultation
#       'meds': '',
#       'symptoms': ''
#   }
# }

@api_view(['POST'])
@permission_classes([AllowAny])
def bale_webhook_view(request):
    """
    تنها وبهوک ربات Bale:
    - بررسی دستورات (/start, /login, /logout, /startchat, /visit, #, *)
    - کنترل مراحل لاگین
    - کنترل مراحل ویزیت
    - کنترل چت آزاد با هوش مصنوعی
    """
    update_json = request.data
    if "message" not in update_json:
        return Response(status=200)
    
    message = update_json["message"]
    chat_id = str(message["chat"]["id"])
    text = message.get("text", "").strip()

    # بررسی دستورات سطح اول
    if text.lower() == "/start":
        return handle_start_command(chat_id)

    elif text.lower() == "/login":
        handle_login_command(chat_id)
        return Response(status=200)

    elif text.lower() == "/logout":
        handle_logout_command(chat_id)
        return Response(status=200)

    elif text.lower() == "/startchat":
        # تنها در صورت احراز هویت
        user = BaleUser.objects.filter(chat_id=chat_id).first()
        if not user or not user.is_authenticated:
            send_message_to_bale(chat_id, "ابتدا باید لاگین کنید (/login).")
            return Response(status=200)
        return start_chat(chat_id, user)

    elif text.lower() == "/visit":
        # تنها در صورت احراز هویت
        user = BaleUser.objects.filter(chat_id=chat_id).first()
        if not user or not user.is_authenticated:
            send_message_to_bale(chat_id, "ابتدا باید لاگین کنید (/login).")
            return Response(status=200)
        return start_visit(chat_id, user)

    elif text == "#":
        # پایان چت آزاد با هوش مصنوعی (در صورت وجود)
        return end_chat(chat_id)

    elif text == "*":
        # بازگشت به مرحله قبلی در ویزیت (در صورت فعال بودن ویزیت)
        return go_back_visit_step(chat_id)

    else:
        # اگر در مرحله لاگین هستیم
        if chat_id in LOGIN_STATE:
            process_login_steps(chat_id, text)
            return Response(status=200)
        
        # اگر در مرحله ویزیت هستیم
        if chat_id in VISIT_STATE:
            return process_visit_step(chat_id, text)
        
        # اگر در مرحله چت آزاد هستیم
        if chat_id in CHAT_STATE and CHAT_STATE[chat_id].get('active'):
            return process_chat_message(chat_id, text)

        # در غیر اینصورت
        send_message_to_bale(chat_id, "دستور ناشناس یا غیرمعتبر.")
        return Response(status=200)

def handle_start_command(chat_id):
    """
    پاسخ اولیه به دستور /start
    """
    welcome_message = (
        "سلام! به ربات خوش آمدید.\n"
        "دستورات موجود:\n"
        "1. /login (لاگین با شماره موبایل و OTP)\n"
        "2. /logout (خروج)\n"
        "3. /startchat (چت با هوش مصنوعی) [فقط کاربران لاگین]\n"
        "4. /visit (شروع روند ویزیت) [فقط کاربران لاگین]\n"
        "5. # (پایان چت در صورت چت فعال)\n"
        "6. * (بازگشت به مرحله قبل در روند ویزیت)\n"
    )
    send_message_to_bale(chat_id, welcome_message)
    return Response(status=200)

# ---------------------------
# چت آزاد با هوش مصنوعی
# ---------------------------
def start_chat(chat_id, user):
    """
    دستور /startchat:
    """
    if chat_id not in CHAT_STATE:
        CHAT_STATE[chat_id] = {'active': True, 'history': []}
    else:
        CHAT_STATE[chat_id]['active'] = True
        CHAT_STATE[chat_id]['history'] = []
    send_message_to_bale(chat_id, "چت با هوش مصنوعی آغاز شد. برای پایان، دستور # را بفرستید.")
    return Response(status=200)

def process_chat_message(chat_id, text):
    """
    پردازش پیام کاربر در چت آزاد
    """
    user = BaleUser.objects.filter(chat_id=chat_id).first()
    if not user:
        send_message_to_bale(chat_id, "ابتدا لاگین کنید.")
        return Response(status=200)
    
    # اینجا می‌توانید لاگ یا محدودیت روزانه را هم اعمال کنید
    user.increment_message_count()

    # سابقه (history) را برای مدل GPT آماده می‌کنیم
    # ساختار لازم: لیستی از دیکشنری با role=user/assistant, content="..."
    conversation = CHAT_STATE[chat_id]['history']
    conversation.append({"role": "user", "content": text})

    # فراخوانی API
    bot_resp = talk_to_bot(
        user_messages=conversation,
        system_role_description=user.get_assistant_description(),
        model="gpt-4o-mini",
        max_tokens=user.token_limit,
        temperature=0.7
    )
    if "error" in bot_resp:
        send_message_to_bale(chat_id, f"خطا در پاسخ هوش مصنوعی: {bot_resp['error']}")
    else:
        reply_text = bot_resp.get("choices", [{}])[0].get("message", {}).get("content", "پاسخی دریافت نشد.")
        send_message_to_bale(chat_id, reply_text)
        conversation.append({"role": "assistant", "content": reply_text})

    return Response(status=200)

def end_chat(chat_id):
    """
    پایان چت آزاد
    """
    if chat_id in CHAT_STATE:
        CHAT_STATE[chat_id]['active'] = False
        send_message_to_bale(chat_id, "چت پایان یافت. هر زمان تمایل داشتید /startchat را بزنید.")
    else:
        send_message_to_bale(chat_id, "شما در حال حاضر چتی فعال ندارید.")
    return Response(status=200)

# ---------------------------
# روند ویزیت
# ---------------------------
def start_visit(chat_id, user):
    """
    با دستور /visit شروع می‌شود.
    """
    # فیلدهای مورد نیاز ویزیت
    steps = ['ask_name', 'ask_national', 'ask_type', 'ask_meds_or_symptoms']
    VISIT_STATE[chat_id] = {
        'steps': steps,
        'current_step': 0,
        'data': {}
    }
    send_message_to_bale(chat_id, "لطفاً نام و نام خانوادگی خود را وارد کنید.")
    return Response(status=200)

def go_back_visit_step(chat_id):
    """
    با ارسال * کاربر می‌تواند یک مرحله به عقب برگردد.
    """
    if chat_id not in VISIT_STATE:
        send_message_to_bale(chat_id, "در حال حاضر در روند ویزیت نیستید.")
        return Response(status=200)
    state = VISIT_STATE[chat_id]
    if state['current_step'] == 0:
        send_message_to_bale(chat_id, "هم‌اکنون در اولین مرحله هستید و امکان بازگشت وجود ندارد.")
        return Response(status=200)
    state['current_step'] -= 1
    step_name = state['steps'][state['current_step']]
    # تکرار مجدد سوال آن مرحله
    if step_name == 'ask_name':
        send_message_to_bale(chat_id, "لطفاً نام و نام خانوادگی خود را وارد کنید.")
    elif step_name == 'ask_national':
        send_message_to_bale(chat_id, "لطفاً کد ملی خود را وارد کنید (دقیقاً 10 رقم).")
    elif step_name == 'ask_type':
        send_message_to_bale(chat_id, "نوع ویزیت: \n1: تمدید نسخه دارویی\n2: مشاوره آنلاین")
    elif step_name == 'ask_meds_or_symptoms':
        # با توجه به نوع قبلاً ثبت‌شده، مشخص می‌کنیم
        vtype = state['data'].get('type', '')
        if vtype == 'renewal':
            send_message_to_bale(chat_id, "نام داروهای موردنظر را وارد کنید (به صورت یک رشته).")
        elif vtype == 'consultation':
            send_message_to_bale(chat_id, "علائم عمومی خود را وارد کنید (حداکثر 300 کاراکتر).")
    return Response(status=200)

def process_visit_step(chat_id, text):
    """
    بر اساس current_step مقداردهی‌ها انجام می‌شود
    """
    state = VISIT_STATE[chat_id]
    step_name = state['steps'][state['current_step']]
    data = state['data']

    if step_name == 'ask_name':
        full_name = text.strip()
        if not full_name:
            send_message_to_bale(chat_id, "نام و نام خانوادگی نمیتواند خالی باشد.")
            return Response(status=200)
        data['name'] = full_name
        # مرحله بعد
        state['current_step'] += 1
        send_message_to_bale(chat_id, "لطفاً کد ملی خود را وارد کنید (دقیقاً 10 رقم).")

    elif step_name == 'ask_national':
        if len(text) != 10 or not text.isdigit():
            send_message_to_bale(chat_id, "کد ملی باید 10 رقمی باشد.")
            return Response(status=200)
        data['national_code'] = text
        state['current_step'] += 1
        send_message_to_bale(chat_id, "نوع ویزیت را مشخص کنید:\n1: تمدید نسخه دارویی\n2: مشاوره آنلاین")

    elif step_name == 'ask_type':
        if text not in ['1', '2']:
            send_message_to_bale(chat_id, "گزینه نامعتبر. 1 یا 2 را وارد کنید.")
            return Response(status=200)
        if text == '1':
            data['type'] = 'renewal'
            state['current_step'] += 1
            send_message_to_bale(chat_id, "نام داروهای موردنظر را وارد کنید (به صورت یک رشته).")
        else:
            data['type'] = 'consultation'
            state['current_step'] += 1
            send_message_to_bale(chat_id, "علائم عمومی خود را وارد کنید (حداکثر 300 کاراکتر).")

    elif step_name == 'ask_meds_or_symptoms':
        vtype = data['type']
        if vtype == 'renewal':
            # تماس با talkbot برای اصلاح نام دارو
            bot_resp = talk_to_bot(
                user_messages=[{"role": "user", "content": f"Please return the standardized generic names for these medications: {text}"}],
                system_role_description="You are a medical transcription assistant. Return corrected medication names.",
                model="gpt-4o-mini",
                max_tokens=150,
                temperature=0.3
            )
            if "error" in bot_resp:
                send_message_to_bale(chat_id, f"خطا در پردازش نام داروها: {bot_resp['error']}")
                return Response(status=200)
            corrected = bot_resp.get("choices", [{}])[0].get("message", {}).get("content", "")
            if not corrected:
                corrected = text  # در صورت بروز خطا، متن خام را استفاده میکنیم
            if len(corrected) > 300:
                corrected = corrected[:300]
            data['info'] = corrected
        else:
            # consultation
            if len(text) > 300:
                send_message_to_bale(chat_id, "متن وارد شده بیش از 300 کاراکتر است.")
                return Response(status=200)
            data['info'] = text
        
        # حالا ویزیت را ثبت می‌کنیم
        response = complete_visit(chat_id)
        return response
    
    return Response(status=200)

def complete_visit(chat_id):
    """
    وقتی آخرین مرحله وارد شد، ویزیت ثبت و پرداخت آغاز می‌شود
    """
    state = VISIT_STATE[chat_id]
    data = state['data']
    user = BaleUser.objects.get(chat_id=chat_id)

    visit_data = {
        'name': data['name'],
        'national_code': data['national_code'],
        'urgency': data['type'],
        'description': data['info']
    }
    serializer = MinimalVisitSerializer(data=visit_data, context={"request": DummyRequest(user)})
    if not serializer.is_valid():
        send_message_to_bale(chat_id, "خطا در ثبت ویزیت: " + json.dumps(serializer.errors))
        return Response(status=200)
    
    with transaction.atomic():
        visit = serializer.save()
        visit.visit_state = "completed"
        visit.save()
    
    # شروع پرداخت
    return initiate_payment(chat_id, user)

def initiate_payment(chat_id, bale_user):
    payment_data = {
        'api': settings.BITPAY_API_KEY,
        'amount': FIXED_AMOUNT,
        'redirect': 'https://medogram.ir/baletranscription/',
    }
    pay_resp = requests.post('https://bitpay.ir/payment/gateway-send', data=payment_data)
    id_get = pay_resp.text

    if id_get.isdigit() and int(id_get) > 0:
        Transaction.objects.create(
            user=bale_user,
            amount=FIXED_AMOUNT,
            card_num=id_get
        )
        payment_url = f"https://bitpay.ir/payment/gateway-{id_get}-get"
        send_message_to_bale(
            chat_id,
            f"ویزیت شما ثبت شد.\nجهت پرداخت مبلغ {FIXED_AMOUNT} تومان روی لینک زیر کلیک کنید:\n{payment_url}"
        )
        del VISIT_STATE[chat_id]  # پاک کردن وضعیت ویزیت
        return Response({'message': 'ویزیت ثبت شد و پرداخت آغاز گردید.'}, status=200)
    else:
        send_message_to_bale(chat_id, "خطا در ایجاد تراکنش پرداخت. لطفاً مجدداً تلاش کنید.")
        return Response(status=200)

class DummyRequest:
    def __init__(self, user):
        self.user = user

# ---------------------------
# تأیید پرداخت
# ---------------------------
from rest_framework.views import APIView

class VerifyPredictionView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        trans_id = request.data.get('trans_id')
        id_get = request.data.get('id_get')
        if not trans_id or not id_get:
            return Response({'error': 'trans_id or id_get missing'}, status=400)
        verify_data = {
            'api': settings.BITPAY_API_KEY,
            'trans_id': trans_id,
            'id_get': id_get,
            'json': 1
        }
        response = requests.post('https://bitpay.ir/payment/gateway-result-second', data=verify_data)
        try:
            result = response.json()
        except Exception:
            return Response({'error': 'Invalid JSON from payment gateway'}, status=400)
        
        if result.get('status') == 1:
            trans_obj = Transaction.objects.get(card_num=id_get)
            trans_obj.status = 'successful'
            trans_obj.factor_id = trans_id
            trans_obj.save()
            send_message_to_bale(str(trans_obj.user.chat_id), "پرداخت شما با موفقیت انجام شد.")
            return Response({'message': 'Payment verified successfully.'}, status=200)
        elif result.get('status') == 11:
            return Response({'message': 'Transaction verified in the past.'}, status=200)
        else:
            return Response({
                'error': 'Payment verification failed. با پشتیبانی تماس بگیرید: tel:09961733668'
            }, status=400)
