# Telemedicine Platform

This directory contains a skeleton Django project. The environment requires PostgreSQL and Redis. Activate the virtual environment with `source venv/bin/activate`.
