from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=255)
    dob = models.DateField()
    phone = models.CharField(max_length=20)


class SymptomAssessment(models.Model):
    patient = models.ForeignKey(Patient, related_name='assessments', on_delete=models.CASCADE)
    symptoms = models.TextField()
    severity_score = models.IntegerField(default=0)
    urgency_level = models.CharField(max_length=50)


class DoctorMatch(models.Model):
    patient = models.ForeignKey(Patient, related_name='matches', on_delete=models.CASCADE)
    doctor_id = models.IntegerField()
    score = models.FloatField(default=0.0)


class PatientHistory(models.Model):
    patient = models.ForeignKey(Patient, related_name='history', on_delete=models.CASCADE)
    notes = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)


class Appointment(models.Model):
    patient = models.ForeignKey(Patient, related_name='appointments', on_delete=models.CASCADE)
    doctor_id = models.IntegerField()
    scheduled_for = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
