from rest_framework import routers
from .views import (
    PatientViewSet,
    SymptomAssessmentViewSet,
    DoctorMatchViewSet,
    AppointmentViewSet,
)

router = routers.DefaultRouter()
router.register(r'patients', PatientViewSet)
router.register(r'assessments', SymptomAssessmentViewSet)
router.register(r'matches', DoctorMatchViewSet)
router.register(r'appointments', AppointmentViewSet)

urlpatterns = router.urls
