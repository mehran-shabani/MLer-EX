class DoctorMatchingService:
    """Calculate doctor match score based on weighted factors."""

    WEIGHTS = {
        "specialty": 0.35,
        "availability": 0.25,
        "location": 0.15,
        "reviews": 0.10,
        "experience": 0.08,
        "cost": 0.04,
        "language": 0.02,
        "history": 0.01,
    }

    def score_doctor(self, factors: dict) -> float:
        """Return the final score after weighting all factors."""
        score = 0.0
        for key, weight in self.WEIGHTS.items():
            score += weight * factors.get(key, 0)
        return score

    # Step 2.4: Smart Scoring System helpers
    def specialty_match_score(self, patient_symptoms: list, doctor_specialties: list) -> float:
        """Calculate how well the doctor's specialties match the patient's symptoms."""
        if not patient_symptoms or not doctor_specialties:
            return 0.0
        matches = len(set(patient_symptoms) & set(doctor_specialties))
        return min(matches / len(patient_symptoms), 1.0)

    def availability_score(self, is_available: bool) -> float:
        """Return 1.0 if available else 0.0."""
        return 1.0 if is_available else 0.0

    def location_score(self, patient_location: tuple, doctor_location: tuple) -> float:
        """Simple geographic distance scoring between 0 and 1."""
        if not patient_location or not doctor_location:
            return 0.0
        # very naive distance scoring
        distance = ((patient_location[0] - doctor_location[0]) ** 2 + (patient_location[1] - doctor_location[1]) ** 2) ** 0.5
        return max(0.0, 1.0 - (distance / 100))

    def reviews_score(self, rating: float) -> float:
        """Normalize review ratings out of 5 to a 0-1 range."""
        return max(0.0, min(rating / 5.0, 1.0))

    def experience_score(self, years: int) -> float:
        """Return a normalized experience score."""
        return min(years / 30, 1.0)

    def cost_score(self, cost_ok: bool) -> float:
        """Return 1.0 if cost is within patient budget."""
        return 1.0 if cost_ok else 0.0

    def language_score(self, language_match: bool) -> float:
        return 1.0 if language_match else 0.0

    def history_score(self, prior_match: bool) -> float:
        return 1.0 if prior_match else 0.0

    def calculate_factors(self, patient_info: dict, doctor_info: dict) -> dict:
        """Combine helper calculations to generate factor scores."""
        return {
            "specialty": self.specialty_match_score(patient_info.get("symptoms", []), doctor_info.get("specialties", [])),
            "availability": self.availability_score(doctor_info.get("available", False)),
            "location": self.location_score(patient_info.get("location"), doctor_info.get("location")),
            "reviews": self.reviews_score(doctor_info.get("rating", 0)),
            "experience": self.experience_score(doctor_info.get("years_experience", 0)),
            "cost": self.cost_score(doctor_info.get("cost_ok", False)),
            "language": self.language_score(doctor_info.get("language_match", False)),
            "history": self.history_score(doctor_info.get("prior_match", False)),
        }

    def match_doctor(self, patient_info: dict, doctor_info: dict) -> float:
        """High level API to get a weighted doctor score."""
        factors = self.calculate_factors(patient_info, doctor_info)
        return self.score_doctor(factors)

    # Step 2.5: Machine Learning Optimization placeholder
    def adjust_weights(self, feedback: float) -> None:
        """Dynamically tweak weights based on patient feedback score (0-1)."""
        for key in self.WEIGHTS:
            self.WEIGHTS[key] = max(0.0, min(self.WEIGHTS[key] * (1 + (feedback - 0.5) / 10), 1.0))

