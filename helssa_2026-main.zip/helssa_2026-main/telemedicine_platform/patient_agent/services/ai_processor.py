class TalkBotService:
    """Analyze patient symptoms using a placeholder algorithm."""

    def analyze_symptoms(self, text: str) -> dict:
        """Return symptom severity, urgency, and extracted keywords."""
        if not text:
            return {"severity": 0, "urgency": "low", "keywords": []}

        severity = min(len(text) // 50, 10)
        urgency = "high" if severity > 5 else "medium"
        keywords = [word.lower() for word in text.split()[:5]]
        return {"severity": severity, "urgency": urgency, "keywords": keywords}
