from rest_framework import viewsets
from .models import Patient, SymptomAssessment, DoctorMatch, Appointment
from rest_framework import serializers

class PatientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Patient
        fields = '__all__'

class SymptomAssessmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = SymptomAssessment
        fields = '__all__'

class DoctorMatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = DoctorMatch
        fields = '__all__'

class AppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = '__all__'

class PatientViewSet(viewsets.ModelViewSet):
    queryset = Patient.objects.all()
    serializer_class = PatientSerializer

class SymptomAssessmentViewSet(viewsets.ModelViewSet):
    queryset = SymptomAssessment.objects.all()
    serializer_class = SymptomAssessmentSerializer

class DoctorMatchViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = DoctorMatch.objects.all()
    serializer_class = DoctorMatchSerializer

class AppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.all()
    serializer_class = AppointmentSerializer
