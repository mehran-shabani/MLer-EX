class KavenegarService:
    """Simplified Kavenegar SMS sending service."""

    def send_sms(self, to_number: str, message: str) -> bool:
        """Pretend to send an SMS and return success."""
        if not to_number or not message:
            return False
        # In real implementation we'd call Kavenegar API here
        print(f"SMS to {to_number}: {message}")
        return True
