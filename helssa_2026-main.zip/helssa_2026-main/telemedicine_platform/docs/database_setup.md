# Database Setup

Install PostgreSQL and Redis on your system.
Create a database named `telemedicine_db` and a user with necessary privileges.
Configure Redis to run on its default port.
