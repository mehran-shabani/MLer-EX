from django.urls import path, include

urlpatterns = [
    path('api/', include('patient_agent.urls')),
    path('api/', include('doctor_agent.urls')),
]
