class ClinicalDecisionService:
    """Provide basic clinical decision support."""

    def differential_diagnoses(self, symptoms: str) -> list:
        if not symptoms:
            return []
        words = {w.strip(',.').lower() for w in symptoms.split()}
        return list(words)[:5]

    def suggest_tests(self, keywords: list) -> list:
        if not keywords:
            return []
        return [f"{kw}_test" for kw in keywords]

    def treatment_protocol(self, condition: str) -> str:
        return f"Standard protocol for {condition}"

    def check_interactions(self, drugs: list) -> bool:
        return len(drugs) != len(set(drugs))
