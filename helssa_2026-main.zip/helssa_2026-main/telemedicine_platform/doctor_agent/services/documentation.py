class SmartDocumentationService:
    """Generate visit documentation and templates."""

    def generate_visit_note(self, patient: dict) -> str:
        return f"Visit note for {patient.get('name')}"

    def prescription_template(self, meds: list) -> str:
        return '\n'.join(meds)

    def referral_letter(self, patient: str, specialist: str) -> str:
        return f"Referral for {patient} to {specialist}"

    def follow_up_instructions(self, condition: str) -> str:
        return f"Follow up in 1 week for {condition}"
