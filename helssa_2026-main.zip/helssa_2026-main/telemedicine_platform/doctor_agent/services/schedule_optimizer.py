class ScheduleOptimizer:
    """Optimize doctor schedules and handle conflicts."""

    def optimize_daily(self, appointments: list) -> list:
        return sorted(appointments, key=lambda a: a.get('time'))

    def resolve_conflicts(self, appointments: list) -> list:
        seen = set()
        resolved = []
        for appt in appointments:
            if appt.get('time') not in seen:
                resolved.append(appt)
                seen.add(appt.get('time'))
        return resolved

    def predict_duration(self, symptoms: str) -> int:
        return min(len(symptoms) // 20 + 15, 60)

    def allocate_emergency_slot(self, appointments: list) -> list:
        if not any(a.get('emergency') for a in appointments):
            appointments.append({'time': '17:00', 'emergency': True})
        return appointments
