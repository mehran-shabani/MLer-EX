from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Doctor',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255)),
                ('specialty', models.CharField(max_length=100)),
                ('location', models.CharField(max_length=100)),
                ('years_experience', models.IntegerField(default=0)),
                ('rating', models.FloatField(default=0.0)),
            ],
        ),
        migrations.CreateModel(
            name='DoctorSchedule',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('start_time', models.DateTimeField()),
                ('end_time', models.DateTimeField()),
                ('doctor', models.ForeignKey(on_delete=models.CASCADE, related_name='schedules', to='doctor_agent.doctor')),
            ],
        ),
        migrations.CreateModel(
            name='ClinicalDecisionSupport',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('data', models.TextField()),
                ('doctor', models.ForeignKey(on_delete=models.CASCADE, related_name='cds_entries', to='doctor_agent.doctor')),
            ],
        ),
        migrations.CreateModel(
            name='PerformanceMetrics',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('patient_satisfaction', models.FloatField(default=0.0)),
                ('successful_diagnoses', models.IntegerField(default=0)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('doctor', models.ForeignKey(on_delete=models.CASCADE, related_name='metrics', to='doctor_agent.doctor')),
            ],
        ),
    ]
