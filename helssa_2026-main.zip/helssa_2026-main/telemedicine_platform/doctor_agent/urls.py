from rest_framework import routers
from .views import (
    DoctorViewSet,
    DoctorScheduleViewSet,
    ClinicalDecisionSupportViewSet,
    PerformanceMetricsViewSet,
)

router = routers.DefaultRouter()
router.register(r'doctors', DoctorViewSet)
router.register(r'schedules', DoctorScheduleViewSet)
router.register(r'cds', ClinicalDecisionSupportViewSet)
router.register(r'metrics', PerformanceMetricsViewSet)

urlpatterns = router.urls
