from django.db import models

class Doctor(models.Model):
    name = models.CharField(max_length=255)
    specialty = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    years_experience = models.IntegerField(default=0)
    rating = models.FloatField(default=0.0)


class DoctorSchedule(models.Model):
    doctor = models.ForeignKey(Doctor, related_name='schedules', on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()


class ClinicalDecisionSupport(models.Model):
    doctor = models.ForeignKey(Doctor, related_name='cds_entries', on_delete=models.CASCADE)
    data = models.TextField()


class PerformanceMetrics(models.Model):
    doctor = models.ForeignKey(Doctor, related_name='metrics', on_delete=models.CASCADE)
    patient_satisfaction = models.FloatField(default=0.0)
    successful_diagnoses = models.IntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)
