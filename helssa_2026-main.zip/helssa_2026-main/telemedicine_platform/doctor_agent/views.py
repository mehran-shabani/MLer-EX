from rest_framework import viewsets, serializers
from .models import Doctor, DoctorSchedule, ClinicalDecisionSupport, PerformanceMetrics

class DoctorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Doctor
        fields = '__all__'

class DoctorScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = DoctorSchedule
        fields = '__all__'

class ClinicalDecisionSupportSerializer(serializers.ModelSerializer):
    class Meta:
        model = ClinicalDecisionSupport
        fields = '__all__'

class PerformanceMetricsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PerformanceMetrics
        fields = '__all__'

class DoctorViewSet(viewsets.ModelViewSet):
    queryset = Doctor.objects.all()
    serializer_class = DoctorSerializer

class DoctorScheduleViewSet(viewsets.ModelViewSet):
    queryset = DoctorSchedule.objects.all()
    serializer_class = DoctorScheduleSerializer

class ClinicalDecisionSupportViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ClinicalDecisionSupport.objects.all()
    serializer_class = ClinicalDecisionSupportSerializer

class PerformanceMetricsViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PerformanceMetrics.objects.all()
    serializer_class = PerformanceMetricsSerializer
