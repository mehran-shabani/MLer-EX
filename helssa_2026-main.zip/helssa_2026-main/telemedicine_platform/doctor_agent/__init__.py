"""Doctor agent Django app."""
