import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/api_service.dart';
import 'providers/auth_provider.dart';
import 'providers/profile_provider.dart';
import 'providers/visit_provider.dart';
import 'providers/wallet_provider.dart';
import 'providers/medagent_provider.dart';
import 'screens/splash_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/home_screen.dart';
import 'utils/app_theme.dart';

void main() {
  runApp(const GoldDropApp());
}

class GoldDropApp extends StatelessWidget {
  const GoldDropApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<ApiService>(
          create: (_) => ApiService(),
        ),
        ChangeNotifierProxyProvider<ApiService, AuthProvider>(
          create: (context) => AuthProvider(context.read<ApiService>()),
          update: (context, apiService, previous) =>
              previous ?? AuthProvider(apiService),
        ),
        ChangeNotifierProxyProvider<ApiService, ProfileProvider>(
          create: (context) => ProfileProvider(context.read<ApiService>()),
          update: (context, apiService, previous) =>
              previous ?? ProfileProvider(apiService),
        ),
        ChangeNotifierProxyProvider<ApiService, WalletProvider>(
          create: (context) => WalletProvider(context.read<ApiService>()),
          update: (context, apiService, previous) =>
              previous ?? WalletProvider(apiService),
        ),
        ChangeNotifierProxyProvider<ApiService, MedAgentProvider>(
          create: (context) => MedAgentProvider(context.read<ApiService>()),
          update: (context, apiService, previous) =>
              previous ?? MedAgentProvider(apiService),
        ),
        
        ChangeNotifierProxyProvider<ApiService, VisitProvider>(
          create: (context) => VisitProvider(
            context.read<ApiService>().visitService,
          ),
          update: (context, apiService, previous) =>
              previous ?? VisitProvider(apiService.visitService),
        ),
      ],
      child: MaterialApp(
        title: 'GoldDrop Telemedicine',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        home: const SplashScreen(),
        routes: {
          '/login': (context) => const LoginScreen(),
          '/home': (context) => const HomeScreen(),
        },
      ),
    );
  }
}
