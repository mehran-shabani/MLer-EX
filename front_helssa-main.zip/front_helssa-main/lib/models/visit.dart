// ================================
// lib/models/visit.dart
// ================================
import 'package:json_annotation/json_annotation.dart';

part 'visit.g.dart';

/// Core visit entity returned by the Medogram backend.
@JsonSerializable()
class Visit {
  final String id;
  final String name;
  final String urgency;
  final String? description;
  final String status;
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @JsonKey(name: 'scheduled_at')
  final DateTime? scheduledAt;

  Visit({
    required this.id,
    required this.name,
    required this.urgency,
    this.description,
    required this.status,
    required this.createdAt,
    this.scheduledAt,
  });

  factory Visit.fromJson(Map<String, dynamic> json) => _$VisitFromJson(json);
  Map<String, dynamic> toJson() => _$VisitToJson(this);
}

// ------------------------------------------------------------------
// Run once after editing the model:
// flutter pub run build_runner build --delete-conflicting-outputs
// ------------------------------------------------------------------