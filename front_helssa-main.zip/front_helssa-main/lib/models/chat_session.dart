import 'package:json_annotation/json_annotation.dart';

part 'chat_session.g.dart';

@JsonSerializable()
class ChatSession {
  final String id;
  final String patientId;
  final String? doctorId;
  final String purpose;
  final String status;
  final DateTime createdAt;
  final DateTime? endedAt;
  final List<ChatMessage> messages;

  ChatSession({
    required this.id,
    required this.patientId,
    this.doctorId,
    required this.purpose,
    required this.status,
    required this.createdAt,
    this.endedAt,
    this.messages = const [],
  });

  factory ChatSession.fromJson(Map<String, dynamic> json) => _$ChatSessionFromJson(json);
  Map<String, dynamic> toJson() => _$ChatSessionToJson(this);
}

@JsonSerializable()
class ChatMessage {
  final String id;
  final String sessionId;
  final String senderId;
  final String senderType; // 'patient', 'doctor', 'agent'
  final String content;
  final String type; // 'text', 'image', 'file'
  final DateTime createdAt;
  final bool isRead;

  ChatMessage({
    required this.id,
    required this.sessionId,
    required this.senderId,
    required this.senderType,
    required this.content,
    required this.type,
    required this.createdAt,
    this.isRead = false,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) => _$ChatMessageFromJson(json);
  Map<String, dynamic> toJson() => _$ChatMessageToJson(this);
}

@JsonSerializable()
class SessionSummary {
  final String sessionId;
  final String patientId;
  final String summary;
  final List<String> keyPoints;
  final List<String> recommendations;
  final DateTime createdAt;

  SessionSummary({
    required this.sessionId,
    required this.patientId,
    required this.summary,
    required this.keyPoints,
    required this.recommendations,
    required this.createdAt,
  });

  factory SessionSummary.fromJson(Map<String, dynamic> json) => _$SessionSummaryFromJson(json);
  Map<String, dynamic> toJson() => _$SessionSummaryToJson(this);
}
