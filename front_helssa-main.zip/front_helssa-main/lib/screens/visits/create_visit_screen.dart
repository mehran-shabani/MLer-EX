import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/visit_provider.dart';
// import AuthProvider (یا هر جایی که توکن را نگه می‌دارید)

class CreateVisitScreen extends StatefulWidget {
  const CreateVisitScreen({super.key});

  @override
  State<CreateVisitScreen> createState() => _CreateVisitScreenState();
}

class _CreateVisitScreenState extends State<CreateVisitScreen> {
  final _formKey = GlobalKey<FormState>();
  final _complaintCtrl = TextEditingController();

  @override
  void dispose() {
    _complaintCtrl.dispose();
    super.dispose();
  }

  Future<void> _createVisit() async {
    if (!_formKey.currentState!.validate()) return;

    // ✔️ توکن را از لایهٔ احراز هویت بگیرید
    const accessToken = /* context.read<AuthProvider>().accessToken */ '';
    if (accessToken.isEmpty) return;

    final visitProvider = context.read<VisitProvider>();
    final ok = await visitProvider.sendQuickVisit(
      chiefComplaint: _complaintCtrl.text.trim(),
      accessToken: accessToken,
    );

    if (!mounted) return;
    final snackBar = SnackBar(
      content: Text(
        ok ? 'Visit created successfully'
           : (visitProvider.error ?? 'Failed to create visit'),
      ),
      backgroundColor: ok ? Colors.green : Colors.red,
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
    if (ok) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Quick Visit')),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextFormField(
                controller: _complaintCtrl,
                decoration: const InputDecoration(
                  labelText: 'Chief Complaint',
                  hintText: 'e.g., Headache, Fever…',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Please describe your complaint' : null,
              ),
              const SizedBox(height: 32),
              Consumer<VisitProvider>(
                builder: (_, v, __) => ElevatedButton(
                  onPressed: v.isSending ? null : _createVisit,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: v.isSending
                      ? const CircularProgressIndicator()
                      : const Text('Create Visit', style: TextStyle(fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
