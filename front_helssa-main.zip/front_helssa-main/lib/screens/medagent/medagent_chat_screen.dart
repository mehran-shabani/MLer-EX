import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/medagent_provider.dart';
import '../../models/chat_session.dart';
import 'session_summary_screen.dart';

class MedAgentChatScreen extends StatefulWidget {
  final dynamic sessionId;
  
  final dynamic purpose;
  
  final dynamic isDoctorFlow;

  // Update constructor to remove patientId since we're not using it
  const MedAgentChatScreen({
    super.key,
    required this.sessionId,
    this.purpose,
    this.isDoctorFlow = false,
  });

  @override
  State<MedAgentChatScreen> createState() => _MedAgentChatScreenState();
}

class _MedAgentChatScreenState extends State<MedAgentChatScreen> {
  // Remove patientId from the class properties
  late final String id;
  late final String? purpose;
  late final bool isDoctorFlow;
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Load the session
      context.read<MedAgentProvider>().loadSession(widget.sessionId);
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    _messageController.clear();
    
    final medAgentProvider = context.read<MedAgentProvider>();
    final success = await medAgentProvider.sendMessage(message);

    if (success) {
      _scrollToBottom();
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(medAgentProvider.error ?? 'Failed to send message'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _endSession() async {
    final shouldEnd = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('End Session'),
        content: Text(widget.isDoctorFlow 
            ? 'Are you sure you want to end this doctor consultation session?'
            : 'Are you sure you want to end this consultation session?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('End Session'),
          ),
        ],
      ),
    );

    if (shouldEnd == true && mounted) {
      final medAgentProvider = context.read<MedAgentProvider>();
      final success = await medAgentProvider.endSession();
      
      if (success && mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Session ended successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isDoctorFlow ? 'Doctor Consultation' : 'MedAgent Chat'),
        actions: [
          Consumer<MedAgentProvider>(
            builder: (context, medAgentProvider, child) {
              final session = medAgentProvider.currentSession;
              if (session?.status.toLowerCase() == 'ended') {
                return IconButton(
                  icon: const Icon(Icons.summarize),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => SessionSummaryScreen(
                          sessionId: widget.sessionId,
                        ),
                      ),
                    );
                  },
                );
              }
              return IconButton(
                icon: const Icon(Icons.stop),
                onPressed: _endSession,
              );
            },
          ),
        ],
      ),
      body: Consumer<MedAgentProvider>(
        builder: (context, medAgentProvider, child) {
          if (medAgentProvider.isLoading && medAgentProvider.messages.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }

          if (medAgentProvider.error != null && medAgentProvider.messages.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.error_outline,
                    size: 64,
                    color: Colors.red,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    medAgentProvider.error!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => medAgentProvider.loadSession(widget.sessionId),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              if (medAgentProvider.currentSession != null)
                _SessionHeader(
                  session: medAgentProvider.currentSession!,
                  isDoctorFlow: widget.isDoctorFlow,
                ),
              Expanded(
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(16),
                  itemCount: medAgentProvider.messages.length,
                  itemBuilder: (context, index) {
                    final message = medAgentProvider.messages[index];
                    return _MessageBubble(
                      message: message,
                      isDoctorFlow: widget.isDoctorFlow,
                    );
                  },
                ),
              ),
              if (medAgentProvider.currentSession?.status.toLowerCase() != 'ended')
                _MessageInput(
                  controller: _messageController,
                  onSend: _sendMessage,
                  isLoading: medAgentProvider.isSendingMessage,
                ),
            ],
          );
        },
      ),
    );
  }
}

class _SessionHeader extends StatelessWidget {
  final ChatSession session;
  final bool isDoctorFlow;

  const _SessionHeader({
    required this.session,
    required this.isDoctorFlow,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).dividerColor,
          ),
        ),
      ),
      child: Row(
        children: [
          Icon(
            isDoctorFlow ? Icons.medical_services : Icons.smart_toy,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isDoctorFlow ? 'Doctor Consultation' : session.purpose,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                // Update the session header to not show patient ID
                if (isDoctorFlow)
                  Text(
                    'Session ID: ${session.id.substring(0, 8)}...',
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: session.status.toLowerCase() == 'active'
                  ? Colors.green.shade100
                  : Colors.grey.shade100,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              session.status,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: session.status.toLowerCase() == 'active'
                    ? Colors.green.shade800
                    : Colors.grey.shade800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final ChatMessage message;
  final bool isDoctorFlow;

  const _MessageBubble({
    required this.message,
    required this.isDoctorFlow,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.senderType == 'patient' || message.senderType == 'doctor';
    final isDoctor = message.senderType == 'doctor';

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser) ...[
            CircleAvatar(
              radius: 16,
              backgroundColor: _getAvatarColor(message.senderType),
              child: Icon(
                _getAvatarIcon(message.senderType),
                size: 16,
                color: _getIconColor(message.senderType),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUser
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(16),
                border: !isUser
                    ? Border.all(color: Theme.of(context).dividerColor)
                    : null,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isUser)
                    Text(
                      _getSenderLabel(message.senderType),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                  if (!isUser) const SizedBox(height: 4),
                  Text(
                    message.content,
                    style: TextStyle(
                      color: isUser
                          ? Theme.of(context).colorScheme.onPrimary
                          : Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _formatTime(message.createdAt),
                    style: TextStyle(
                      fontSize: 10,
                      color: isUser
                          ? Theme.of(context).colorScheme.onPrimary.withOpacity(0.7)
                          : Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            CircleAvatar(
              radius: 16,
              backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
              child: Icon(
                isDoctor ? Icons.medical_services : Icons.person,
                size: 16,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _getAvatarColor(String senderType) {
    switch (senderType) {
      case 'agent':
        return Colors.blue.shade100;
      case 'assistant':
        return Colors.purple.shade100;
      case 'doctor':
        return Colors.green.shade100;
      default:
        return Colors.grey.shade100;
    }
  }

  IconData _getAvatarIcon(String senderType) {
    switch (senderType) {
      case 'agent':
        return Icons.smart_toy;
      case 'assistant':
        return Icons.support_agent;
      case 'doctor':
        return Icons.medical_services;
      default:
        return Icons.person;
    }
  }

  Color _getIconColor(String senderType) {
    switch (senderType) {
      case 'agent':
        return Colors.blue;
      case 'assistant':
        return Colors.purple;
      case 'doctor':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getSenderLabel(String senderType) {
    switch (senderType) {
      case 'agent':
        return 'MedAgent';
      case 'assistant':
        return 'Assistant';
      case 'doctor':
        return 'Doctor';
      default:
        return 'Unknown';
    }
  }

  String _formatTime(DateTime time) {
    return '${time.hour}:${time.minute.toString().padLeft(2, '0')}';
  }
}

class _MessageInput extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;
  final bool isLoading;

  const _MessageInput({
    required this.controller,
    required this.onSend,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).dividerColor,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              decoration: const InputDecoration(
                hintText: 'Type your message...',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
              maxLines: null,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => onSend(),
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            onPressed: isLoading ? null : onSend,
            icon: isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.send),
            style: IconButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
