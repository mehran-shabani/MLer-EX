import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/medagent_provider.dart';
import 'medagent_chat_screen.dart';

class CreateSessionScreen extends StatefulWidget {
  const CreateSessionScreen({super.key});

  @override
  State<CreateSessionScreen> createState() => _CreateSessionScreenState();
}

class _CreateSessionScreenState extends State<CreateSessionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _purposeController = TextEditingController();
  String _selectedPurpose = 'General Consultation';
  String _selectedFlow = 'user'; // 'user' or 'doctor'

  final List<String> _purposeOptions = [
    'General Consultation',
    'Follow-up',
    'Symptom Assessment',
    'Medication Review',
    'Emergency Consultation',
    'Second Opinion',
  ];

  @override
  void dispose() {
    _purposeController.dispose();
    super.dispose();
  }

  Future<void> _createSession() async {
    if (!_formKey.currentState!.validate()) return;

    final purpose = _selectedPurpose == 'Other' 
        ? _purposeController.text 
        : _selectedPurpose;

    // Generate a session ID (you can use UUID or timestamp-based ID)
    final sessionId = DateTime.now().millisecondsSinceEpoch.toString();

    final medAgentProvider = context.read<MedAgentProvider>();
    
    bool success;
    if (_selectedFlow == 'user') {
      // Normal user flow: user + agent
      success = await medAgentProvider.createSession(purpose, sessionId);
    } else {
      // Doctor flow: doctor + assistant
      success = await medAgentProvider.createDoctorSession(purpose, sessionId);
    }

    if (success && mounted) {
      final session = medAgentProvider.currentSession;
      if (session != null) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => MedAgentChatScreen(
              sessionId: session.id,
              purpose: purpose,
              isDoctorFlow: _selectedFlow == 'doctor',
            ),
          ),
        );
      }
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(medAgentProvider.error ?? 'Failed to create session'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Session'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Start a new consultation session',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 24),
              
              // Session Type Selection
              const Text(
                'Session Type',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              Card(
                child: Column(
                  children: [
                    RadioListTile<String>(
                      title: const Text('User + Agent'),
                      subtitle: const Text('Direct consultation with AI agent'),
                      value: 'user',
                      groupValue: _selectedFlow,
                      onChanged: (value) {
                        setState(() {
                          _selectedFlow = value!;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title: const Text('Doctor + Assistant'),
                      subtitle: const Text('Doctor consultation with AI assistant'),
                      value: 'doctor',
                      groupValue: _selectedFlow,
                      onChanged: (value) {
                        setState(() {
                          _selectedFlow = value!;
                        });
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              const Text(
                'Consultation Purpose',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              ..._purposeOptions.map((purpose) {
                return RadioListTile<String>(
                  title: Text(purpose),
                  value: purpose,
                  groupValue: _selectedPurpose,
                  onChanged: (value) {
                    setState(() {
                      _selectedPurpose = value!;
                    });
                  },
                  contentPadding: EdgeInsets.zero,
                );
              }),
              RadioListTile<String>(
                title: const Text('Other'),
                value: 'Other',
                groupValue: _selectedPurpose,
                onChanged: (value) {
                  setState(() {
                    _selectedPurpose = value!;
                  });
                },
                contentPadding: EdgeInsets.zero,
              ),
              if (_selectedPurpose == 'Other') ...[
                const SizedBox(height: 16),
                TextFormField(
                  controller: _purposeController,
                  decoration: const InputDecoration(
                    labelText: 'Custom Purpose',
                    hintText: 'Describe the consultation purpose',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (_selectedPurpose == 'Other' && 
                        (value == null || value.isEmpty)) {
                      return 'Please describe the consultation purpose';
                    }
                    return null;
                  },
                ),
              ],
              
              const SizedBox(height: 32),
              Consumer<MedAgentProvider>(
                builder: (context, medAgentProvider, child) {
                  return ElevatedButton(
                    onPressed: medAgentProvider.isLoading ? null : _createSession,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: medAgentProvider.isLoading
                        ? const CircularProgressIndicator()
                        : Text(
                            _selectedFlow == 'user' 
                                ? 'Start User Session'
                                : 'Start Doctor Session',
                            style: const TextStyle(fontSize: 16),
                          ),
                  );
                },
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _selectedFlow == 'user' ? 'About MedAgent' : 'About Doctor Consultation',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _selectedFlow == 'user'
                            ? 'MedAgent is an AI-powered medical assistant that can help with symptom assessment, medication information, and general health guidance. The server will handle diagnosis based on your consultation purpose.'
                            : 'Doctor consultation mode allows doctors to chat with AI assistant support. The server will provide diagnostic assistance based on the consultation purpose and session context.',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
