import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/chat_session.dart';

class MedAgentProvider extends ChangeNotifier {
  final ApiService _apiService;
  List<ChatSession> _sessions = [];
  ChatSession? _currentSession;
  List<ChatMessage> _messages = [];
  bool _isLoading = false;
  bool _isSendingMessage = false;
  String? _error;

  MedAgentProvider(this._apiService);

  List<ChatSession> get sessions => _sessions;
  ChatSession? get currentSession => _currentSession;
  List<ChatMessage> get messages => _messages;
  bool get isLoading => _isLoading;
  bool get isSendingMessage => _isSendingMessage;
  String? get error => _error;

  Future<void> loadSessions() async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.getChatSessions();
    
    _setLoading(false);
    
    if (response.isSuccess) {
      _sessions = response.data ?? [];
    } else {
      _error = response.error;
    }
    notifyListeners();
  }

  // Normal user session creation (user + agent)
  Future<bool> createSession(String purpose, String sessionId) async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.createChatSession(purpose, sessionId);
  
    _setLoading(false);
  
    if (response.isSuccess) {
      _currentSession = response.data;
      _messages = _currentSession?.messages ?? [];
      await loadSessions(); // Refresh sessions list
      notifyListeners();
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  // Doctor session creation (doctor + assistant)
  Future<bool> createDoctorSession(String purpose, String sessionId) async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.createDoctorChatSession(purpose, sessionId);
  
    _setLoading(false);
  
    if (response.isSuccess) {
      _currentSession = response.data;
      _messages = _currentSession?.messages ?? [];
      await loadSessions(); // Refresh sessions list
      notifyListeners();
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  Future<void> loadSession(String sessionId) async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.getChatSession(sessionId);
    
    _setLoading(false);
    
    if (response.isSuccess) {
      _currentSession = response.data;
      _messages = _currentSession?.messages ?? [];
    } else {
      _error = response.error;
    }
    notifyListeners();
  }

  Future<bool> sendMessage(String content) async {
    if (_currentSession == null) return false;

    _isSendingMessage = true;
    _error = null;
    notifyListeners();

    final response = await _apiService.sendChatMessage(
      _currentSession!.id,
      {'content': content, 'type': 'text'},
    );
    
    _isSendingMessage = false;
    
    if (response.isSuccess) {
      final newMessage = response.data;
      if (newMessage != null) {
        _messages.add(newMessage);
      }
      notifyListeners();
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  Future<bool> endSession() async {
    if (_currentSession == null) return false;

    _setLoading(true);
    _error = null;

    final response = await _apiService.endChatSession(_currentSession!.id);
    
    _setLoading(false);
    
    if (response.isSuccess) {
      _currentSession = null;
      _messages = [];
      await loadSessions(); // Refresh sessions list
      notifyListeners();
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  Future<SessionSummary?> getSessionSummary(String sessionId) async {
    final response = await _apiService.getSessionSummary(sessionId);
    
    if (response.isSuccess) {
      return response.data;
    } else {
      _error = response.error;
      notifyListeners();
      return null;
    }
  }

  void clearCurrentSession() {
    _currentSession = null;
    _messages = [];
    notifyListeners();
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void setCurrentSession(ChatSession session) {
    _currentSession = session;
    _messages = session.messages;
    notifyListeners();
  }

  Future<void> initializeSessionFromId(String sessionId, String patientId, String purpose) async {
    // Create a temporary session object while we load the real one
    _currentSession = ChatSession(
      id: sessionId,
      patientId: patientId,
      purpose: purpose,
      status: 'active',
      createdAt: DateTime.now(),
      messages: [],
    );
    _messages = [];
    notifyListeners();
    
    // Load the actual session data
    await loadSession(sessionId);
  }
}
