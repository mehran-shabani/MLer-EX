// ================================
// lib/providers/visit_provider.dart
// ================================
// Provider (ChangeNotifier) for feeding UI with visit-related state.
// Doctor-on-call banner & cancel-visit functionality were **removed**
// per latest requirements – hence the corresponding fields & methods
// no longer exist here.

import 'package:flutter/material.dart';
import '../services/visit_service.dart';
import '../models/visit.dart';

class VisitProvider extends ChangeNotifier {
  VisitProvider(this._visitService);

  // ---------------------------------------------------------------------------
  // Dependencies
  // ---------------------------------------------------------------------------
  final VisitService _visitService;

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  List<Visit> _visits = [];

  bool _isLoading       = false;
  bool _isSendingVisit  = false;
  bool _isSendingSOS    = false;
  String? _error;

  // ---------------------------------------------------------------------------
  // Getters for UI
  // ---------------------------------------------------------------------------
  List<Visit> get visits       => _visits;
  bool        get isLoading    => _isLoading;
  bool        get isSending    => _isSendingVisit;
  bool        get isSendingSOS => _isSendingSOS;
  String?     get error        => _error;

  // ---------------------------------------------------------------------------
  // Create – normal (prescription) visit
  // ---------------------------------------------------------------------------
  Future<bool> sendRegularVisit({
    required String name,
    required String nationalCode,
    required String details,
    required bool needsCertificate,
    required String contactMethod,
    required String accessToken,
  }) async {
    _isSendingVisit = true;
    _error = null;
    notifyListeners();

    final res = await _visitService.sendRegularVisit(
      name: name,
      nationalCode: nationalCode,
      details: details,
      needsCertificate: needsCertificate,
      contactMethod: contactMethod,
      accessToken: accessToken,
    );

    _isSendingVisit = false;

    if (res.isSuccess) {
      _visits.insert(0, res.data!);
      notifyListeners();
      return true;
    } else {
      _error = res.error;
      notifyListeners();
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Create – SOS visit
  // ---------------------------------------------------------------------------
  Future<bool> sendSOSVisit({
    required String title,
    required String description,
    required String accessToken,
  }) async {
    _isSendingSOS = true;
    _error = null;
    notifyListeners();

    final res = await _visitService.sendSOSVisit(
      title: title,
      description: description,
      accessToken: accessToken,
    );

    _isSendingSOS = false;

    if (res.isSuccess) {
      _visits.insert(0, res.data!);
      notifyListeners();
      return true;
    } else {
      _error = res.error;
      notifyListeners();
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Create – quick presets (4 buttons)
  // ---------------------------------------------------------------------------
  Future<bool> sendQuickVisit({
    required String chiefComplaint,
    required String accessToken,
  }) async {
    _isSendingVisit = true;
    _error = null;
    notifyListeners();

    final res = await _visitService.sendQuickVisit(
      chiefComplaint: chiefComplaint,
      accessToken: accessToken,
    );

    _isSendingVisit = false;

    if (res.isSuccess) {
      _visits.insert(0, res.data!);
      notifyListeners();
      return true;
    } else {
      _error = res.error;
      notifyListeners();
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Read – list & details
  // ---------------------------------------------------------------------------
  Future<void> loadVisits({int page = 1, int limit = 20}) async {
    _setLoading(true);
    _error = null;

    final res = await _visitService.getPatientVisits(page: page, limit: limit);

    _setLoading(false);

    if (res.isSuccess) {
      if (page == 1) {
        _visits = res.data!;
      } else {
        _visits.addAll(res.data!);
      }
    } else {
      _error = res.error;
    }
    notifyListeners();
  }

  Future<Visit?> getVisitDetails(String visitId) async {
    final res = await _visitService.getVisitDetails(visitId);
    if (res.isSuccess) {
      return res.data;
    } else {
      _error = res.error;
      notifyListeners();
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
