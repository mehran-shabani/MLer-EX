import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/wallet.dart';

class WalletProvider extends ChangeNotifier {
  final ApiService _apiService;
  Wallet? _wallet;
  bool _isLoading = false;
  String? _error;

  WalletProvider(this._apiService);

  Wallet? get wallet => _wallet;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadWallet() async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.getWallet();
    
    _setLoading(false);
    
    if (response.isSuccess) {
      _wallet = response.data;
    } else {
      _error = response.error;
    }
    notifyListeners();
  }

  Future<bool> topUpWallet(int amount) async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.createTransaction(amount);
    
    _setLoading(false);
    
    if (response.isSuccess) {
      // In a real app, you would redirect to payment gateway here
      // For now, we'll just reload the wallet
      await loadWallet();
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
}
