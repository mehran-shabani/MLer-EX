import 'package:flutter/material.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  final ApiService _apiService;
  bool _isLoading = false;
  String? _error;

  AuthProvider(this._apiService);

  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _apiService.isAuthenticated;

  Future<bool> register(String phoneNumber) async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.register(phoneNumber);
    
    _setLoading(false);
    
    if (response.isSuccess) {
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  Future<bool> verifyOtp(String phoneNumber, String code) async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.verifyOtp(phoneNumber, code);
    
    _setLoading(false);
    
    if (response.isSuccess) {
      notifyListeners();
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    await _apiService.clearTokens();
    notifyListeners();
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
