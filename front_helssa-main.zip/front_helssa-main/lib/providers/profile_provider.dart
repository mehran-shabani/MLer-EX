import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/user.dart';

class ProfileProvider extends ChangeNotifier {
  final ApiService _apiService;
  User? _user;
  bool _isLoading = false;
  String? _error;

  ProfileProvider(this._apiService);

  User? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadProfile() async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.getProfile();
    
    _setLoading(false);
    
    if (response.isSuccess) {
      _user = response.data;
    } else {
      _error = response.error;
    }
    notifyListeners();
  }

  Future<bool> updateProfile(Map<String, dynamic> data) async {
    _setLoading(true);
    _error = null;

    final response = await _apiService.updateProfile(data);
    
    _setLoading(false);
    
    if (response.isSuccess) {
      _user = response.data;
      notifyListeners();
      return true;
    } else {
      _error = response.error;
      notifyListeners();
      return false;
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
}
