import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/api_response.dart';
import '../models/user.dart';
import '../models/visit.dart';
import '../models/wallet.dart';
import '../models/chat_session.dart';
import 'visit_service.dart';

class ApiService {
  static const String baseUrl = 'https://api.golddrop.ir';
  late final Dio _dio;
  
  late final VisitService _visitService;
  
  String? _accessToken;
  String? _refreshToken;

  ApiService() {
    _dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        if (_accessToken != null) {
          options.headers['Authorization'] = 'Bearer $_accessToken';
        }
        handler.next(options);
      },
      onError: (error, handler) async {
        if (error.response?.statusCode == 401) {
          // Token expired, try to refresh
          if (await _refreshAccessToken()) {
            // Retry the request
            final opts = error.requestOptions;
            opts.headers['Authorization'] = 'Bearer $_accessToken';
            try {
              final response = await _dio.fetch(opts);
              handler.resolve(response);
              return;
            } catch (e) {
              // If retry fails, continue with original error
            }
          }
        }
        handler.next(error);
      },
    ));

    // Initialize specialized services
   
    _visitService = VisitService(_dio);

    _loadTokens();
  }

  // Getters for specialized services
  
  VisitService get visitService => _visitService;

  Future<void> _loadTokens() async {
    final prefs = await SharedPreferences.getInstance();
    _accessToken = prefs.getString('access_token');
    _refreshToken = prefs.getString('refresh_token');
  }

  Future<void> _saveTokens(String accessToken, String refreshToken) async {
    final prefs = await SharedPreferences.getInstance();
    _accessToken = accessToken;
    _refreshToken = refreshToken;
    await prefs.setString('access_token', accessToken);
    await prefs.setString('refresh_token', refreshToken);
  }

  Future<bool> _refreshAccessToken() async {
    if (_refreshToken == null) return false;

    try {
      final response = await _dio.post('/api/token/refresh/', data: {
        'refresh': _refreshToken,
      });

      if (response.statusCode == 200) {
        final newAccessToken = response.data['access'];
        final prefs = await SharedPreferences.getInstance();
        _accessToken = newAccessToken;
        await prefs.setString('access_token', newAccessToken);
        return true;
      }
    } catch (e) {
      // Refresh failed, clear tokens
      await clearTokens();
    }
    return false;
  }

  Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    _accessToken = null;
    _refreshToken = null;
    await prefs.remove('access_token');
    await prefs.remove('refresh_token');
  }

  // Authentication endpoints
  Future<ApiResponse<Map<String, dynamic>>> register(String phoneNumber) async {
    try {
      final response = await _dio.post('/api/register/', data: {
        'phone_number': phoneNumber,
      });
      return ApiResponse.success(response.data);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<Map<String, dynamic>>> verifyOtp(
      String phoneNumber, String code) async {
    try {
      final response = await _dio.post('/api/verify/', data: {
        'phone_number': phoneNumber,
        'code': code,
      });

      if (response.statusCode == 200) {
        final accessToken = response.data['access'];
        final refreshToken = response.data['refresh'];
        await _saveTokens(accessToken, refreshToken);
      }

      return ApiResponse.success(response.data);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  // Profile endpoints
  Future<ApiResponse<User>> getProfile() async {
    try {
      final response = await _dio.get('/api/profile/');
      return ApiResponse.success(User.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<User>> updateProfile(Map<String, dynamic> data) async {
    try {
      final response = await _dio.post('/api/profile/update/', data: data);
      return ApiResponse.success(User.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  // Visit endpoints (legacy support)
  Future<ApiResponse<Visit>> createVisit(Map<String, dynamic> data) async {
    try {
      final response = await _dio.post('/api/visit/', data: data);
      return ApiResponse.success(Visit.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<List<Visit>>> getVisits() async {
    try {
      final response = await _dio.get('/api/visit/');
      final visits = (response.data['results'] as List)
          .map((json) => Visit.fromJson(json))
          .toList();
      return ApiResponse.success(visits);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  // Wallet endpoints
  Future<ApiResponse<Map<String, dynamic>>> createTransaction(int amount) async {
    try {
      final response = await _dio.post('/api/transaction/', data: {
        'amount': amount,
      });
      return ApiResponse.success(response.data);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<Map<String, dynamic>>> verifyPayment(
      String transId, String idGet) async {
    try {
      final response = await _dio.post('/api/verify-payment/', data: {
        'trans_id': transId,
        'id_get': idGet,
      });
      return ApiResponse.success(response.data);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<Wallet>> getWallet() async {
    try {
      final response = await _dio.get('/api/box/');
      return ApiResponse.success(Wallet.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  // MedAgent Chat endpoints
  Future<ApiResponse<ChatSession>> createChatSession(String purpose, String sessionId) async {
    try {
      final response = await _dio.post('/agent/session/create/', data: {
        'purpose': purpose,
        'session_id': sessionId,
      });
      return ApiResponse.success(ChatSession.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<ChatSession>> createDoctorChatSession(String purpose, String sessionId) async {
    try {
      final response = await _dio.post('/agent/session-doctor/create/', data: {
        'purpose': purpose,
        'session_id': sessionId,
      });
      return ApiResponse.success(ChatSession.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<List<ChatSession>>> getChatSessions() async {
    try {
      final response = await _dio.get('/agent/sessions/');
      final sessions = (response.data['results'] as List)
          .map((json) => ChatSession.fromJson(json))
          .toList();
      return ApiResponse.success(sessions);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<ChatSession>> getChatSession(String sessionId) async {
    try {
      final response = await _dio.get('/agent/session/$sessionId/');
      return ApiResponse.success(ChatSession.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<ChatMessage>> sendChatMessage(
      String sessionId, Map<String, dynamic> data) async {
    try {
      final response = await _dio.post('/agent/session/$sessionId/message/', data: data);
      return ApiResponse.success(ChatMessage.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<Map<String, dynamic>>> endChatSession(String sessionId) async {
    try {
      final response = await _dio.patch('/agent/session/end/', data: {
        'session_id': sessionId,
      });
      return ApiResponse.success(response.data);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<SessionSummary>> getSessionSummary(String sessionId) async {
    try {
      final response = await _dio.get('/agent/session/$sessionId/summary/');
      return ApiResponse.success(SessionSummary.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  Future<ApiResponse<SessionSummary>> getPatientSummary(String patientId) async {
    try {
      final response = await _dio.get('/agent/patient/$patientId/summary/');
      return ApiResponse.success(SessionSummary.fromJson(response.data));
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  // Doctor on-call endpoint
  Future<ApiResponse<Map<String, dynamic>>> getDoctorOnCall() async {
    try {
      final response = await _dio.get('/doc/oncall/');
      return ApiResponse.success(response.data);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  // App update status
  Future<ApiResponse<Map<String, dynamic>>> getAppStatus() async {
    try {
      final response = await _dio.get('/down/status/');
      return ApiResponse.success(response.data);
    } on DioException catch (e) {
      return ApiResponse.error(_handleError(e));
    }
  }

  String _handleError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
        return 'Connection timeout. Please check your internet connection.';
      case DioExceptionType.badResponse:
        if (e.response?.data is Map) {
          final data = e.response!.data as Map<String, dynamic>;
          if (data.containsKey('detail')) {
            return data['detail'].toString();
          }
          if (data.containsKey('error')) {
            return data['error'].toString();
          }
        }
        return 'Server error: ${e.response?.statusCode}';
      case DioExceptionType.cancel:
        return 'Request was cancelled';
      default:
        return 'Network error occurred';
    }
  }

  bool get isAuthenticated => _accessToken != null;
}
