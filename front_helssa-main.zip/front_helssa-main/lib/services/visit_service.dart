// ================================
// lib/services/visit_service.dart
// ================================
import 'package:dio/dio.dart';
import '../models/api_response.dart';
import '../models/visit.dart';

/// All visit‑related endpoints except cancelling & on‑call – both removed per
/// latest requirements.
class VisitService {
  VisitService(this._dio);

  final Dio _dio;
  static const _baseUrl = 'https://api.golddrop.ir/api';

  Options _authJson(String token) => Options(headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json; charset=UTF-8',
      });

  // ──────────────────────────────────────────────────────────────
  // 1️⃣  Normal (prescription) visit
  // ──────────────────────────────────────────────────────────────
  Future<ApiResponse<Visit>> sendRegularVisit({
    required String name,
    required String nationalCode,
    required String details,
    required bool needsCertificate,
    required String contactMethod,
    required String accessToken,
  }) async {
    try {
      final payload = {
        'name': name,
        'urgency': 'prescription',
        'general_symptoms': 'fever',
        'description': _buildDescription(
          details: details,
          needsCertificate: needsCertificate,
          contactMethod: contactMethod,
          nationalCode: nationalCode,
        ),
      };

      final res = await _dio.post('$_baseUrl/visit/',
          data: payload, options: _authJson(accessToken));
      return ApiResponse.success(Visit.fromJson(res.data));
    } on DioException catch (e) {
      return ApiResponse.error(_dioError(e));
    } catch (e) {
      return ApiResponse.error('مشکل غیرمنتظره: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────
  // 2️⃣  Quick‑visit presets (4 green chips)
  // ──────────────────────────────────────────────────────────────
  Future<ApiResponse<Visit>> sendQuickVisit({
    required String chiefComplaint,
    required String accessToken,
  }) async {
    try {
      final res = await _dio.post('$_baseUrl/quick-visit/',
          data: {
            'name': chiefComplaint,
            'urgency': 'prescription',
            'general_symptoms': 'fever',
            'description': 'ویزیت سریع - $chiefComplaint',
          },
          options: _authJson(accessToken));
      return ApiResponse.success(Visit.fromJson(res.data));
    } on DioException catch (e) {
      return ApiResponse.error(_dioError(e));
    } catch (e) {
      return ApiResponse.error('مشکل غیرمنتظره: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────
  // 3️⃣  SOS visit
  // ──────────────────────────────────────────────────────────────
  Future<ApiResponse<Visit>> sendSOSVisit({
    required String title,
    required String description,
    required String accessToken,
  }) async {
    try {
      final form = FormData.fromMap({
        'name': title.isNotEmpty ? title : 'اورژانسی',
        'urgency': 'prescription',
        'general_symptoms': 'fever',
        'neurological_symptoms': '',
        'cardiovascular_symptoms': '',
        'gastrointestinal_symptoms': '',
        'respiratory_symptoms': '',
        'description': 'اورژانسی - $description',
      });

      final res = await _dio.post('$_baseUrl/super-visit/500000/',
          data: form,
          options: Options(headers: {
            'Authorization': 'Bearer $accessToken',
          }));

      return ApiResponse.success(Visit.fromJson(res.data));
    } on DioException catch (e) {
      return ApiResponse.error(_dioError(e));
    } catch (e) {
      return ApiResponse.error('مشکل غیرمنتظره: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────
  // 🔍  Fetch list & details
  // ──────────────────────────────────────────────────────────────
  Future<ApiResponse<List<Visit>>> getPatientVisits({int page = 1, int limit = 20}) async {
    try {
      final res = await _dio.get('$_baseUrl/visit/', queryParameters: {
        'page': page,
        'limit': limit,
      });
      final list = (res.data['results'] as List).map((j) => Visit.fromJson(j)).toList();
      return ApiResponse.success(list);
    } on DioException catch (e) {
      return ApiResponse.error(_dioError(e));
    } catch (e) {
      return ApiResponse.error('مشکل غیرمنتظره: $e');
    }
  }

  Future<ApiResponse<Visit>> getVisitDetails(String visitId) async {
    try {
      final res = await _dio.get('$_baseUrl/visit/$visitId/');
      return ApiResponse.success(Visit.fromJson(res.data));
    } on DioException catch (e) {
      return ApiResponse.error(_dioError(e));
    } catch (e) {
      return ApiResponse.error('مشکل غیرمنتظره: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Helpers
  // ──────────────────────────────────────────────────────────────
  String _buildDescription({
    required String details,
    required bool needsCertificate,
    required String contactMethod,
    required String nationalCode,
  }) {
    String n(String s) => s.trim().replaceAll(RegExp(r'\n{2,}'), '\n');
    return '''
📝 جزئیات ویزیت
==========================
${n(details)}
==========================
${needsCertificate ? 'نیاز به استعلاجی دارد ✅' : ''}
==========================
📞: $contactMethod
==========================
🆔: $nationalCode
==========================
'''.trim();
  }

  String _dioError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
        return 'خطای اتصال: پایان مهلت اتصال';
      case DioExceptionType.badResponse:
        if (e.response?.data is Map) {
          final d = e.response!.data as Map<String, dynamic>;
          return d['detail']?.toString() ?? d['error']?.toString() ?? 'خطای سرور: ${e.response?.statusCode}';
        }
        return 'خطای سرور: ${e.response?.statusCode}';
      case DioExceptionType.cancel:
        return 'درخواست لغو شد';
      default:
        return 'خطای ناشناخته شبکه';
    }
  }
}

// ------------------------------------------------------------------
// Usage snippet:
// final service = VisitService(Dio());
// final res = await service.getPatientVisits();
// ------------------------------------------------------------------
