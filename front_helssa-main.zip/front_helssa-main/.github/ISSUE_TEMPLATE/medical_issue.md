---
name: Medical Feature Issue
about: Report issues related to medical features (MedAgent, consultations, etc.)
title: '[MEDICAL] '
labels: 'medical, bug'
assignees: ''

---

**Medical Feature**
Which medical feature is affected?
- [ ] MedAgent Chat
- [ ] Doctor Consultation
- [ ] Session Management
- [ ] Medical Records
- [ ] Prescription Management
- [ ] Other: ___________

**Issue Type**
- [ ] Bug/Error
- [ ] Feature Request
- [ ] Performance Issue
- [ ] Security Concern
- [ ] Compliance Issue

**Describe the issue**
A clear and concise description of the medical feature issue.

**Steps to Reproduce** (if applicable)
1. Go to '...'
2. Click on '....'
3. Enter medical information '....'
4. See error

**Expected Medical Workflow**
Describe what the correct medical workflow should be.

**Patient Safety Impact**
- [ ] No impact on patient safety
- [ ] Low impact
- [ ] Medium impact
- [ ] High impact - could affect patient care
- [ ] Critical - immediate patient safety concern

**Compliance Requirements**
Does this relate to any medical compliance requirements?
- [ ] HIPAA
- [ ] FDA regulations
- [ ] Medical device regulations
- [ ] Other: ___________

**Additional Medical Context**
Add any relevant medical context, workflows, or requirements.

**Priority**
- [ ] Low
- [ ] Medium
- [ ] High
- [ ] Critical (Patient Safety)
