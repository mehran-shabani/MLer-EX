# Contributing to GoldDrop Telemedicine App

Thank you for your interest in contributing to the GoldDrop Telemedicine App! This document provides guidelines and information for contributors.

## Table of Contents
- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Contributing Process](#contributing-process)
- [Coding Standards](#coding-standards)
- [Medical Data Guidelines](#medical-data-guidelines)
- [Testing](#testing)
- [Pull Request Process](#pull-request-process)

## Code of Conduct

This project adheres to a code of conduct that promotes a welcoming and inclusive environment. Please read and follow our code of conduct in all interactions.

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/golddrop-flutter-app.git`
3. Create a feature branch: `git checkout -b feature/your-feature-name`
4. Make your changes
5. Submit a pull request

## Development Setup

### Prerequisites
- Flutter SDK (3.16.0 or later)
- Dart SDK (3.2.0 or later)
- Android Studio / VS Code
- Git

### Setup Steps
1. Install Flutter: https://flutter.dev/docs/get-started/install
2. Clone the repository
3. Run `flutter pub get` to install dependencies
4. Run `flutter packages pub run build_runner build` to generate code
5. Run `flutter run` to start the app

### Environment Configuration
- Copy `.env.example` to `.env` and configure your environment variables
- Set up API endpoints for development/staging environments
- Configure medical data encryption keys (never commit these!)

## Contributing Process

1. **Check existing issues** - Look for existing issues or create a new one
2. **Discuss major changes** - For significant changes, discuss with maintainers first
3. **Follow coding standards** - Ensure your code follows our style guide
4. **Write tests** - Add appropriate tests for your changes
5. **Update documentation** - Update relevant documentation
6. **Submit PR** - Create a pull request with a clear description

## Coding Standards

### Dart/Flutter Guidelines
- Follow the [Dart Style Guide](https://dart.dev/guides/language/effective-dart/style)
- Use `dart format` to format your code
- Run `flutter analyze` to check for issues
- Use meaningful variable and function names
- Add comments for complex medical logic

### File Organization
\`\`\`
lib/
├── models/          # Data models
├── services/        # API and business logic
├── providers/       # State management
├── screens/         # UI screens
├── widgets/         # Reusable widgets
├── utils/           # Utility functions
└── constants/       # App constants
\`\`\`

### Naming Conventions
- Files: `snake_case.dart`
- Classes: `PascalCase`
- Variables/Functions: `camelCase`
- Constants: `SCREAMING_SNAKE_CASE`

## Medical Data Guidelines

### Privacy and Security
- **Never log sensitive medical data**
- **Always encrypt medical data in transit and at rest**
- **Follow HIPAA compliance guidelines**
- **Use anonymized data for testing**
- **Implement proper access controls**

### Medical Feature Development
- Validate medical workflows with healthcare professionals
- Implement proper error handling for medical scenarios
- Add appropriate warnings for critical medical functions
- Test thoroughly with edge cases
- Document medical business logic clearly

### Data Handling
\`\`\`dart
// ✅ Good - Encrypted and secure
final encryptedData = await encryptMedicalData(patientData);
await secureStorage.store(encryptedData);

// ❌ Bad - Plain text medical data
print('Patient data: $patientData'); // Never do this!
\`\`\`

## Testing

### Test Types
- **Unit Tests**: Test individual functions and classes
- **Widget Tests**: Test UI components
- **Integration Tests**: Test complete user flows
- **Medical Workflow Tests**: Test medical scenarios

### Running Tests
\`\`\`bash
# Run all tests
flutter test

# Run specific test file
flutter test test/models/user_test.dart

# Run tests with coverage
flutter test --coverage
\`\`\`

### Test Guidelines
- Write tests for all new features
- Test medical workflows thoroughly
- Use mock data for medical scenarios
- Test error conditions and edge cases
- Maintain test coverage above 80%

## Pull Request Process

### Before Submitting
- [ ] Code is formatted (`dart format`)
- [ ] No analyzer warnings (`flutter analyze`)
- [ ] All tests pass (`flutter test`)
- [ ] Documentation is updated
- [ ] Medical safety checklist completed (if applicable)

### PR Description
- Clearly describe what changes were made
- Reference related issues
- Include screenshots for UI changes
- List any breaking changes
- Add testing instructions

### Review Process
1. Automated checks must pass
2. Code review by maintainers
3. Medical review for healthcare features
4. Testing on multiple devices
5. Final approval and merge

## Medical Feature Contributions

### Special Considerations
- Medical features require additional review
- Healthcare professional validation may be required
- Compliance with medical regulations
- Extra testing for patient safety
- Documentation of medical workflows

### Medical Code Review Checklist
- [ ] Patient data is properly protected
- [ ] Medical logic is validated
- [ ] Error handling for medical scenarios
- [ ] Compliance requirements met
- [ ] Healthcare professional review (if needed)

## Getting Help

- **General Questions**: Create a discussion in GitHub Discussions
- **Bug Reports**: Create an issue with the bug report template
- **Feature Requests**: Create an issue with the feature request template
- **Medical Questions**: Use the medical issue template
- **Security Issues**: Email security@golddrop.ir (do not create public issues)

## Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes for significant contributions
- Special recognition for medical feature contributions

Thank you for contributing to healthcare technology! 🏥💙
