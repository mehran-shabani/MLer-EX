import 'package:flutter_test/flutter_test.dart';
import 'package:golddrop_telemedicine/models/chat_session.dart';

void main() {
  group('ChatSession Model Tests', () {
    test('should create ChatSession from JSON', () {
      // Arrange
      final json = {
        'id': 'session123',
        'patient_id': 'patient123',
        'doctor_id': 'doctor123',
        'purpose': 'General Consultation',
        'status': 'active',
        'created_at': '2023-01-01T00:00:00Z',
        'ended_at': '2023-01-01T01:00:00Z',
        'messages': [],
      };

      // Act
      final session = ChatSession.fromJson(json);

      // Assert
      expect(session.id, 'session123');
      expect(session.patientId, 'patient123');
      expect(session.doctorId, 'doctor123');
      expect(session.purpose, 'General Consultation');
      expect(session.status, 'active');
      expect(session.createdAt, isA<DateTime>());
      expect(session.endedAt, isA<DateTime>());
      expect(session.messages, isEmpty);
    });

    test('should create ChatMessage from JSON', () {
      // Arrange
      final json = {
        'id': 'msg123',
        'session_id': 'session123',
        'sender_id': 'user123',
        'sender_type': 'patient',
        'content': 'Hello doctor',
        'type': 'text',
        'created_at': '2023-01-01T00:00:00Z',
        'is_read': true,
      };

      // Act
      final message = ChatMessage.fromJson(json);

      // Assert
      expect(message.id, 'msg123');
      expect(message.sessionId, 'session123');
      expect(message.senderId, 'user123');
      expect(message.senderType, 'patient');
      expect(message.content, 'Hello doctor');
      expect(message.type, 'text');
      expect(message.createdAt, isA<DateTime>());
      expect(message.isRead, true);
    });

    test('should create SessionSummary from JSON', () {
      // Arrange
      final json = {
        'session_id': 'session123',
        'patient_id': 'patient123',
        'summary': 'Patient consulted for headache',
        'key_points': ['Headache', 'No fever'],
        'recommendations': ['Rest', 'Hydration'],
        'created_at': '2023-01-01T00:00:00Z',
      };

      // Act
      final summary = SessionSummary.fromJson(json);

      // Assert
      expect(summary.sessionId, 'session123');
      expect(summary.patientId, 'patient123');
      expect(summary.summary, 'Patient consulted for headache');
      expect(summary.keyPoints, ['Headache', 'No fever']);
      expect(summary.recommendations, ['Rest', 'Hydration']);
      expect(summary.createdAt, isA<DateTime>());
    });
  });
}
