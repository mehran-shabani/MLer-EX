import 'package:flutter_test/flutter_test.dart';
import 'package:golddrop_telemedicine/models/user.dart';

void main() {
  group('User Model Tests', () {
    test('should create User from JSON', () {
      // Arrange
      final json = {
        'id': '1',
        'username': 'testuser',
        'email': 'test@example.com',
        'phone_number': '09123456789',
        'avatar_url': 'https://example.com/avatar.jpg',
        'created_at': '2023-01-01T00:00:00Z',
        'updated_at': '2023-01-02T00:00:00Z',
      };

      // Act
      final user = User.fromJson(json);

      // Assert
      expect(user.id, '1');
      expect(user.username, 'testuser');
      expect(user.email, 'test@example.com');
      expect(user.phoneNumber, '09123456789');
      expect(user.avatarUrl, 'https://example.com/avatar.jpg');
      expect(user.createdAt, isA<DateTime>());
      expect(user.updatedAt, isA<DateTime>());
    });

    test('should convert User to JSON', () {
      // Arrange
      final user = User(
        id: '1',
        username: 'testuser',
        email: 'test@example.com',
        phoneNumber: '09123456789',
        avatarUrl: 'https://example.com/avatar.jpg',
        createdAt: DateTime.parse('2023-01-01T00:00:00Z'),
        updatedAt: DateTime.parse('2023-01-02T00:00:00Z'),
      );

      // Act
      final json = user.toJson();

      // Assert
      expect(json['id'], '1');
      expect(json['username'], 'testuser');
      expect(json['email'], 'test@example.com');
      expect(json['phone_number'], '09123456789');
      expect(json['avatar_url'], 'https://example.com/avatar.jpg');
      expect(json['created_at'], '2023-01-01T00:00:00.000Z');
      expect(json['updated_at'], '2023-01-02T00:00:00.000Z');
    });

    test('should handle null values', () {
      // Arrange
      final json = <String, dynamic>{
        'id': null,
        'username': null,
        'email': null,
        'phone_number': null,
        'avatar_url': null,
        'created_at': null,
        'updated_at': null,
      };

      // Act
      final user = User.fromJson(json);

      // Assert
      expect(user.id, null);
      expect(user.username, null);
      expect(user.email, null);
      expect(user.phoneNumber, null);
      expect(user.avatarUrl, null);
      expect(user.createdAt, null);
      expect(user.updatedAt, null);
    });
  });
}
