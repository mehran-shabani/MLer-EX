import 'package:golddrop_telemedicine/models/user.dart';
import 'package:golddrop_telemedicine/models/visit.dart';
import 'package:golddrop_telemedicine/models/wallet.dart';
import 'package:golddrop_telemedicine/models/chat_session.dart';

class MockData {
  static User get mockUser => User(
    id: '1',
    username: 'testuser',
    email: 'test@example.com',
    phoneNumber: '09123456789',
    avatarUrl: 'https://example.com/avatar.jpg',
    createdAt: DateTime.parse('2023-01-01T00:00:00Z'),
    updatedAt: DateTime.parse('2023-01-02T00:00:00Z'),
  );

  static Visit get mockVisit => Visit(
    id: '1',
    name: 'General Checkup',
    urgency: 'medium',
    description: 'Regular health checkup',
    status: 'pending',
    createdAt: DateTime.parse('2023-01-01T00:00:00Z'),
    scheduledAt: DateTime.parse('2023-01-02T10:00:00Z'),
  );

  static Wallet get mockWallet => Wallet(
    balance: 500000.0,
    currency: 'IRR',
    transactions: [mockTransaction],
  );

  static Transaction get mockTransaction => Transaction(
    id: '1',
    amount: 100000.0,
    type: 'credit',
    status: 'completed',
    createdAt: DateTime.parse('2023-01-01T00:00:00Z'),
  );

  static ChatSession get mockChatSession => ChatSession(
    id: 'session123',
    patientId: 'patient123',
    doctorId: 'doctor123',
    purpose: 'General Consultation',
    status: 'active',
    createdAt: DateTime.parse('2023-01-01T00:00:00Z'),
    endedAt: null,
    messages: [mockChatMessage],
  );

  static ChatMessage get mockChatMessage => ChatMessage(
    id: 'msg123',
    sessionId: 'session123',
    senderId: 'user123',
    senderType: 'patient',
    content: 'Hello doctor',
    type: 'text',
    createdAt: DateTime.parse('2023-01-01T00:00:00Z'),
    isRead: false,
  );

  static SessionSummary get mockSessionSummary => SessionSummary(
    sessionId: 'session123',
    patientId: 'patient123',
    summary: 'Patient consulted for headache symptoms',
    keyPoints: ['Headache', 'No fever', 'Duration: 2 days'],
    recommendations: ['Rest', 'Hydration', 'Monitor symptoms'],
    createdAt: DateTime.parse('2023-01-01T00:00:00Z'),
  );

  static List<Visit> get mockVisits => [
    mockVisit,
    Visit(
      id: '2',
      name: 'Follow-up',
      urgency: 'low',
      description: 'Follow-up consultation',
      status: 'completed',
      createdAt: DateTime.parse('2023-01-03T00:00:00Z'),
      scheduledAt: DateTime.parse('2023-01-04T14:00:00Z'),
    ),
  ];

  static List<ChatSession> get mockChatSessions => [
    mockChatSession,
    ChatSession(
      id: 'session456',
      patientId: 'patient123',
      purpose: 'Follow-up',
      status: 'ended',
      createdAt: DateTime.parse('2023-01-02T00:00:00Z'),
      endedAt: DateTime.parse('2023-01-02T01:00:00Z'),
      messages: [],
    ),
  ];
}
