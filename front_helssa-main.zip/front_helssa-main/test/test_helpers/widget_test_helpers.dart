import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:golddrop_telemedicine/providers/auth_provider.dart';
import 'package:golddrop_telemedicine/providers/profile_provider.dart';
import 'package:golddrop_telemedicine/providers/visit_provider.dart';
import 'package:golddrop_telemedicine/providers/wallet_provider.dart';
import 'package:golddrop_telemedicine/providers/medagent_provider.dart';
import 'package:golddrop_telemedicine/services/api_service.dart';
import 'package:golddrop_telemedicine/utils/app_theme.dart';

class WidgetTestHelpers {
  static Widget createTestableWidget({
    required Widget child,
    AuthProvider? authProvider,
    ProfileProvider? profileProvider,
    VisitProvider? visitProvider,
    WalletProvider? walletProvider,
    MedAgentProvider? medAgentProvider,
    ApiService? apiService,
  }) {
    final mockApiService = apiService ?? ApiService();
    
    return MultiProvider(
      providers: [
        Provider<ApiService>.value(value: mockApiService),
        ChangeNotifierProvider<AuthProvider>.value(
          value: authProvider ?? AuthProvider(mockApiService),
        ),
        ChangeNotifierProvider<ProfileProvider>.value(
          value: profileProvider ?? ProfileProvider(mockApiService),
        ),
        ChangeNotifierProvider<VisitProvider>.value(
          value: visitProvider ?? VisitProvider(mockApiService),
        ),
        ChangeNotifierProvider<WalletProvider>.value(
          value: walletProvider ?? WalletProvider(mockApiService),
        ),
        ChangeNotifierProvider<MedAgentProvider>.value(
          value: medAgentProvider ?? MedAgentProvider(mockApiService),
        ),
      ],
      child: MaterialApp(
        theme: AppTheme.lightTheme,
        home: child,
      ),
    );
  }

  static Future<void> pumpAndSettle(WidgetTester tester, {Duration? duration}) async {
    await tester.pumpAndSettle(duration ?? const Duration(milliseconds: 100));
  }

  static Future<void> enterTextAndPump(
    WidgetTester tester,
    Finder finder,
    String text,
  ) async {
    await tester.enterText(finder, text);
    await tester.pump();
  }

  static Future<void> tapAndPump(
    WidgetTester tester,
    Finder finder,
  ) async {
    await tester.tap(finder);
    await tester.pump();
  }

  static Future<void> scrollAndPump(
    WidgetTester tester,
    Finder finder,
    Offset offset,
  ) async {
    await tester.drag(finder, offset);
    await tester.pump();
  }

  static Finder findByTextContaining(String text) {
    return find.byWidgetPredicate(
      (widget) => widget is Text && widget.data?.contains(text) == true,
    );
  }

  static Finder findByKeyString(String key) {
    return find.byKey(Key(key));
  }
}
