import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:golddrop_telemedicine/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('App Integration Tests', () {
    testWidgets('complete authentication flow', (tester) async {
      // Start the app
      app.main();
      await tester.pumpAndSettle();

      // Should start with splash screen
      expect(find.text('GoldDrop'), findsOneWidget);
      expect(find.text('Telemedicine & MedAgent'), findsOneWidget);

      // Wait for navigation to login screen
      await tester.pumpAndSettle(const Duration(seconds: 3));

      // Should navigate to login screen
      expect(find.text('Welcome to GoldDrop'), findsOneWidget);
      expect(find.text('Enter your phone number to get started'), findsOneWidget);

      // Enter phone number
      await tester.enterText(
        find.byType(TextFormField),
        '09123456789',
      );
      await tester.pump();

      // Tap send OTP button
      await tester.tap(find.text('Send OTP'));
      await tester.pumpAndSettle();

      // Should navigate to OTP verification screen
      expect(find.text('Enter Verification Code'), findsOneWidget);

      // Enter OTP code
      await tester.enterText(
        find.byType(TextFormField),
        '123456',
      );
      await tester.pump();

      // Tap verify button
      await tester.tap(find.text('Verify'));
      await tester.pumpAndSettle();

      // Should navigate to home screen (if OTP is valid)
      // Note: This will fail in real testing without proper backend
      // but shows the complete flow
    });

    testWidgets('navigation between tabs', (tester) async {
      // This test assumes user is already logged in
      app.main();
      await tester.pumpAndSettle();

      // Skip authentication for this test
      // In a real scenario, you'd mock the authentication state

      // Test bottom navigation
      await tester.tap(find.text('Visits'));
      await tester.pumpAndSettle();
      expect(find.text('My Visits'), findsOneWidget);

      await tester.tap(find.text('Wallet'));
      await tester.pumpAndSettle();
      expect(find.text('Wallet'), findsOneWidget);

      await tester.tap(find.text('Profile'));
      await tester.pumpAndSettle();
      expect(find.text('Profile'), findsOneWidget);

      await tester.tap(find.text('Home'));
      await tester.pumpAndSettle();
      expect(find.text('GoldDrop'), findsOneWidget);
    });

    testWidgets('MedAgent session creation flow', (tester) async {
      app.main();
      await tester.pumpAndSettle();

      // Navigate to MedAgent from home screen
      await tester.tap(find.text('MedAgent'));
      await tester.pumpAndSettle();

      // Should show sessions screen
      expect(find.text('MedAgent Sessions'), findsOneWidget);

      // Tap create new session
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();

      // Should show create session screen
      expect(find.text('New Session'), findsOneWidget);

      // Select purpose
      await tester.tap(find.text('General Consultation'));
      await tester.pump();

      // Create session
      await tester.tap(find.text('Start User Session'));
      await tester.pumpAndSettle();

      // Should navigate to chat screen
      expect(find.text('MedAgent Chat'), findsOneWidget);
    });
  });
}
