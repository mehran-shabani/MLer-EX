import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:dio/dio.dart';
import 'package:golddrop_telemedicine/services/enhanced_visit_service.dart';
import 'package:golddrop_telemedicine/models/visit.dart';

import 'enhanced_visit_service_test.mocks.dart';

@GenerateMocks([Dio])
void main() {
  group('EnhancedVisitService Tests', () {
    late EnhancedVisitService visitService;
    late MockDio mockDio;

    setUp(() {
      mockDio = MockDio();
      visitService = EnhancedVisitService(mockDio);
    });

    group('sendRegularVisit', () {
      test('should send regular visit successfully', () async {
        // Arrange
        final responseData = {
          'id': '1',
          'name': 'Test Patient',
          'urgency': 'prescription',
          'description': 'Test description',
          'status': 'pending',
          'created_at': DateTime.now().toIso8601String(),
        };

        when(mockDio.post(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await visitService.sendRegularVisit(
          name: 'Test Patient',
          nationalCode: '1234567890',
          details: 'Test symptoms',
          needsCertificate: false,
          contactMethod: 'واتس‌اپ',
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<Visit>());
        expect(result.data!.name, 'Test Patient');
        expect(result.data!.urgency, 'prescription');
      });

      test('should handle API error', () async {
        // Arrange
        when(mockDio.post(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenThrow(DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.badResponse,
          response: Response(
            statusCode: 400,
            data: {'error': 'Invalid visit data'},
            requestOptions: RequestOptions(path: ''),
          ),
        ));

        // Act
        final result = await visitService.sendRegularVisit(
          name: 'Test Patient',
          nationalCode: '1234567890',
          details: 'Test symptoms',
          needsCertificate: false,
          contactMethod: 'واتس‌اپ',
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, false);
        expect(result.error, contains('Invalid visit data'));
      });
    });

    group('sendSOSVisit', () {
      test('should send SOS visit successfully', () async {
        // Arrange
        final responseData = {
          'id': '2',
          'name': 'اورژانسی',
          'urgency': 'prescription',
          'description': 'اورژانسی - Emergency case',
          'status': 'urgent',
          'created_at': DateTime.now().toIso8601String(),
        };

        when(mockDio.post(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await visitService.sendSOSVisit(
          visitName: 'Emergency Patient',
          description: 'Emergency case',
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<Visit>());
        expect(result.data!.description, contains('اورژانسی'));
      });
    });

    group('sendQuickVisit', () {
      test('should send quick visit successfully', () async {
        // Arrange
        final responseData = {
          'id': '3',
          'name': 'Quick Patient',
          'urgency': 'medium',
          'description': 'ویزیت سریع - Quick symptoms',
          'status': 'pending',
          'created_at': DateTime.now().toIso8601String(),
        };

        when(mockDio.post(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await visitService.sendQuickVisit(
          patientName: 'Quick Patient',
          symptoms: 'Quick symptoms',
          urgencyLevel: 'medium',
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<Visit>());
        expect(result.data!.name, 'Quick Patient');
        expect(result.data!.description, contains('ویزیت سریع'));
      });
    });

    group('getDoctorOnCall', () {
      test('should get doctor on call information', () async {
        // Arrange
        final responseData = {
          'full_name': 'Dr. Test Doctor',
          'specialty': 'General Medicine',
          'image': 'https://example.com/doctor.jpg',
          'is_available': true,
        };

        when(mockDio.get(any)).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await visitService.getDoctorOnCall();

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<Map<String, dynamic>>());
        expect(result.data!['full_name'], 'Dr. Test Doctor');
        expect(result.data!['specialty'], 'General Medicine');
      });

      test('should handle no doctor available', () async {
        // Arrange
        when(mockDio.get(any)).thenThrow(DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.badResponse,
          response: Response(
            statusCode: 404,
            requestOptions: RequestOptions(path: ''),
          ),
        ));

        // Act
        final result = await visitService.getDoctorOnCall();

        // Assert
        expect(result.isSuccess, false);
        expect(result.error, contains('خطای سرور'));
      });
    });

    group('getPatientVisits', () {
      test('should get patient visits list', () async {
        // Arrange
        final responseData = {
          'results': [
            {
              'id': '1',
              'name': 'Patient 1',
              'urgency': 'low',
              'description': 'Description 1',
              'status': 'completed',
              'created_at': DateTime.now().toIso8601String(),
            },
            {
              'id': '2',
              'name': 'Patient 2',
              'urgency': 'high',
              'description': 'Description 2',
              'status': 'pending',
              'created_at': DateTime.now().toIso8601String(),
            },
          ]
        };

        when(mockDio.get(
          any,
          queryParameters: anyNamed('queryParameters'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await visitService.getPatientVisits(
          accessToken: 'test_token',
          page: 1,
          limit: 20,
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<List<Visit>>());
        expect(result.data!.length, 2);
        expect(result.data!.first.name, 'Patient 1');
      });
    });

    group('cancelVisit', () {
      test('should cancel visit successfully', () async {
        // Arrange
        when(mockDio.patch(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await visitService.cancelVisit(
          visitId: '1',
          accessToken: 'test_token',
          reason: 'Patient request',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, true);
      });
    });
  });
}
