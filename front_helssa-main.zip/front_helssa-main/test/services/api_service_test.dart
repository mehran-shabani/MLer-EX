import 'package:flutter_test/flutter_test.dart';
import 'package:dio/dio.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:golddrop_telemedicine/services/api_service.dart';
import 'package:golddrop_telemedicine/models/user.dart';
import 'package:golddrop_telemedicine/models/visit.dart';
import 'package:golddrop_telemedicine/models/wallet.dart';
import 'package:golddrop_telemedicine/models/chat_session.dart';

import 'api_service_test.mocks.dart';

@GenerateMocks([Dio, SharedPreferences])
void main() {
  group('ApiService Tests', () {
    late ApiService apiService;
    late MockDio mockDio;
    late MockSharedPreferences mockPrefs;

    setUp(() {
      mockDio = MockDio();
      mockPrefs = MockSharedPreferences();
      
      // Mock SharedPreferences
      SharedPreferences.setMockInitialValues({});
      
      apiService = ApiService();
    });

    group('Authentication', () {
      test('register should return success response', () async {
        // Arrange
        const phoneNumber = '09123456789';
        final responseData = {'message': 'OTP sent successfully'};
        
        when(mockDio.post('/api/register/', data: anyNamed('data')))
            .thenAnswer((_) async => Response(
                  data: responseData,
                  statusCode: 200,
                  requestOptions: RequestOptions(path: '/api/register/'),
                ));

        // Act
        final result = await apiService.register(phoneNumber);

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, responseData);
      });

      test('register should return error on failure', () async {
        // Arrange
        const phoneNumber = '09123456789';
        
        when(mockDio.post('/api/register/', data: anyNamed('data')))
            .thenThrow(DioException(
              requestOptions: RequestOptions(path: '/api/register/'),
              type: DioExceptionType.badResponse,
              response: Response(
                statusCode: 400,
                data: {'detail': 'Invalid phone number'},
                requestOptions: RequestOptions(path: '/api/register/'),
              ),
            ));

        // Act
        final result = await apiService.register(phoneNumber);

        // Assert
        expect(result.isSuccess, false);
        expect(result.error, contains('Invalid phone number'));
      });

      test('verifyOtp should save tokens on success', () async {
        // Arrange
        const phoneNumber = '09123456789';
        const code = '123456';
        final responseData = {
          'access': 'access_token',
          'refresh': 'refresh_token',
        };
        
        when(mockDio.post('/api/verify/', data: anyNamed('data')))
            .thenAnswer((_) async => Response(
                  data: responseData,
                  statusCode: 200,
                  requestOptions: RequestOptions(path: '/api/verify/'),
                ));

        // Act
        final result = await apiService.verifyOtp(phoneNumber, code);

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, responseData);
      });
    });

    group('Profile Management', () {
      test('getProfile should return user data', () async {
        // Arrange
        final userData = {
          'id': '1',
          'username': 'testuser',
          'email': 'test@example.com',
          'phone_number': '09123456789',
          'created_at': DateTime.now().toIso8601String(),
          'updated_at': DateTime.now().toIso8601String(),
        };
        
        when(mockDio.get('/api/profile/'))
            .thenAnswer((_) async => Response(
                  data: userData,
                  statusCode: 200,
                  requestOptions: RequestOptions(path: '/api/profile/'),
                ));

        // Act
        final result = await apiService.getProfile();

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<User>());
        expect(result.data!.username, 'testuser');
      });

      test('updateProfile should return updated user data', () async {
        // Arrange
        final updateData = {'username': 'newusername'};
        final responseData = {
          'id': '1',
          'username': 'newusername',
          'email': 'test@example.com',
          'phone_number': '09123456789',
          'created_at': DateTime.now().toIso8601String(),
          'updated_at': DateTime.now().toIso8601String(),
        };
        
        when(mockDio.post('/api/profile/update/', data: updateData))
            .thenAnswer((_) async => Response(
                  data: responseData,
                  statusCode: 200,
                  requestOptions: RequestOptions(path: '/api/profile/update/'),
                ));

        // Act
        final result = await apiService.updateProfile(updateData);

        // Assert
        expect(result.isSuccess, true);
        expect(result.data!.username, 'newusername');
      });
    });

    group('MedAgent Chat', () {
      test('createChatSession should return session data', () async {
        // Arrange
        const purpose = 'General Consultation';
        const sessionId = '12345';
        final sessionData = {
          'id': sessionId,
          'patient_id': 'patient123',
          'purpose': purpose,
          'status': 'active',
          'created_at': DateTime.now().toIso8601String(),
          'messages': [],
        };
        
        when(mockDio.post('/agent/session/create/', data: anyNamed('data')))
            .thenAnswer((_) async => Response(
                  data: sessionData,
                  statusCode: 200,
                  requestOptions: RequestOptions(path: '/agent/session/create/'),
                ));

        // Act
        final result = await apiService.createChatSession(purpose, sessionId);

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<ChatSession>());
        expect(result.data!.purpose, purpose);
      });

      test('sendChatMessage should return message data', () async {
        // Arrange
        const sessionId = '12345';
        final messageData = {'content': 'Hello', 'type': 'text'};
        final responseData = {
          'id': 'msg123',
          'session_id': sessionId,
          'sender_id': 'user123',
          'sender_type': 'patient',
          'content': 'Hello',
          'type': 'text',
          'created_at': DateTime.now().toIso8601String(),
          'is_read': false,
        };
        
        when(mockDio.post('/agent/session/$sessionId/message/', data: messageData))
            .thenAnswer((_) async => Response(
                  data: responseData,
                  statusCode: 200,
                  requestOptions: RequestOptions(path: '/agent/session/$sessionId/message/'),
                ));

        // Act
        final result = await apiService.sendChatMessage(sessionId, messageData);

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<ChatMessage>());
        expect(result.data!.content, 'Hello');
      });
    });

    group('Error Handling', () {
      test('should handle connection timeout', () async {
        // Arrange
        when(mockDio.post('/api/register/', data: anyNamed('data')))
            .thenThrow(DioException(
              requestOptions: RequestOptions(path: '/api/register/'),
              type: DioExceptionType.connectionTimeout,
            ));

        // Act
        final result = await apiService.register('09123456789');

        // Assert
        expect(result.isSuccess, false);
        expect(result.error, contains('Connection timeout'));
      });

      test('should handle network error', () async {
        // Arrange
        when(mockDio.post('/api/register/', data: anyNamed('data')))
            .thenThrow(DioException(
              requestOptions: RequestOptions(path: '/api/register/'),
              type: DioExceptionType.unknown,
            ));

        // Act
        final result = await apiService.register('09123456789');

        // Assert
        expect(result.isSuccess, false);
        expect(result.error, contains('Network error'));
      });
    });
  });
}
