import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:dio/dio.dart';
import 'package:golddrop_telemedicine/services/prescription_service.dart';
import 'package:golddrop_telemedicine/models/prescription.dart';

import 'prescription_service_test.mocks.dart';

@GenerateMocks([Dio])
void main() {
  group('PrescriptionService Tests', () {
    late PrescriptionService prescriptionService;
    late MockDio mockDio;

    setUp(() {
      mockDio = MockDio();
      prescriptionService = PrescriptionService(mockDio);
    });

    group('createPrescription', () {
      test('should return success when prescription is created successfully', () async {
        // Arrange
        final medicines = [
          Medicine(
            name: 'Aspirin',
            doseMg: '500',
            perIntake: 'یک عدد',
            frequency: 'هر روز',
            quantity: '30',
          ),
        ];

        final responseData = {
          'id': '1',
          'patient_id': 'patient123',
          'doctor_id': 'doctor123',
          'medicines': [
            {
              'name': 'Aspirin',
              'dose_mg': '500',
              'per_intake': 'یک عدد',
              'frequency': 'هر روز',
              'quantity': '30',
            }
          ],
          'created_at': DateTime.now().toIso8601String(),
          'status': 'active',
        };

        when(mockDio.post(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 201,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await prescriptionService.createPrescription(
          patientName: 'Test Patient',
          nationalCode: '1234567890',
          medicines: medicines,
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<Prescription>());
        expect(result.data!.medicines.length, 1);
        expect(result.data!.medicines.first.name, 'Aspirin');
      });

      test('should return error when API call fails', () async {
        // Arrange
        when(mockDio.post(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenThrow(DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.badResponse,
          response: Response(
            statusCode: 400,
            data: {'detail': 'Invalid data'},
            requestOptions: RequestOptions(path: ''),
          ),
        ));

        // Act
        final result = await prescriptionService.createPrescription(
          patientName: 'Test Patient',
          nationalCode: '1234567890',
          medicines: [],
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, false);
        expect(result.error, contains('Invalid data'));
      });
    });

    group('getPatientPrescriptions', () {
      test('should return list of prescriptions', () async {
        // Arrange
        final responseData = {
          'results': [
            {
              'id': '1',
              'patient_id': 'patient123',
              'doctor_id': 'doctor123',
              'medicines': [],
              'created_at': DateTime.now().toIso8601String(),
              'status': 'active',
            }
          ]
        };

        when(mockDio.get(
          any,
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await prescriptionService.getPatientPrescriptions(
          patientId: 'patient123',
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<List<Prescription>>());
        expect(result.data!.length, 1);
      });
    });

    group('searchMedicines', () {
      test('should return list of medicine names', () async {
        // Arrange
        final responseData = {
          'results': [
            {'name': 'Aspirin'},
            {'name': 'Acetaminophen'},
          ]
        };

        when(mockDio.get(
          any,
          queryParameters: anyNamed('queryParameters'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await prescriptionService.searchMedicines(
          query: 'asp',
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, isA<List<String>>());
        expect(result.data!.length, 2);
        expect(result.data!.first, 'Aspirin');
      });
    });

    group('updatePrescription', () {
      test('should update prescription successfully', () async {
        // Arrange
        final medicines = [
          Medicine(
            name: 'Updated Medicine',
            doseMg: '250',
            perIntake: 'دو عدد',
            frequency: 'هر 8 ساعت',
            quantity: '60',
          ),
        ];

        final responseData = {
          'id': '1',
          'patient_id': 'patient123',
          'doctor_id': 'doctor123',
          'medicines': [
            {
              'name': 'Updated Medicine',
              'dose_mg': '250',
              'per_intake': 'دو عدد',
              'frequency': 'هر 8 ساعت',
              'quantity': '60',
            }
          ],
          'created_at': DateTime.now().toIso8601String(),
          'updated_at': DateTime.now().toIso8601String(),
          'status': 'active',
        };

        when(mockDio.patch(
          any,
          data: anyNamed('data'),
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              data: responseData,
              statusCode: 200,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await prescriptionService.updatePrescription(
          prescriptionId: '1',
          medicines: medicines,
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data!.medicines.first.name, 'Updated Medicine');
      });
    });

    group('deletePrescription', () {
      test('should delete prescription successfully', () async {
        // Arrange
        when(mockDio.delete(
          any,
          options: anyNamed('options'),
        )).thenAnswer((_) async => Response(
              statusCode: 204,
              requestOptions: RequestOptions(path: ''),
            ));

        // Act
        final result = await prescriptionService.deletePrescription(
          prescriptionId: '1',
          accessToken: 'test_token',
        );

        // Assert
        expect(result.isSuccess, true);
        expect(result.data, true);
      });
    });
  });
}
