import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:golddrop_telemedicine/providers/auth_provider.dart';
import 'package:golddrop_telemedicine/services/api_service.dart';
import 'package:golddrop_telemedicine/models/api_response.dart';

import 'auth_provider_test.mocks.dart';

@GenerateMocks([ApiService])
void main() {
  group('AuthProvider Tests', () {
    late AuthProvider authProvider;
    late MockApiService mockApiService;

    setUp(() {
      mockApiService = MockApiService();
      authProvider = AuthProvider(mockApiService);
    });

    test('initial state should be correct', () {
      expect(authProvider.isLoading, false);
      expect(authProvider.error, null);
    });

    test('register should update loading state', () async {
      // Arrange
      when(mockApiService.register(any))
          .thenAnswer((_) async => ApiResponse.success({'message': 'Success'}));
      when(mockApiService.isAuthenticated).thenReturn(false);

      // Act
      final future = authProvider.register('09123456789');
      
      // Assert loading state
      expect(authProvider.isLoading, true);
      
      await future;
      expect(authProvider.isLoading, false);
    });

    test('register success should return true', () async {
      // Arrange
      when(mockApiService.register(any))
          .thenAnswer((_) async => ApiResponse.success({'message': 'Success'}));
      when(mockApiService.isAuthenticated).thenReturn(false);

      // Act
      final result = await authProvider.register('09123456789');

      // Assert
      expect(result, true);
      expect(authProvider.error, null);
    });

    test('register failure should set error and return false', () async {
      // Arrange
      const errorMessage = 'Invalid phone number';
      when(mockApiService.register(any))
          .thenAnswer((_) async => ApiResponse.error(errorMessage));
      when(mockApiService.isAuthenticated).thenReturn(false);

      // Act
      final result = await authProvider.register('09123456789');

      // Assert
      expect(result, false);
      expect(authProvider.error, errorMessage);
    });

    test('verifyOtp success should return true', () async {
      // Arrange
      when(mockApiService.verifyOtp(any, any))
          .thenAnswer((_) async => ApiResponse.success({'access': 'token'}));
      when(mockApiService.isAuthenticated).thenReturn(true);

      // Act
      final result = await authProvider.verifyOtp('09123456789', '123456');

      // Assert
      expect(result, true);
      expect(authProvider.error, null);
    });

    test('logout should clear tokens', () async {
      // Arrange
      when(mockApiService.clearTokens()).thenAnswer((_) async {});
      when(mockApiService.isAuthenticated).thenReturn(false);

      // Act
      await authProvider.logout();

      // Assert
      verify(mockApiService.clearTokens()).called(1);
    });

    test('clearError should reset error state', () {
      // Arrange
      authProvider.register('invalid'); // This will set an error

      // Act
      authProvider.clearError();

      // Assert
      expect(authProvider.error, null);
    });
  });
}
