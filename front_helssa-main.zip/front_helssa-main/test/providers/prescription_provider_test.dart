import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:golddrop_telemedicine/providers/prescription_provider.dart';
import 'package:golddrop_telemedicine/services/prescription_service.dart';
import 'package:golddrop_telemedicine/models/prescription.dart';
import 'package:golddrop_telemedicine/models/api_response.dart';

import 'prescription_provider_test.mocks.dart';

@GenerateMocks([PrescriptionService])
void main() {
  group('PrescriptionProvider Tests', () {
    late PrescriptionProvider prescriptionProvider;
    late MockPrescriptionService mockPrescriptionService;

    setUp(() {
      mockPrescriptionService = MockPrescriptionService();
      prescriptionProvider = PrescriptionProvider(mockPrescriptionService);
    });

    test('initial state should be correct', () {
      expect(prescriptionProvider.prescriptions, isEmpty);
      expect(prescriptionProvider.currentMedicines, isEmpty);
      expect(prescriptionProvider.medicineSearchResults, isEmpty);
      expect(prescriptionProvider.isLoading, false);
      expect(prescriptionProvider.isSearching, false);
      expect(prescriptionProvider.error, null);
    });

    group('createPrescription', () {
      test('should create prescription successfully', () async {
        // Arrange
        final medicines = [
          Medicine(
            name: 'Aspirin',
            doseMg: '500',
            perIntake: 'یک عدد',
            frequency: 'هر روز',
            quantity: '30',
          ),
        ];

        final prescription = Prescription(
          id: '1',
          patientId: 'patient123',
          doctorId: 'doctor123',
          medicines: medicines,
          createdAt: DateTime.now(),
          status: 'active',
        );

        when(mockPrescriptionService.createPrescription(
          patientName: anyNamed('patientName'),
          nationalCode: anyNamed('nationalCode'),
          medicines: anyNamed('medicines'),
          notes: anyNamed('notes'),
          accessToken: anyNamed('accessToken'),
        )).thenAnswer((_) async => ApiResponse.success(prescription));

        // Act
        final result = await prescriptionProvider.createPrescription(
          patientName: 'Test Patient',
          nationalCode: '1234567890',
          medicines: medicines,
          accessToken: 'test_token',
        );

        // Assert
        expect(result, true);
        expect(prescriptionProvider.prescriptions.length, 1);
        expect(prescriptionProvider.prescriptions.first.id, '1');
        expect(prescriptionProvider.error, null);
      });

      test('should handle creation failure', () async {
        // Arrange
        when(mockPrescriptionService.createPrescription(
          patientName: anyNamed('patientName'),
          nationalCode: anyNamed('nationalCode'),
          medicines: anyNamed('medicines'),
          notes: anyNamed('notes'),
          accessToken: anyNamed('accessToken'),
        )).thenAnswer((_) async => ApiResponse.error('Creation failed'));

        // Act
        final result = await prescriptionProvider.createPrescription(
          patientName: 'Test Patient',
          nationalCode: '1234567890',
          medicines: [],
          accessToken: 'test_token',
        );

        // Assert
        expect(result, false);
        expect(prescriptionProvider.prescriptions, isEmpty);
        expect(prescriptionProvider.error, 'Creation failed');
      });
    });

    group('loadPatientPrescriptions', () {
      test('should load prescriptions successfully', () async {
        // Arrange
        final prescriptions = [
          Prescription(
            id: '1',
            patientId: 'patient123',
            doctorId: 'doctor123',
            medicines: [],
            createdAt: DateTime.now(),
            status: 'active',
          ),
          Prescription(
            id: '2',
            patientId: 'patient123',
            doctorId: 'doctor123',
            medicines: [],
            createdAt: DateTime.now(),
            status: 'completed',
          ),
        ];

        when(mockPrescriptionService.getPatientPrescriptions(
          patientId: anyNamed('patientId'),
          accessToken: anyNamed('accessToken'),
        )).thenAnswer((_) async => ApiResponse.success(prescriptions));

        // Act
        await prescriptionProvider.loadPatientPrescriptions(
          patientId: 'patient123',
          accessToken: 'test_token',
        );

        // Assert
        expect(prescriptionProvider.prescriptions.length, 2);
        expect(prescriptionProvider.error, null);
      });
    });

    group('searchMedicines', () {
      test('should search medicines successfully', () async {
        // Arrange
        final medicines = ['Aspirin', 'Acetaminophen', 'Ibuprofen'];
        when(mockPrescriptionService.searchMedicines(
          query: anyNamed('query'),
          accessToken: anyNamed('accessToken'),
        )).thenAnswer((_) async => ApiResponse.success(medicines));

        // Act
        await prescriptionProvider.searchMedicines(
          query: 'asp',
          accessToken: 'test_token',
        );

        // Assert
        expect(prescriptionProvider.medicineSearchResults.length, 3);
        expect(prescriptionProvider.medicineSearchResults.first, 'Aspirin');
        expect(prescriptionProvider.isSearching, false);
      });

      test('should clear results for empty query', () async {
        // Arrange
        prescriptionProvider.medicineSearchResults.addAll(['Test1', 'Test2']);

        // Act
        await prescriptionProvider.searchMedicines(
          query: '',
          accessToken: 'test_token',
        );

        // Assert
        expect(prescriptionProvider.medicineSearchResults, isEmpty);
        verifyNever(mockPrescriptionService.searchMedicines(
          query: anyNamed('query'),
          accessToken: anyNamed('accessToken'),
        ));
      });
    });

    group('medicine management', () {
      test('should add medicine to current list', () {
        // Arrange
        final medicine = Medicine(
          name: 'Test Medicine',
          doseMg: '250',
          perIntake: 'یک عدد',
          frequency: 'هر روز',
          quantity: '30',
        );

        // Act
        prescriptionProvider.addMedicine(medicine);

        // Assert
        expect(prescriptionProvider.currentMedicines.length, 1);
        expect(prescriptionProvider.currentMedicines.first.name, 'Test Medicine');
      });

      test('should update medicine in current list', () {
        // Arrange
        final medicine1 = Medicine(
          name: 'Medicine 1',
          doseMg: '250',
          perIntake: 'یک عدد',
          frequency: 'هر روز',
          quantity: '30',
        );
        final medicine2 = Medicine(
          name: 'Medicine 2',
          doseMg: '500',
          perIntake: 'دو عدد',
          frequency: 'هر 8 ساعت',
          quantity: '60',
        );

        prescriptionProvider.addMedicine(medicine1);

        // Act
        prescriptionProvider.updateMedicine(0, medicine2);

        // Assert
        expect(prescriptionProvider.currentMedicines.length, 1);
        expect(prescriptionProvider.currentMedicines.first.name, 'Medicine 2');
        expect(prescriptionProvider.currentMedicines.first.doseMg, '500');
      });

      test('should remove medicine from current list', () {
        // Arrange
        final medicine = Medicine(
          name: 'Test Medicine',
          doseMg: '250',
          perIntake: 'یک عدد',
          frequency: 'هر روز',
          quantity: '30',
        );

        prescriptionProvider.addMedicine(medicine);

        // Act
        prescriptionProvider.removeMedicine(0);

        // Assert
        expect(prescriptionProvider.currentMedicines, isEmpty);
      });

      test('should clear all current medicines', () {
        // Arrange
        final medicine1 = Medicine(
          name: 'Medicine 1',
          doseMg: '250',
          perIntake: 'یک عدد',
          frequency: 'هر روز',
          quantity: '30',
        );
        final medicine2 = Medicine(
          name: 'Medicine 2',
          doseMg: '500',
          perIntake: 'دو عدد',
          frequency: 'هر 8 ساعت',
          quantity: '60',
        );

        prescriptionProvider.addMedicine(medicine1);
        prescriptionProvider.addMedicine(medicine2);

        // Act
        prescriptionProvider.clearCurrentMedicines();

        // Assert
        expect(prescriptionProvider.currentMedicines, isEmpty);
      });
    });

    group('utility methods', () {
      test('should clear search results', () {
        // Arrange
        prescriptionProvider.medicineSearchResults.addAll(['Test1', 'Test2']);

        // Act
        prescriptionProvider.clearSearchResults();

        // Assert
        expect(prescriptionProvider.medicineSearchResults, isEmpty);
      });

      test('should clear error', () {
        // Arrange
        prescriptionProvider.clearError();

        // Act & Assert
        expect(prescriptionProvider.error, null);
      });
    });
  });
}
