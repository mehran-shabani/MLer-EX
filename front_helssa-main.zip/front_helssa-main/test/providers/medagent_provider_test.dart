import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:golddrop_telemedicine/providers/medagent_provider.dart';
import 'package:golddrop_telemedicine/services/api_service.dart';
import 'package:golddrop_telemedicine/models/api_response.dart';
import 'package:golddrop_telemedicine/models/chat_session.dart';

import 'medagent_provider_test.mocks.dart';

@GenerateMocks([ApiService])
void main() {
  group('MedAgentProvider Tests', () {
    late MedAgentProvider medAgentProvider;
    late MockApiService mockApiService;

    setUp(() {
      mockApiService = MockApiService();
      medAgentProvider = MedAgentProvider(mockApiService);
    });

    test('initial state should be correct', () {
      expect(medAgentProvider.sessions, isEmpty);
      expect(medAgentProvider.currentSession, null);
      expect(medAgentProvider.messages, isEmpty);
      expect(medAgentProvider.isLoading, false);
      expect(medAgentProvider.isSendingMessage, false);
      expect(medAgentProvider.error, null);
    });

    test('loadSessions should update sessions list', () async {
      // Arrange
      final sessions = [
        ChatSession(
          id: '1',
          patientId: 'patient1',
          purpose: 'Test',
          status: 'active',
          createdAt: DateTime.now(),
        ),
      ];
      when(mockApiService.getChatSessions())
          .thenAnswer((_) async => ApiResponse.success(sessions));

      // Act
      await medAgentProvider.loadSessions();

      // Assert
      expect(medAgentProvider.sessions, sessions);
      expect(medAgentProvider.error, null);
    });

    test('createSession should create new session', () async {
      // Arrange
      final session = ChatSession(
        id: '1',
        patientId: 'patient1',
        purpose: 'Test',
        status: 'active',
        createdAt: DateTime.now(),
      );
      when(mockApiService.createChatSession(any, any))
          .thenAnswer((_) async => ApiResponse.success(session));
      when(mockApiService.getChatSessions())
          .thenAnswer((_) async => ApiResponse.success([session]));

      // Act
      final result = await medAgentProvider.createSession('Test', '12345');

      // Assert
      expect(result, true);
      expect(medAgentProvider.currentSession, session);
    });

    test('sendMessage should add message to list', () async {
      // Arrange
      final session = ChatSession(
        id: '1',
        patientId: 'patient1',
        purpose: 'Test',
        status: 'active',
        createdAt: DateTime.now(),
      );
      final message = ChatMessage(
        id: 'msg1',
        sessionId: '1',
        senderId: 'user1',
        senderType: 'patient',
        content: 'Hello',
        type: 'text',
        createdAt: DateTime.now(),
      );
      
      medAgentProvider.setCurrentSession(session);
      
      when(mockApiService.sendChatMessage(any, any))
          .thenAnswer((_) async => ApiResponse.success(message));

      // Act
      final result = await medAgentProvider.sendMessage('Hello');

      // Assert
      expect(result, true);
      expect(medAgentProvider.messages, contains(message));
    });

    test('endSession should clear current session', () async {
      // Arrange
      final session = ChatSession(
        id: '1',
        patientId: 'patient1',
        purpose: 'Test',
        status: 'active',
        createdAt: DateTime.now(),
      );
      medAgentProvider.setCurrentSession(session);
      
      when(mockApiService.endChatSession(any))
          .thenAnswer((_) async => ApiResponse.success({'status': 'ended'}));
      when(mockApiService.getChatSessions())
          .thenAnswer((_) async => ApiResponse.success([]));

      // Act
      final result = await medAgentProvider.endSession();

      // Assert
      expect(result, true);
      expect(medAgentProvider.currentSession, null);
      expect(medAgentProvider.messages, isEmpty);
    });
  });
}
