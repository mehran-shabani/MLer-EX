import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:golddrop_telemedicine/providers/enhanced_visit_provider.dart';
import 'package:golddrop_telemedicine/services/enhanced_visit_service.dart';
import 'package:golddrop_telemedicine/models/visit.dart';
import 'package:golddrop_telemedicine/models/api_response.dart';

import 'enhanced_visit_provider_test.mocks.dart';

@GenerateMocks([EnhancedVisitService])
void main() {
  group('EnhancedVisitProvider Tests', () {
    late EnhancedVisitProvider visitProvider;
    late MockEnhancedVisitService mockVisitService;

    setUp(() {
      mockVisitService = MockEnhancedVisitService();
      visitProvider = EnhancedVisitProvider(mockVisitService);
    });

    test('initial state should be correct', () {
      expect(visitProvider.visits, isEmpty);
      expect(visitProvider.doctorOnCall, null);
      expect(visitProvider.isLoading, false);
      expect(visitProvider.isSendingVisit, false);
      expect(visitProvider.isSendingSOS, false);
      expect(visitProvider.isLoadingDoctor, false);
      expect(visitProvider.error, null);
    });

    group('sendRegularVisit', () {
      test('should send regular visit successfully', () async {
        // Arrange
        final visit = Visit(
          id: '1',
          name: 'Test Patient',
          urgency: 'medium',
          description: 'Test symptoms',
          status: 'pending',
          createdAt: DateTime.now(),
        );

        when(mockVisitService.sendRegularVisit(
          name: anyNamed('name'),
          nationalCode: anyNamed('nationalCode'),
          details: anyNamed('details'),
          needsCertificate: anyNamed('needsCertificate'),
          contactMethod: anyNamed('contactMethod'),
          accessToken: anyNamed('accessToken'),
        )).thenAnswer((_) async => ApiResponse.success(visit));

        // Act
        final result = await visitProvider.sendRegularVisit(
          name: 'Test Patient',
          nationalCode: '1234567890',
          details: 'Test symptoms',
          needsCertificate: false,
          contactMethod: 'واتس‌اپ',
          accessToken: 'test_token',
        );

        // Assert
        expect(result, true);
        expect(visitProvider.visits.length, 1);
        expect(visitProvider.visits.first.name, 'Test Patient');
        expect(visitProvider.error, null);
        expect(visitProvider.isSendingVisit, false);
      });

      test('should handle visit sending failure', () async {
        // Arrange
        when(mockVisitService.sendRegularVisit(
          name: anyNamed('name'),
          nationalCode: anyNamed('nationalCode'),
          details: anyNamed('details'),
          needsCertificate: anyNamed('needsCertificate'),
          contactMethod: anyNamed('contactMethod'),
          accessToken: anyNamed('accessToken'),
        )).thenAnswer((_) async => ApiResponse.error('Visit sending failed'));

        // Act
        final result = await visitProvider.sendRegularVisit(
          name: 'Test Patient',
          nationalCode: '1234567890',
          details: 'Test symptoms',
          needsCertificate: false,
          contactMethod: 'واتس‌اپ',
          accessToken: 'test_token',
        );

        // Assert
        expect(result, false);
        expect(visitProvider.visits, isEmpty);
        expect(visitProvider.error, 'Visit sending failed');
        expect(visitProvider.isSendingVisit, false);
      });
    });

    group('sendSOSVisit', () {
      test('should send SOS visit successfully', () async {
        // Arrange
        final visit = Visit(
          id: '2',
          name: 'اورژانسی',
          urgency: 'high',
          description: 'اورژانسی - Emergency case',
          status: 'urgent',
          createdAt: DateTime.now(),
        );

        when(mockVisitService.sendSOSVisit(
          visitName: anyNamed('visitName'),
          description: anyNamed('description'),
          accessToken: anyNamed('accessToken'),
        )).thenAnswer((_) async => ApiResponse.success(visit));

        // Act
        final result = await visitProvider.sendSOSVisit(
          visitName: 'Emergency Patient',
          description: 'Emergency case',
          accessToken: 'test_token',
        );

        // Assert
        expect(result, true);
        expect(visitProvider.visits.length, 1);
        expect(visitProvider.visits.first.name, 'اورژانسی');
        expect(visitProvider.error, null);
        expect(visitProvider.isSendingSOS, false);
      });
    });

    group('loadDoctorOnCall', () {
      test('should load doctor on call successfully', () async {
        // Arrange
        final doctorData = {
          'full_name': 'Dr. Test Doctor',
          'specialty': 'General Medicine',
          'image': 'https://example.com/doctor.jpg',
          'is_available': true,
        };

        when(mockVisitService.getDoctorOnCall())
            .thenAnswer((_) async => ApiResponse.success(doctorData));

        // Act
        await visitProvider.loadDoctorOnCall();

        // Assert
        expect(visitProvider.doctorOnCall, doctorData);
        expect(visitProvider.error, null);
        expect(visitProvider.isLoadingDoctor, false);
      });

      test('should handle doctor loading failure', () async {
        // Arrange
        when(mockVisitService.getDoctorOnCall())
            .thenAnswer((_) async => ApiResponse.error('No doctor available'));

        // Act
        await visitProvider.loadDoctorOnCall();

        // Assert
        expect(visitProvider.doctorOnCall, null);
        expect(visitProvider.error, 'No doctor available');
        expect(visitProvider.isLoadingDoctor, false);
      });
    });

    group('loadVisits', () {
      test('should load visits successfully', () async {
        // Arrange
        final visits = [
          Visit(
            id: '1',
            name: 'Patient 1',
            urgency: 'low',
            description: 'Description 1',
            status: 'completed',
            createdAt: DateTime.now(),
          ),
          Visit(
            id: '2',
            name: 'Patient 2',
            urgency: 'high',
            description: 'Description 2',
            status: 'pending',
            createdAt: DateTime.now(),
          ),
        ];

        when(mockVisitService.getPatientVisits(
          accessToken: anyNamed('accessToken'),
          page: anyNamed('page'),
          limit: anyNamed('limit'),
        )).thenAnswer((_) async => ApiResponse.success(visits));

        // Act
        await visitProvider.loadVisits(accessToken: 'test_token');

        // Assert
        expect(visitProvider.visits.length, 2);
        expect(visitProvider.visits.first.name, 'Patient 1');
        expect(visitProvider.error, null);
      });
    });

    group('cancelVisit', () {
      test('should cancel visit successfully', () async {
        // Arrange
        final visit = Visit(
          id: '1',
          name: 'Test Patient',
          urgency: 'medium',
          description: 'Test symptoms',
          status: 'pending',
          createdAt: DateTime.now(),
        );

        visitProvider.visits.add(visit);

        when(mockVisitService.cancelVisit(
          visitId: anyNamed('visitId'),
          accessToken: anyNamed('accessToken'),
          reason: anyNamed('reason'),
        )).thenAnswer((_) async => ApiResponse.success(true));

        // Act
        final result = await visitProvider.cancelVisit(
          visitId: '1',
          accessToken: 'test_token',
          reason: 'Patient request',
        );

        // Assert
        expect(result, true);
        expect(visitProvider.visits.first.status, 'cancelled');
        expect(visitProvider.error, null);
      });
    });

    group('utility methods', () {
      test('should clear error', () {
        // Act
        visitProvider.clearError();

        // Assert
        expect(visitProvider.error, null);
      });

      test('should clear doctor info', () {
        // Arrange
        visitProvider.loadDoctorOnCall();

        // Act
        visitProvider.clearDoctorInfo();

        // Assert
        expect(visitProvider.doctorOnCall, null);
      });
    });
  });
}
