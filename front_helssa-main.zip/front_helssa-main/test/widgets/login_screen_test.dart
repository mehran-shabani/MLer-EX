import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:golddrop_telemedicine/screens/auth/login_screen.dart';
import 'package:golddrop_telemedicine/providers/auth_provider.dart';

import 'login_screen_test.mocks.dart';

@GenerateMocks([AuthProvider])
void main() {
  group('LoginScreen Widget Tests', () {
    late MockAuthProvider mockAuthProvider;

    setUp(() {
      mockAuthProvider = MockAuthProvider();
      when(mockAuthProvider.isLoading).thenReturn(false);
      when(mockAuthProvider.error).thenReturn(null);
    });

    Widget createWidgetUnderTest() {
      return MaterialApp(
        home: ChangeNotifierProvider<AuthProvider>.value(
          value: mockAuthProvider,
          child: const LoginScreen(),
        ),
      );
    }

    testWidgets('should display welcome text and phone input', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.text('Welcome to GoldDrop'), findsOneWidget);
      expect(find.text('Enter your phone number to get started'), findsOneWidget);
      expect(find.byType(TextFormField), findsOneWidget);
      expect(find.text('Send OTP'), findsOneWidget);
    });

    testWidgets('should show validation error for empty phone number', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.tap(find.text('Send OTP'));
      await tester.pump();

      // Assert
      expect(find.text('Please enter your phone number'), findsOneWidget);
    });

    testWidgets('should show validation error for invalid phone number', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.enterText(find.byType(TextFormField), '123456');
      await tester.tap(find.text('Send OTP'));
      await tester.pump();

      // Assert
      expect(find.text('Please enter a valid Iranian phone number'), findsOneWidget);
    });

    testWidgets('should call register when valid phone number is entered', (tester) async {
      // Arrange
      const phoneNumber = '09123456789';
      when(mockAuthProvider.register(phoneNumber))
          .thenAnswer((_) async => true);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.enterText(find.byType(TextFormField), phoneNumber);
      await tester.tap(find.text('Send OTP'));
      await tester.pump();

      // Assert
      verify(mockAuthProvider.register(phoneNumber)).called(1);
    });

    testWidgets('should show loading indicator when isLoading is true', (tester) async {
      // Arrange
      when(mockAuthProvider.isLoading).thenReturn(true);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
      expect(find.text('Send OTP'), findsNothing);
    });

    testWidgets('should show error snackbar when registration fails', (tester) async {
      // Arrange
      const phoneNumber = '09123456789';
      const errorMessage = 'Registration failed';
      when(mockAuthProvider.register(phoneNumber))
          .thenAnswer((_) async => false);
      when(mockAuthProvider.error).thenReturn(errorMessage);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.enterText(find.byType(TextFormField), phoneNumber);
      await tester.tap(find.text('Send OTP'));
      await tester.pump();
      await tester.pump(); // Additional pump for snackbar

      // Assert
      expect(find.text(errorMessage), findsOneWidget);
    });
  });
}
