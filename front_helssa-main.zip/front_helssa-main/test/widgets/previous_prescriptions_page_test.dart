import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:golddrop_telemedicine/screens/visits/previous_prescriptions_page.dart';

void main() {
  group('PreviousPrescriptionsPage Widget Tests', () {
    Widget createWidgetUnderTest() {
      return MaterialApp(
        home: const PreviousPrescriptionsPage(),
      );
    }

    testWidgets('should display app bar with correct title', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.text('ثبت داروهای روتین'), findsOneWidget);
      expect(find.byType(AppBar), findsOneWidget);
    });

    testWidgets('should display medicine form fields', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.text('نام دارو'), findsOneWidget);
      expect(find.text('دوز دارو'), findsOneWidget);
      expect(find.text('تعداد'), findsOneWidget);
      expect(find.text('مقدار مصرف'), findsOneWidget);
      expect(find.text('زمان مصرف'), findsOneWidget);
    });

    testWidgets('should show validation error for empty medicine name', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.tap(find.text('افزودن'));
      await tester.pump();

      // Assert
      expect(find.text('نام دارو الزامی است'), findsOneWidget);
    });

    testWidgets('should show validation error for invalid dose', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      
      // Enter medicine name
      await tester.enterText(
        find.widgetWithText(TextFormField, 'نام دارو'),
        'Test Medicine',
      );
      
      // Enter invalid dose
      await tester.enterText(
        find.widgetWithText(TextFormField, 'دوز دارو'),
        'invalid',
      );
      
      await tester.tap(find.text('افزودن'));
      await tester.pump();

      // Assert
      expect(find.text('دوز دارو باید عددی معتبر باشد'), findsOneWidget);
    });

    testWidgets('should add medicine to list when valid data is entered', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      
      // Enter valid medicine data
      await tester.enterText(
        find.widgetWithText(TextFormField, 'نام دارو'),
        'Aspirin',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'دوز دارو'),
        '500',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'تعداد'),
        '30',
      );
      
      await tester.tap(find.text('افزودن'));
      await tester.pump();

      // Assert
      expect(find.text('Aspirin 500 mg'), findsOneWidget);
      expect(find.text('لیست داروها'), findsOneWidget);
    });

    testWidgets('should show dropdown options for frequency', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.tap(find.text('زمان مصرف'));
      await tester.pump();

      // Assert
      expect(find.text('هر روز'), findsOneWidget);
      expect(find.text('هر شب'), findsOneWidget);
      expect(find.text('هر 6 ساعت'), findsOneWidget);
      expect(find.text('هر 8 ساعت'), findsOneWidget);
    });

    testWidgets('should show dropdown options for per intake', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.tap(find.text('مقدار مصرف'));
      await tester.pump();

      // Assert
      expect(find.text('یک عدد'), findsOneWidget);
      expect(find.text('دو عدد'), findsOneWidget);
      expect(find.text('سه عدد'), findsOneWidget);
      expect(find.text('نصف'), findsOneWidget);
    });

    testWidgets('should edit medicine when edit button is tapped', (tester) async {
      // Arrange - Add a medicine first
      await tester.pumpWidget(createWidgetUnderTest());
      
      await tester.enterText(
        find.widgetWithText(TextFormField, 'نام دارو'),
        'Test Medicine',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'دوز دارو'),
        '250',
      );
      
      await tester.tap(find.text('افزودن'));
      await tester.pump();

      // Act - Tap edit button
      await tester.tap(find.byIcon(Icons.edit_rounded));
      await tester.pump();

      // Assert
      expect(find.text('ویرایش دارو'), findsOneWidget);
      expect(find.text('ویرایش'), findsOneWidget);
      expect(find.text('لغو'), findsOneWidget);
    });

    testWidgets('should remove medicine when delete button is tapped', (tester) async {
      // Arrange - Add a medicine first
      await tester.pumpWidget(createWidgetUnderTest());
      
      await tester.enterText(
        find.widgetWithText(TextFormField, 'نام دارو'),
        'Test Medicine',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'دوز دارو'),
        '250',
      );
      
      await tester.tap(find.text('افزودن'));
      await tester.pump();

      // Act - Tap delete button
      await tester.tap(find.byIcon(Icons.close_rounded));
      await tester.pump();

      // Assert
      expect(find.text('Test Medicine 250 mg'), findsNothing);
      expect(find.text('لیست داروها'), findsNothing);
    });

    testWidgets('should show final submit button when medicines are added', (tester) async {
      // Arrange - Add a medicine
      await tester.pumpWidget(createWidgetUnderTest());
      
      await tester.enterText(
        find.widgetWithText(TextFormField, 'نام دارو'),
        'Test Medicine',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'دوز دارو'),
        '250',
      );
      
      await tester.tap(find.text('افزودن'));
      await tester.pump();

      // Assert
      expect(find.text('ثبت نهایی'), findsOneWidget);
    });

    testWidgets('should return formatted text when final submit is tapped', (tester) async {
      // Arrange - Add a medicine
      await tester.pumpWidget(createWidgetUnderTest());
      
      await tester.enterText(
        find.widgetWithText(TextFormField, 'نام دارو'),
        'Aspirin',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'دوز دارو'),
        '500',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'تعداد'),
        '30',
      );
      
      // Select frequency
      await tester.tap(find.text('زمان مصرف'));
      await tester.pump();
      await tester.tap(find.text('هر روز'));
      await tester.pump();
      
      // Select per intake
      await tester.tap(find.text('مقدار مصرف'));
      await tester.pump();
      await tester.tap(find.text('یک عدد'));
      await tester.pump();
      
      await tester.tap(find.text('افزودن'));
      await tester.pump();

      // Act - Tap final submit
      await tester.tap(find.text('ثبت نهایی'));
      await tester.pump();

      // The widget should pop with formatted text
      // This would be tested in integration tests with proper navigation
    });

    testWidgets('should clear form when cancel is tapped during edit', (tester) async {
      // Arrange - Add and edit a medicine
      await tester.pumpWidget(createWidgetUnderTest());
      
      await tester.enterText(
        find.widgetWithText(TextFormField, 'نام دارو'),
        'Test Medicine',
      );
      await tester.enterText(
        find.widgetWithText(TextFormField, 'دوز دارو'),
        '250',
      );
      
      await tester.tap(find.text('افزودن'));
      await tester.pump();
      
      await tester.tap(find.byIcon(Icons.edit_rounded));
      await tester.pump();

      // Act - Tap cancel
      await tester.tap(find.text('لغو'));
      await tester.pump();

      // Assert
      expect(find.text('افزودن دارو جدید'), findsOneWidget);
      expect(find.text('افزودن'), findsOneWidget);
      expect(find.text('لغو'), findsNothing);
    });
  });
}
