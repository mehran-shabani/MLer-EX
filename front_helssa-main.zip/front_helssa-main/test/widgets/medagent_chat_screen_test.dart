import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:golddrop_telemedicine/screens/medagent/medagent_chat_screen.dart';
import 'package:golddrop_telemedicine/providers/medagent_provider.dart';
import 'package:golddrop_telemedicine/models/chat_session.dart';

import 'medagent_chat_screen_test.mocks.dart';

@GenerateMocks([MedAgentProvider])
void main() {
  group('MedAgentChatScreen Widget Tests', () {
    late MockMedAgentProvider mockMedAgentProvider;

    setUp(() {
      mockMedAgentProvider = MockMedAgentProvider();
      when(mockMedAgentProvider.isLoading).thenReturn(false);
      when(mockMedAgentProvider.isSendingMessage).thenReturn(false);
      when(mockMedAgentProvider.error).thenReturn(null);
      when(mockMedAgentProvider.messages).thenReturn([]);
      when(mockMedAgentProvider.currentSession).thenReturn(null);
    });

    Widget createWidgetUnderTest() {
      return MaterialApp(
        home: ChangeNotifierProvider<MedAgentProvider>.value(
          value: mockMedAgentProvider,
          child: const MedAgentChatScreen(
            sessionId: 'test-session',
            purpose: 'Test Purpose',
          ),
        ),
      );
    }

    testWidgets('should display app bar with correct title', (tester) async {
      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.text('MedAgent Chat'), findsOneWidget);
      expect(find.byType(AppBar), findsOneWidget);
    });

    testWidgets('should show loading indicator when loading', (tester) async {
      // Arrange
      when(mockMedAgentProvider.isLoading).thenReturn(true);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('should show error message when error occurs', (tester) async {
      // Arrange
      const errorMessage = 'Failed to load session';
      when(mockMedAgentProvider.error).thenReturn(errorMessage);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.text(errorMessage), findsOneWidget);
      expect(find.text('Retry'), findsOneWidget);
    });

    testWidgets('should display session header when session is loaded', (tester) async {
      // Arrange
      final session = ChatSession(
        id: 'test-session',
        patientId: 'patient1',
        purpose: 'Test Purpose',
        status: 'active',
        createdAt: DateTime.now(),
      );
      when(mockMedAgentProvider.currentSession).thenReturn(session);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.text('Test Purpose'), findsOneWidget);
      expect(find.text('active'), findsOneWidget);
    });

    testWidgets('should display message input when session is active', (tester) async {
      // Arrange
      final session = ChatSession(
        id: 'test-session',
        patientId: 'patient1',
        purpose: 'Test Purpose',
        status: 'active',
        createdAt: DateTime.now(),
      );
      when(mockMedAgentProvider.currentSession).thenReturn(session);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.byType(TextField), findsOneWidget);
      expect(find.text('Type your message...'), findsOneWidget);
      expect(find.byIcon(Icons.send), findsOneWidget);
    });

    testWidgets('should call sendMessage when send button is tapped', (tester) async {
      // Arrange
      final session = ChatSession(
        id: 'test-session',
        patientId: 'patient1',
        purpose: 'Test Purpose',
        status: 'active',
        createdAt: DateTime.now(),
      );
      when(mockMedAgentProvider.currentSession).thenReturn(session);
      when(mockMedAgentProvider.sendMessage(any))
          .thenAnswer((_) async => true);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());
      await tester.enterText(find.byType(TextField), 'Hello');
      await tester.tap(find.byIcon(Icons.send));
      await tester.pump();

      // Assert
      verify(mockMedAgentProvider.sendMessage('Hello')).called(1);
    });

    testWidgets('should not display message input when session is ended', (tester) async {
      // Arrange
      final session = ChatSession(
        id: 'test-session',
        patientId: 'patient1',
        purpose: 'Test Purpose',
        status: 'ended',
        createdAt: DateTime.now(),
      );
      when(mockMedAgentProvider.currentSession).thenReturn(session);

      // Act
      await tester.pumpWidget(createWidgetUnderTest());

      // Assert
      expect(find.byType(TextField), findsNothing);
      expect(find.byIcon(Icons.send), findsNothing);
    });
  });
}
