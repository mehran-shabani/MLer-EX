#!/bin/bash

# Flutter Test Script for GoldDrop Telemedicine App

set -e

echo "🧪 Running Flutter Tests for GoldDrop Telemedicine App"
echo "=================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Flutter is installed
if ! command -v flutter &> /dev/null; then
    print_error "Flutter is not installed or not in PATH"
    exit 1
fi

print_status "Flutter version:"
flutter --version

# Clean and get dependencies
print_status "Cleaning project and getting dependencies..."
flutter clean
flutter pub get

# Generate code (for JSON serialization)
print_status "Generating code..."
flutter packages pub run build_runner build --delete-conflicting-outputs

# Run code analysis
print_status "Running code analysis..."
if flutter analyze; then
    print_success "Code analysis passed"
else
    print_error "Code analysis failed"
    exit 1
fi

# Check code formatting
print_status "Checking code formatting..."
if dart format --set-exit-if-changed .; then
    print_success "Code formatting is correct"
else
    print_warning "Code formatting issues found. Run 'dart format .' to fix them."
fi

# Run unit tests
print_status "Running unit tests..."
if flutter test --coverage; then
    print_success "Unit tests passed"
else
    print_error "Unit tests failed"
    exit 1
fi

# Generate coverage report
if command -v genhtml &> /dev/null; then
    print_status "Generating coverage report..."
    genhtml coverage/lcov.info -o coverage/html
    print_success "Coverage report generated in coverage/html/"
else
    print_warning "genhtml not found. Install lcov to generate HTML coverage reports."
fi

# Run integration tests (if available)
if [ -d "integration_test" ]; then
    print_status "Running integration tests..."
    if flutter test integration_test/; then
        print_success "Integration tests passed"
    else
        print_error "Integration tests failed"
        exit 1
    fi
else
    print_warning "No integration tests found"
fi

# Build for different platforms
print_status "Testing builds for different platforms..."

# Test Android build
print_status "Testing Android APK build..."
if flutter build apk --debug; then
    print_success "Android APK build successful"
else
    print_error "Android APK build failed"
    exit 1
fi

# Test web build
print_status "Testing web build..."
if flutter build web; then
    print_success "Web build successful"
else
    print_error "Web build failed"
    exit 1
fi

# Test iOS build (only on macOS)
if [[ "$OSTYPE" == "darwin"* ]]; then
    print_status "Testing iOS build..."
    if flutter build ios --no-codesign; then
        print_success "iOS build successful"
    else
        print_error "iOS build failed"
        exit 1
    fi
else
    print_warning "Skipping iOS build (not on macOS)"
fi

print_success "All tests completed successfully! 🎉"
print_status "Summary:"
echo "  ✅ Code analysis passed"
echo "  ✅ Unit tests passed"
echo "  ✅ Android build successful"
echo "  ✅ Web build successful"
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "  ✅ iOS build successful"
fi

# Medical app specific checks
print_status "Running medical app specific checks..."

# Check for hardcoded sensitive data
print_status "Checking for hardcoded sensitive data..."
if grep -r "password\|secret\|key\|token" lib/ --exclude-dir=generated --exclude="*.g.dart" | grep -v "// TODO\|// FIXME"; then
    print_warning "Potential hardcoded sensitive data found. Please review."
else
    print_success "No hardcoded sensitive data found"
fi

# Check for proper error handling in medical features
print_status "Checking medical feature error handling..."
if grep -r "try\s*{" lib/services/ lib/providers/ | wc -l | awk '{if($1>0) print "✅ Error handling found in " $1 " locations"; else print "⚠️  No error handling found"}'; then
    print_success "Error handling checks completed"
fi

print_success "Medical app compliance checks completed! 🏥"
