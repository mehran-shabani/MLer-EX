package com.example.helssa_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
