// lib/constants.dart
const String baseUrl = 'https://api.example.com';
