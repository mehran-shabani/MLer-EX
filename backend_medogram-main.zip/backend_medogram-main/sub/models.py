"""
Minimal subscription models used for testing the medagent application.

A SubscriptionPlan represents purchasable plans with a duration and price.
A Subscription associates a user with a plan and uses start/end dates to
determine whether it is active.
"""

from datetime import timedelta
from django.db import models
from django.utils import timezone
from django.conf import settings
from telemedicine.models import BoxMoney

User = settings.AUTH_USER_MODEL



class SubscriptionPlan(models.Model):
    """
    Represents a purchasable subscription plan. Each plan has a duration in days
    and a price. For example, a 31-day plan might cost 300 units.
    """
    
       
    name = models.CharField(max_length=50)
    days = models.PositiveIntegerField(help_text="Duration of the subscription in days")
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.name} ({self.days}d, {self.price})"

class Subscription(models.Model):
    """
    Associates a user with a subscription plan and keeps track of start and end dates.

    A subscription is considered active if the current time is before the end_date.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='subscription')
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.PROTECT)
    start_date = models.DateTimeField(auto_now_add=True)
    end_date = models.DateTimeField()

    def __str__(self):
        return f"Subscription({self.user.username}, plan={self.plan}, active={self.is_active})"

    @property
    def is_active(self) -> bool:
        return timezone.now() <= self.end_date
    

    @classmethod
    def buy_plan(cls, user, plan):
        """
        خرید پلن با در نظر گرفتن موجودی کاربر و تمدید یا ایجاد اشتراک جدید.
        """
        box_money = BoxMoney.objects.get(user=user)
        if not box_money.has_sufficient_balance(plan.price):
            raise ValueError("موجودی کافی نیست")

        box_money.deduct_amount(int(plan.price))
        now = timezone.now()
        try:
            subscription = cls.objects.get(user=user)
            if subscription.is_active:
                subscription.end_date += timedelta(days=plan.days)
            else:
                subscription.plan = plan
                subscription.start_date = now
                subscription.end_date = now + timedelta(days=plan.days)
            subscription.plan = plan
            subscription.save()
        except cls.DoesNotExist:
            subscription = cls.objects.create(
                user=user,
                plan=plan,
                start_date=now,
                end_date=now + timedelta(days=plan.days)
            )
        return subscription
