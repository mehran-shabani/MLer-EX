"""
REST API views for the MedAgent application.

These views implement OTP request/verification, chat session management, posting
messages, ending sessions, and retrieving summaries. The views enforce
authentication and subscription permissions where appropriate and rely on
auxiliary modules for sending SMS and interacting with the agent.
"""

import random
from django.utils import timezone
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from medagent.permissions import HasActiveSubscription, PatientHasActiveSubscription
from medagent.serializers import (
    CreateSession_for_doctorSerializer, OTPRequestSerializer, OTPVerifySerializer,
    CreateSessionSerializer, ChatMessageSerializer,
    EndSessionSerializer, PatientSummarySerializer,
    SessionSummarySerializer
)
from django.contrib.auth import get_user_model
from medagent.models import (
    OTPVerification, AccessHistory,
    ChatSession, ChatMessage, SessionSummary, PatientSummary
)
from medagent.sms import send_sms
from medagent.tools import SummarizeSessionTool, ProfanityCheckTool

User = get_user_model()

class RequestOTP(APIView):
    permission_classes = [IsAuthenticated, HasActiveSubscription]

    def post(self, request):
        ser = OTPRequestSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        pn = ser.validated_data["phone_number"]

        patient = get_object_or_404(User, phone_number=pn)
        raw = f"{random.randint(0, 999999):06d}"
        OTPVerification.create(patient, raw)
        send_sms(phone=pn,raw=raw)
        return Response({"msg": "OTP sent"}, status=200)

class VerifyOTP(APIView):
    permission_classes = [IsAuthenticated, HasActiveSubscription]

    def post(self, request):
        ser = OTPVerifySerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        pn, code = ser.validated_data.values()

        patient = get_object_or_404(User, phone_number=pn)
        otp = OTPVerification.objects.filter(user=patient).latest("created_at")
        if not otp.valid(code) and AccessHistory.objects.filter(doctor=request.user, user=patient).exists():
            return Response({"error": "OTP نامعتبر یا منقضی"}, status=400)

        AccessHistory.objects.create(doctor=request.user, patient=patient)
        return Response({"msg": "Access granted", "patient_id": patient.id}, status=200)

class CreateSession(APIView):
    permission_classes = [IsAuthenticated, HasActiveSubscription]

    def post(self, request):
        ser = CreateSessionSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        user = get_object_or_404(User, id=ser.validated_data["patient_id"])

        session = ChatSession.objects.create(
            user=user,
            purpose=ser.validated_data.get("purpose", "")
        )
        return Response({"session_id": session.id}, status=201)

class CreateSession_for_doctor(APIView):
    """
    یک پزشک پس از داشتن OTP معتبر برای بیمار می‌تواند جلسه‌ی ویزیت ایجاد کند.
    پزشک باید اشتراک فعال خود بیمار را نیز داشته باشد (PatientHasActiveSubscription).
    """
    permission_classes = [IsAuthenticated, PatientHasActiveSubscription]

    def post(self, request, *args, **kwargs):
        ser = CreateSession_for_doctorSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        doctor = request.user
        patient_id = ser.validated_data.get("patient_id")
        patient = get_object_or_404(User, id=patient_id)

        # اطمینان از وجود AccessHistory (OTP) بین این پزشک و بیمار
        has_otp = AccessHistory.objects.filter(doctor=doctor, patient=patient).exists()
        if not has_otp:
            return Response({"error": "no OTP access"}, status=403)

        session = ChatSession.objects.create(        # دکتر ایجاد‌کننده جلسه
            patient=patient,      # بیمار مربوطه
            purpose=ser.validated_data.get("purpose", ""),
            is_visit=True,
            doctor=doctor
        )
        return Response({"session_id": session.id}, status=201)

class PostMessage(APIView):
    permission_classes = [IsAuthenticated, HasActiveSubscription]

    def post(self, request, session_id):
        session = get_object_or_404(ChatSession, id=session_id, ended_at__isnull=True)
        
        if session.is_visit:
            pn = session.patient
            if not  AccessHistory.objects.filter(doctor=request.user, patient=pn).exists():
                 return Response({"error": "not doctor"}, status=403)

           

        ser = ChatMessageSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        content = ser.validated_data["content"]

        # Check for profanity
        if ProfanityCheckTool()._run(content) == "True":
            content = "[پیام حاوی کلمات نامناسب بود]"

        ChatMessage.objects.create(session=session, role="owner", content=content)
        from medagent.agent_setup import agent

        
        reply = agent.run(content)
        ChatMessage.objects.create(session=session, role="assistant", content=reply)
        return Response({"assistant_reply": reply})

class EndSession(APIView):
    permission_classes = [IsAuthenticated, HasActiveSubscription]

    def patch(self, request):
        ser = EndSessionSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        sess = get_object_or_404(ChatSession, id=ser.validated_data["session_id"], owner=request.user)

        sess.ended_at = timezone.now()
        sess.save(update_fields=["ended_at"])

        SummarizeSessionTool()._run(str(sess.id))
        return Response({"msg": "session closed & summarized"})

class GetPatientSummary(APIView):
    permission_classes = [IsAuthenticated, HasActiveSubscription]

    def get(self, request, patient_id):
        summary = get_object_or_404(PatientSummary, patient_id=patient_id)
        patient_user = summary.patient.user
        # فقط خود بیمار یا پزشکی که OTP دارد می‌تواند خلاصه را ببیند
        if request.user != patient_user and not AccessHistory.objects.filter(doctor=request.user, patient=summary.patient).exists():
            return Response({"error": "access denied"}, status=403)
        return Response(PatientSummarySerializer(summary).data)

class GetSessionSummary(APIView):
    permission_classes = [IsAuthenticated, HasActiveSubscription]

    def get(self, request, session_id):
        summ = get_object_or_404(SessionSummary, session_id=session_id)
        session = summ.session
        # مالک جلسه یا پزشکی با دسترسی OTP می‌تواند خلاصه را ببیند
        if request.user != session.owner and not AccessHistory.objects.filter(doctor=request.user, patient=session.patient).exists():
            return Response({"error": "access denied"}, status=403)
        return Response(SessionSummarySerializer(summ).data)
