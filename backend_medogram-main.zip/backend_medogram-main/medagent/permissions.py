"""
Custom permission classes for MedAgent.

- HasActiveSubscription : فقط کاربرانی را می‌پذیرد که یک Subscription فعال دارند.
- PatientHasActiveSubscription : بررسی می‌کند بیمار (از طریق پارامتر URL) اشتراک فعال دارد.
"""

from rest_framework.permissions import BasePermission
from django.shortcuts import get_object_or_404
from sub.models import Subscription
from django.contrib.auth import get_user_model

User = get_user_model()


class HasActiveSubscription(BasePermission):
    """
    دسترسی فقط برای کاربرانی که Subscription فعال دارند.
    AnonymousUser یا کاربران بدون Subscription → HTTP 403.
    """

    message = "You must have an active subscription."

    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False

        try:
            return user.subscription.is_active
        except (AttributeError, Subscription.DoesNotExist):
            return False


class PatientHasActiveSubscription(BasePermission):
    """
    بررسی می‌کند «بیماری» که در پارامترهای URL آمده، Subscription فعال دارد.
    انتظار می‌رود ویو پارامتر `patient_id` یا `phone_number` را در kwargs داشته باشد.
    """

    message = "Patient must have an active subscription."

    # نام پارامتر را می‌توانید بر اساس URLConf خود تغییر دهید
    patient_lookup_kw = "patient_id"

    def has_permission(self, request, view):
        patient_id = view.kwargs.get(self.patient_lookup_kw)
        if not patient_id:
            # در برخی ویوها شاید phone_number ارسال شده باشد
            phone = request.data.get("phone_number") or request.query_params.get("phone_number")
            if phone:
                patient = get_object_or_404(User, phone_number=phone)
            else:
                return False
        else:
            patient = get_object_or_404(User, pk=patient_id)

        try:
            return patient.subscription.is_active
        except (AttributeError, Subscription.DoesNotExist):
            return False
