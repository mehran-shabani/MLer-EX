"""
URL patterns for the MedAgent app.

Endpoints:
- OTP request / verify
- Chat session create / message / end
- Patient & session summaries
"""

from django.urls import path
from . import views

app_name = "medagent"   # ← namespace

urlpatterns = [
    # OTP
    path("otp/request/", views.RequestOTP.as_view(), name="request-otp"),
    path("otp/verify/", views.VerifyOTP.as_view(), name="verify-otp"),

    # Session (patient)
    path("session/create/", views.CreateSession.as_view(), name="session-create"),
    path("session-doctor/create/", views.CreateSession_for_doctor.as_view(),
         name="session-doctor-create"),
    path("session/<int:session_id>/message/", views.PostMessage.as_view(),
         name="session-message"),
    path("session/end/", views.EndSession.as_view(), name="session-end"),

    # Summaries
    path("patient/<int:patient_id>/summary/", views.GetPatientSummary.as_view(),
         name="patient-summary"),
    path("session/<int:session_id>/summary/", views.GetSessionSummary.as_view(),
         name="session-summary"),
]
