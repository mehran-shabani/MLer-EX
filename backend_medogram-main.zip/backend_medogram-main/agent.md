# **Medogram — Agent Testing Guidelines**

> **IMPORTANT:** This file (``) is the *single* source of truth for all testing‑related work carried out by Agents. **Do not edit this file directly.** Questions, suggestions, or change requests *must* be appended to `` (see § 7).

---

## 1 Purpose

Provide a clear, enforceable checklist that enables every Agent to create and maintain an automated test‑suite with overall project **code‑coverage ≥ 98 %**.

## 2 Core Principles

1. **Testing is your only job.** Any merge request that drops total coverage below 98 % **must be rejected**.
2 **Your test must be cover view api model serializers if you have a cover 90% please go for missing items that dont have test**
3. **If have wrong test please correct them and if all of tests is passed but coverage<90% please write new test for non coverage areas.**
4. Record *every* activity—successful or not—in an **append‑only** manner inside `agent.log` (see § 7).
5. **Never** modify critical files such as `agent.md`, `agent.dock`, CI/CD configs, etc. Proposals belong in the log.

## 3 User‑Creation Convention

Create users in tests and scripts using **exactly four mandatory fields** in the order shown below:

```bash
# phone_number  username  password     email
create_user +989121234567  alice   "S3cur3P@ss"  alice@example.com
```

## 4 `pytest.ini`

A **single** `pytest.ini` must live in the repository root and contain, at minimum, the following:

```ini
[pytest]
addopts = -ra -q --cov=.
filterwarnings =
    ignore::DeprecationWarning
```

Agents may extend this configuration, but **never** remove existing options.

## 5 Writing Tests

- Use **pytest** together with **pytest‑cov**.
- Recommended directory layout:

```
project_root/
├─ appname/
│   └─ tests/
│       ├─ unit/
│       ├─ integration/
│       └─ e2e/
└─ …
```

- Unit tests must be fast and isolated. Integration tests may connect to real services but **must** rely on dedicated test data.
- Provide at least minimal tests covering all models, views, API endpoints,
  serializers, and signals.

## 6 Coverage ≥ 98 %

Run locally:

```bash
pytest --cov=. --cov-report=html
open htmlcov/index.html   # or your OS equivalent
```

A pull request that reduces total coverage below 98% **fails CI** and must be fixed before merging.

## 7 `agent.log` — Activity Ledger

- **Format** (one line per entry):
  ```
  [YYYY-MM-DD HH:MM:SS] <agent‑id> :: <short description>
  ```
- The log is **append‑only**. Never edit or delete previous entries.

## 8 Restricted vs Free Areas

| Path                              | Policy                           |
| --------------------------------- | -------------------------------- |
| `agent.md`                        | **READ‑ONLY**                    |
| `structure.md` & other core files | Read‑only (put proposals in log) |
| `appname/tests/`                  | Free to modify                   |

## 9 GitHub Automation & Templates

Agents are responsible for ensuring the `` folder exists and remains up‑to‑date:

| File                                         | Purpose                           |
| -------------------------------------------- | --------------------------------- |
| `.github/ISSUE_TEMPLATE/bug_report.yml`      | Standard bug‑report template      |
| `.github/ISSUE_TEMPLATE/feature_request.yml` | Standard feature‑request template |
| `.github/pull_request_template.md`           | Pull‑request checklist            |
| `.github/dependabot.yml`                     | Dependabot configuration          |

*Create the file if missing; update it if outdated.* Every modification **must** be logged in `agent.log`.

## 10 Before You Start Working

1. Read the latest entries in ``.
2. Add a new entry describing the task you are about to begin.

## 11 References

- [pytest Documentation](https://docs.pytest.org/)
- [pytest‑cov](https://github.com/pytest-dev/pytest-cov)
- [PEP 8 — Style Guide for Python Code](https://peps.python.org/pep-0008/)

---

*Document version 1.3 — 02 Aug 2025*

